(function(){
  var f=null; try{ f=localStorage.getItem('perf_lite'); }catch(e){}
  var low=(navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4);
  function apply(on){ document.documentElement.classList.toggle('mf-lite',!!on); }
  apply(f==='1'||(f!=='0'&&low));
  window.mfLiteOn=function(){ return document.documentElement.classList.contains('mf-lite'); };
  window.mfToggleLite=function(){
    var on=!window.mfLiteOn(); apply(on);
    try{ localStorage.setItem('perf_lite',on?'1':'0'); }catch(e){}
    var b=document.getElementById('mf-lite-label'); if(b) b.textContent=on?'حالەتی خێرا: کراوە':'حالەتی خێرا: داخراو';
  };
  document.addEventListener('DOMContentLoaded',function(){ var b=document.getElementById('mf-lite-label'); if(b) b.textContent=window.mfLiteOn()?'حالەتی خێرا: کراوە':'حالەتی خێرا: داخراو'; });
})();
