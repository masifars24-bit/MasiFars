(function(){
  var KEY='mf_hidden_cards';
  var PROTECTED=['ڕێکخستن']; // settings box can never be hidden, otherwise this screen would be unreachable
  function getHidden(){
    try{var a=JSON.parse(localStorage.getItem(KEY)||'[]'); return Array.isArray(a)?a.filter(function(k){return PROTECTED.indexOf(k)<0;}):[];}catch(e){return [];}
  }
  function setHidden(a){try{localStorage.setItem(KEY,JSON.stringify(a));}catch(e){}}
  function allCards(){
    var out=[];
    document.querySelectorAll('.dashboard-grid > .menu-card[data-card-key]').forEach(function(c){
      var m=/openCardDashboard\(\s*'[^']*'\s*,\s*'([^']+)'/.exec(c.getAttribute('onclick')||'');
      var tEl=c.querySelector('.card-title');
      var key=c.getAttribute('data-card-key');
      out.push({el:c,key:key,icon:m?m[1]:'layout-grid',label:(tEl&&tEl.textContent.trim())||key,color:c.style.getPropertyValue('--wave-color').trim()||'var(--c-1,#4f46e5)'});
    });
    return out;
  }
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function apply(){
    var hidden=getHidden();
    allCards().forEach(function(c){c.el.classList.toggle('mf-box-hidden',hidden.indexOf(c.key)>-1);});
    if(typeof window.mfRenumberCards==='function') window.mfRenumberCards();
  }
  window.renderBoxVisibilityList=function(){
    var list=document.getElementById('mf-vis-list'); if(!list) return;
    var hidden=getHidden(), cards=allCards(), shown=0;
    list.innerHTML=cards.map(function(c){
      var isProt=PROTECTED.indexOf(c.key)>-1, on=hidden.indexOf(c.key)<0;
      if(on) shown++;
      var ctl=isProt
        ? '<span class="mf-vis-lock"><i data-lucide="lock"></i></span>'
        : '<button type="button" class="mf-vis-switch'+(on?' on':'')+'" data-vis-key="'+esc(c.key)+'" aria-pressed="'+(on?'true':'false')+'" aria-label="'+esc(c.label)+'"><span class="k"></span></button>';
      return '<div class="mf-vis-row'+(on?'':' off')+'" style="--row-c:'+c.color+'">'
        +'<div class="mf-vis-ico"><i data-lucide="'+esc(c.icon)+'"></i></div>'
        +'<div class="mf-vis-txt"><b>'+esc(c.label)+'</b><span>'+(isProt?'هەمیشە دیارە':(on?'دیارە لە ڕووکاری سەرەکی':'شاراوەیە'))+'</span></div>'
        +ctl+'</div>';
    }).join('');
    var cnt=document.getElementById('mf-vis-count'); if(cnt) cnt.textContent=shown+' لە '+cards.length+' بۆکس دیارن';
    if(typeof safeCreateIcons==='function') safeCreateIcons();
  };
  window.mfBoxVisShowAll=function(){setHidden([]);apply();window.renderBoxVisibilityList();};
  document.addEventListener('click',function(e){
    var b=e.target&&e.target.closest?e.target.closest('.mf-vis-switch[data-vis-key]'):null; if(!b) return;
    var key=b.getAttribute('data-vis-key'), hidden=getHidden(), i=hidden.indexOf(key);
    if(i>-1) hidden.splice(i,1); else hidden.push(key);
    setHidden(hidden); apply(); window.renderBoxVisibilityList();
  });
  apply();
})();
