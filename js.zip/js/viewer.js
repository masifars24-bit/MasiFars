(function(){
  var tok=null;
  try{ tok=new URLSearchParams(location.search).get('r'); }catch(e){}
  if(!tok||!/^[A-Za-z0-9]{12,64}$/.test(tok)) return;
  window.__MF_VIEWER=tok;
  var SB='https://wtzffmorfclxivopvsit.supabase.co', KEY='sb_publishable_YDz--eVlnrTgZJ6hKJwLig_bzY1-Fjg';
  document.documentElement.classList.add('mf-viewer');
  var st=document.createElement('style');
  st.textContent=[
    'html.mf-viewer,html.mf-viewer body{margin:0!important;background:#f1f2f6!important;overflow:auto!important}',
    'html.mf-viewer body>*:not(#mf-viewer){display:none!important}',
    'html.mf-viewer body>#mf-viewer{position:fixed!important;inset:0!important;z-index:2147483647!important;overflow:auto;-webkit-overflow-scrolling:touch;background:#f1f2f6;padding:14px 10px 0;box-sizing:border-box;display:flex!important;visibility:visible!important;opacity:1!important;justify-content:center;align-items:flex-start;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;direction:rtl}',
    '#mf-viewer .vwrap{width:100%;max-width:720px;min-height:100%;display:flex;flex-direction:column;align-items:stretch}',
    '#mf-viewer .vimg{display:block;width:100%;height:auto;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.18);background:#fff;image-rendering:auto;-webkit-user-select:none;user-select:none}',
    '#mf-viewer .vhint{margin:12px 6px 0;color:#7b8096;font-size:12.5px;line-height:1.7;text-align:center}',
    '#mf-viewer .vbar{position:sticky;bottom:0;margin-top:auto;display:flex;gap:8px;padding:12px 0 calc(12px + env(safe-area-inset-bottom,0px));background:linear-gradient(to top,#f1f2f6 80%,rgba(241,242,246,0))}',
    '#mf-viewer .vbtn{flex:1 1 0;min-width:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;min-height:62px;padding:8px 4px;border:0;border-radius:16px;color:#fff;font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent;box-shadow:0 8px 18px rgba(30,30,80,.22);transition:transform .12s ease,opacity .2s ease}',
    '#mf-viewer .vbtn:active{transform:scale(.96)}',
    '#mf-viewer .vbtn[disabled]{opacity:.55;pointer-events:none}',
    '#mf-viewer .vbtn b{font-size:14.5px;font-weight:800;line-height:1.2}',
    '#mf-viewer .vbtn small{font-size:11.5px;font-weight:600;opacity:.88;line-height:1.2}',
    '#mf-viewer .vb-dl{background:linear-gradient(135deg,#4338ca,#6d3be0)}',
    '#mf-viewer .vb-pdf{background:linear-gradient(135deg,#e11d48,#f4476b)}',
    '#mf-viewer .vb-sh{background:linear-gradient(135deg,#15a05a,#2fcf88)}',
    '#mf-viewer .vtoast{position:fixed;left:50%;bottom:calc(96px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);max-width:88vw;padding:10px 16px;border-radius:12px;background:rgba(20,22,40,.93);color:#fff;font-size:14px;line-height:1.6;text-align:center;z-index:5}',
    '#mf-viewer .vmsg{margin:auto;color:#555;font-size:17px;text-align:center;line-height:1.8;padding:24px;direction:rtl}',
    '#mf-viewer .vspin{width:34px;height:34px;border:4px solid #d6d8e0;border-top-color:#e8590c;border-radius:50%;animation:mfvs .8s linear infinite;margin:0 auto 14px}',
    '@keyframes mfvs{to{transform:rotate(360deg)}}'
  ].join('');
  document.head.appendChild(st);
  try{ var vp=document.querySelector('meta[name=viewport]'); if(vp) vp.setAttribute('content','width=device-width, initial-scale=1, maximum-scale=5, user-scalable=yes'); }catch(e){}
  try{ document.title='وەسڵ - Massi Fars'; }catch(e){}

  /* request starts immediately (in parallel with the rest of the page loading) */
  var dataP=fetch(SB+'/rest/v1/rpc/get_public_receipt',{method:'POST',headers:{apikey:KEY,Authorization:'Bearer '+KEY,'Content-Type':'application/json'},body:JSON.stringify({p_token:tok})})
    .then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); });
  dataP.catch(function(){});

  function msg(box,t,spin){ box.innerHTML=''; var d=document.createElement('div'); d.className='vmsg'; if(spin){var sp=document.createElement('div');sp.className='vspin';d.appendChild(sp);} d.appendChild(document.createTextNode(t)); box.appendChild(d); }

  var ICO={
    dl:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg>',
    pdf:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M12 11v6M9.5 14.5 12 17l2.5-2.5"/></svg>',
    sh:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg>'
  };

  function render(box,img){
    var m=/^data:image\/(jpeg|png|webp);/.exec(img);
    var mime='image/'+m[1], ext=(m[1]==='jpeg'?'jpg':m[1]), base='wasl-'+tok.slice(0,6);
    var wrap=document.createElement('div'); wrap.className='vwrap';
    var im=new Image(); im.className='vimg'; im.alt=''; im.decoding='async'; im.draggable=false;
    wrap.appendChild(im);
    var hint=document.createElement('div'); hint.className='vhint';
    hint.textContent='بۆ وردبینی، بە دوو پەنجە وێنەکە گەورە بکە. ئەگەر دابەزاندن کار نەکرد، وێنەکە بە درێژی دابگرە و پاشەکەوتی بکە.';
    wrap.appendChild(hint);
    var bar=document.createElement('div'); bar.className='vbar';
    bar.innerHTML=
      '<button type="button" class="vbtn vb-dl" data-a="dl">'+ICO.dl+'<b>دابەزاندن</b><small>وەک وێنە</small></button>'+
      '<button type="button" class="vbtn vb-pdf" data-a="pdf">'+ICO.pdf+'<b>دابەزاندن</b><small>وەک PDF</small></button>'+
      '<button type="button" class="vbtn vb-sh" data-a="sh">'+ICO.sh+'<b>هاوبەشکردن</b><small>وێنەی وەسڵ</small></button>';
    wrap.appendChild(bar);

    var blobCache=null;
    function getBlob(){
      if(blobCache) return blobCache;
      var bin=atob(img.slice(img.indexOf(',')+1)), len=bin.length, u=new Uint8Array(len), i;
      for(i=0;i<len;i++) u[i]=bin.charCodeAt(i);
      blobCache=new Blob([u],{type:mime});
      return blobCache;
    }
    var tt=null;
    function toast(t){
      var old=box.querySelector('.vtoast'); if(old&&old.parentNode) old.parentNode.removeChild(old);
      var d=document.createElement('div'); d.className='vtoast'; d.textContent=t; box.appendChild(d);
      clearTimeout(tt); tt=setTimeout(function(){ if(d.parentNode) d.parentNode.removeChild(d); },3200);
    }
    function doDownload(){
      var url=URL.createObjectURL(getBlob()), a=document.createElement('a');
      if(!('download' in a)){ window.open(url,'_blank'); toast('وێنەکە کرایەوە، بە درێژی لێی بدە و پاشەکەوتی بکە'); return; }
      a.href=url; a.download=base+'.'+ext; a.rel='noopener'; a.style.display='none';
      box.appendChild(a); a.click();
      setTimeout(function(){ if(a.parentNode) a.parentNode.removeChild(a); },1000);
      setTimeout(function(){ try{ URL.revokeObjectURL(url); }catch(e){} },90000);
      toast('وێنەی وەسڵ دابەزێنرا');
    }
    function copyLink(url){
      if(navigator.clipboard&&navigator.clipboard.writeText){
        return navigator.clipboard.writeText(url).then(function(){ toast('بەستەری وەسڵ کۆپی کرا'); },function(){ toast(url); });
      }
      try{
        var t=document.createElement('textarea'); t.value=url; t.style.cssText='position:fixed;opacity:0'; box.appendChild(t); t.select();
        var ok=document.execCommand('copy'); box.removeChild(t);
        toast(ok?'بەستەری وەسڵ کۆپی کرا':url);
      }catch(e){ toast(url); }
    }
    function shareLink(){
      var url=location.href;
      if(navigator.share){
        return navigator.share({title:'وەسڵ',url:url}).catch(function(e){ if(e&&e.name==='AbortError') return; return copyLink(url); });
      }
      return copyLink(url);
    }
    function doShare(){
      var file=null;
      try{ file=new File([getBlob()],base+'.'+ext,{type:mime}); }catch(e){}
      if(file&&navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){
        return navigator.share({files:[file],title:'وەسڵ'}).catch(function(e){ if(e&&e.name==='AbortError') return; return shareLink(); });
      }
      return shareLink();
    }
    function doPdf(){
      try{ if(window.mfEnsurePdfLibs) window.mfEnsurePdfLibs(); }catch(e){}
      var J=window.jspdf&&window.jspdf.jsPDF;
      if(!J){ toast('PDF ئامادە نییە، دووبارە هەوڵبدەوە'); return; }
      var jpg=img;
      if(m[1]!=='jpeg'){
        var c=document.createElement('canvas'); c.width=im.naturalWidth; c.height=im.naturalHeight;
        var x=c.getContext('2d'); x.fillStyle='#fff'; x.fillRect(0,0,c.width,c.height); x.drawImage(im,0,0);
        jpg=c.toDataURL('image/jpeg',0.97);
      }
      var wmm=116, hmm=wmm*(im.naturalHeight||1)/(im.naturalWidth||1);
      var pdf=new J({orientation:(hmm>=wmm?'portrait':'landscape'),unit:'mm',format:[wmm,hmm]});
      pdf.addImage(jpg,'JPEG',0,0,wmm,hmm);
      pdf.save(base+'.pdf');
      toast('PDF ی وەسڵ دابەزێنرا');
    }
    bar.addEventListener('click',function(e){
      var btn=e.target.closest?e.target.closest('.vbtn'):null;
      if(!btn||btn.disabled) return;
      var act=btn.getAttribute('data-a');
      btn.disabled=true;
      var free=function(){ btn.disabled=false; };
      try{
        var r=(act==='dl'?doDownload():act==='pdf'?doPdf():doShare());
        if(r&&r.then) r.then(free,free); else setTimeout(free,500);
      }catch(err){
        free(); toast('هەڵەیەک ڕوویدا، دووبارە هەوڵبدەوە');
      }
    });

    var shown=false;
    function show(){ if(shown) return; shown=true; box.innerHTML=''; box.appendChild(wrap); setTimeout(function(){ try{ getBlob(); }catch(e){} },300); }
    im.onload=show;
    im.onerror=function(){ if(shown) return; shown=true; msg(box,'وێنەی وەسڵ نەتوانرا بکرێتەوە'); };
    setTimeout(show,10000);
    im.src=img;
  }

  function boot(){
    var box=document.createElement('div'); box.id='mf-viewer'; document.body.appendChild(box);
    msg(box,'چاوەڕێبە...',true);
    dataP.then(function(img){
      if(typeof img!=='string'||!/^data:image\/(jpeg|png|webp);base64,/.test(img)){ msg(box,'ئەم وەسڵە نەدۆزرایەوە یان سڕاوەتەوە'); return; }
      render(box,img);
    },function(){ msg(box,'نەتوانرا وەسڵەکە بار بکرێت، ئینتەرنێتەکەت بپشکنە و دووبارە هەوڵبدەوە'); });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();
