(function(){
  var MAP={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
  function E(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return MAP[c];});}
  function col(c,fb){c=String(c||'');return /^(#[0-9a-f]{3,8}|var\(--[a-z0-9-]+\)|color-mix\([^;"]+\))$/i.test(c)?c:fb;}
  function fsz(v){var n=String(v).length;return n>13?' s3':(n>10?' s2':'');}
  function ic(n){return '<i data-lucide="'+n+'"></i>';}
    window.mfUcClose=function(){var l=document.querySelectorAll('.mf-uc-open');for(var i=0;i<l.length;i++)l[i].classList.remove('mf-uc-open');};
  window.mfUcMenu=function(btn){var card=btn.closest('.mf-uc');if(!card)return;var was=card.classList.contains('mf-uc-open');window.mfUcClose();if(!was)card.classList.add('mf-uc-open');};
  document.addEventListener('click',function(e){if(!e.target.closest||!e.target.closest('.mf-uc-menu'))window.mfUcClose();});

  window.mfUcCard=function(o){
    var c=col(o.color,'var(--c-7)');
    var menu=o.menu||[];
    var pr=(typeof o.progress==='number'&&isFinite(o.progress))?Math.max(0,Math.min(1,o.progress)):null;
    var h='<div class="mf-uc'+(o.cleared?' mf-uc-cleared':'')+'" style="--uc:'+c+'"'+(o.onOpen?' onclick="'+o.onOpen+'"':'')+'>';
    h+='<div class="mf-uc-head">';
    h+='<div class="mf-uc-icowrap"><div class="mf-uc-ico">'+(o.image?'<img src="'+E(o.image)+'" alt="">':ic(o.icon||'user-round'))+'</div>'+(o.cleared?'<span class="mf-uc-done" title="تەواو">'+ic('check')+'</span>':'')+'</div>';
    h+='<div class="mf-uc-info"><div class="mf-uc-title">'+E(o.title)+'</div>';
    if(o.subtitle||o.meta){
      h+='<div class="mf-uc-line">';
      if(o.subtitle)h+='<span class="mf-uc-sub">'+E(o.subtitle)+'</span>';
      if(o.meta)h+='<span class="mf-uc-meta'+(o.meta.muted?' muted':'')+'">'+ic(o.meta.icon||'phone')+'<span>'+E(o.meta.text)+'</span></span>';
      h+='</div>';
    }
    h+='</div>';
    if(menu.length){
      h+='<button type="button" class="mf-uc-act" aria-label="هەڵبژاردنەکان" onclick="event.stopPropagation();mfUcMenu(this)">'+ic('ellipsis-vertical')+'</button>';
      h+='<div class="mf-uc-menu" onclick="event.stopPropagation()">';
      menu.forEach(function(m){h+='<button type="button" class="'+(m.danger?'danger':'')+'" onclick="event.stopPropagation();mfUcClose();'+m.js+'">'+ic(m.icon||'circle')+'<span>'+E(m.label)+'</span></button>';});
      h+='</div>';
    } else {
      h+='<span class="mf-uc-act nav">'+ic('chevron-left')+'</span>';
    }
    h+='</div>';
    h+='<div class="mf-uc-stats">';
    (o.tiles||[]).forEach(function(t){
      var tone=(!t.tone||t.tone==='uc')?'var(--uc)':t.tone;
      h+='<div class="mf-uc-tile" style="--t:'+tone+'"><span class="l">'+ic(t.icon)+'<b>'+E(t.label)+'</b></span><span class="v'+(t.text?' txt':fsz(t.value))+'">'+E(t.value)+'</span></div>';
    });
    h+='</div>';
    if(pr!==null)h+='<div class="mf-uc-bar" title="'+Math.round(pr*100)+'%"><i style="--p:'+(pr*100).toFixed(1)+'%"></i></div>';
    if(o.footer)h+='<div class="mf-uc-foot"><span class="doc">'+ic('file-text')+'</span><span class="txt">'+E(o.footer)+'</span></div>';
    h+='</div>';
    return h;
  };
})();
