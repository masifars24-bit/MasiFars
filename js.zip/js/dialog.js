(function () {
  'use strict';
  if (window.mfDialog) return;
  var P = {
    warn: '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
    ok: '<circle cx="12" cy="12" r="10"/><path d="m8.5 12.5 2.5 2.5 4.5-5"/>',
    ask: '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
    err: '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/>',
    out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    hist: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>'
  };
  var C = { danger: ['#ef4444', '#f97316'], warn: ['#f59e0b', '#f97316'], info: ['#6d3df0', '#a855f7'], ok: ['#10b981', '#22c55e'], ask: ['#6d3df0', '#a855f7'], err: ['#ef4444', '#ec4899'] };
  var DI = { danger: 'warn', warn: 'warn', info: 'info', ok: 'ok', ask: 'ask', err: 'err' };
  var css = '#mfd-ov{position:fixed;inset:0;z-index:2147483600;display:none;align-items:center;justify-content:center;padding:44px 20px 20px;direction:rtl;background:rgba(8,6,24,.62);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);font-family:inherit}#mfd-ov.open{display:flex}' +
    '#mfd-box{position:relative;width:100%;max-width:360px;padding:50px 20px 18px;border-radius:30px;text-align:center;background:var(--bg-card,#fff);color:var(--text-main,#222);border:1px solid color-mix(in srgb,var(--a) 28%,var(--border,rgba(0,0,0,.1)));box-shadow:0 30px 80px rgba(10,0,40,.55);animation:mfdPop .32s cubic-bezier(.2,.9,.3,1) both}' +
    '@keyframes mfdPop{from{opacity:0;transform:translateY(20px) scale(.94)}to{opacity:1;transform:none}}@keyframes mfdHalo{0%{opacity:.9;transform:scale(.92)}100%{opacity:0;transform:scale(1.25)}}' +
    '.mfd-ic{position:absolute;top:-38px;left:50%;margin-left:-36px;width:72px;height:72px;border-radius:26px;display:flex;align-items:center;justify-content:center;color:#fff;background:linear-gradient(135deg,var(--a),var(--b));border:3px solid var(--bg-card,#fff);box-shadow:0 14px 30px color-mix(in srgb,var(--a) 55%,transparent),inset 0 1px 0 rgba(255,255,255,.4)}' +
    '.mfd-ic::before{content:"";position:absolute;inset:-9px;border-radius:32px;border:2px solid color-mix(in srgb,var(--a) 45%,transparent);animation:mfdHalo 2s ease-out infinite}' +
    '.mfd-t{margin:0 0 8px;font-size:19px;font-weight:900;line-height:1.4;color:var(--text-main,#222)}' +
    '.mfd-m{max-height:38vh;overflow:auto;font-size:14px;font-weight:600;line-height:1.9;color:var(--text-sub,#6b7088)}.mfd-m p{margin:0 0 6px}' +
    '.mfd-m code{display:block;direction:ltr;text-align:left;margin:8px 0;padding:10px 12px;border-radius:12px;font:700 12.5px/1.5 ui-monospace,Menlo,monospace;background:color-mix(in srgb,var(--a) 10%,var(--bg-card,#fff));border:1px dashed color-mix(in srgb,var(--a) 45%,transparent);color:var(--text-main,#222);word-break:break-all;user-select:all}' +
    '.mfd-b{display:flex;gap:10px;margin-top:18px}.mfd-b button{flex:1;margin:0;padding:14px 10px;border-radius:18px;font:800 15px inherit;font-family:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .15s}.mfd-b button:active{transform:scale(.96)}' +
    '.mfd-ok{flex:1.4!important;border:0;color:#fff;background:linear-gradient(135deg,var(--a),var(--b));box-shadow:0 10px 22px color-mix(in srgb,var(--a) 45%,transparent),inset 0 1px 0 rgba(255,255,255,.3)}' +
    '.mfd-no{border:1px solid var(--border,rgba(128,128,128,.3));background:transparent;color:var(--text-sub,#6b7088)}' +
    '.mf-lite #mfd-ov{-webkit-backdrop-filter:none;backdrop-filter:none}.mf-lite #mfd-box,.mf-lite .mfd-ic::before{animation:none}';
  var st = document.createElement('style'); st.id = 'mfd-css'; st.textContent = css; document.head.appendChild(st);

  var ov, box, q = [], busy = false, cur = null;
  function build() {
    ov = document.createElement('div'); ov.id = 'mfd-ov';
    ov.innerHTML = '<div id="mfd-box" role="dialog" aria-modal="true"><div class="mfd-ic"></div><h3 class="mfd-t"></h3><div class="mfd-m"></div><div class="mfd-b"></div></div>';
    document.body.appendChild(ov); box = ov.firstChild;
    ov.addEventListener('click', function (e) { if (e.target === ov && cur && cur.o.confirm) finish(false); });
    document.addEventListener('keydown', function (e) { if (cur && e.key === 'Escape') finish(false); });
  }
  function svg(n) { return '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">' + (P[n] || P.info) + '</svg>'; }
  function render(it) {
    if (!ov) build();
    var o = it.o, type = C[o.type] ? o.type : (o.confirm ? 'ask' : 'info'), c = C[type];
    cur = it; box.style.setProperty('--a', c[0]); box.style.setProperty('--b', c[1]);
    box.querySelector('.mfd-ic').innerHTML = svg(o.icon || DI[type]);
    box.querySelector('.mfd-t').textContent = o.title || (o.confirm ? 'دڵنیایت؟' : (type === 'err' ? 'هەڵەیەک ڕوویدا' : 'ئاگاداری'));
    var m = box.querySelector('.mfd-m'); m.innerHTML = '';
    String(o.message == null ? '' : o.message).split('\n').forEach(function (ln) {
      ln = ln.trim(); if (!ln) return;
      var codeLike = /^[\x20-\x7E]+$/.test(ln) && /[;_=]/.test(ln);
      var e = document.createElement(codeLike ? 'code' : 'p'); e.textContent = ln; m.appendChild(e);
    });
    m.style.display = m.firstChild ? '' : 'none';
    var b = box.querySelector('.mfd-b'); b.innerHTML = '';
    var ok = document.createElement('button'); ok.type = 'button'; ok.className = 'mfd-ok'; ok.textContent = o.ok || (o.confirm ? 'بەڵێ' : 'باشە');
    ok.onclick = function () { finish(true); }; b.appendChild(ok);
    if (o.confirm) { var no = document.createElement('button'); no.type = 'button'; no.className = 'mfd-no'; no.textContent = o.cancel || 'نەخێر'; no.onclick = function () { finish(false); }; b.appendChild(no); }
    ov.classList.add('open'); setTimeout(function () { try { ok.focus(); } catch (e) {} }, 60);
  }
  function finish(v) {
    if (!cur) return; var it = cur; cur = null; ov.classList.remove('open'); busy = false;
    try { it.res(v); } catch (e) {} next();
  }
  function next() { if (busy || !q.length) return; busy = true; render(q.shift()); }
  function show(o) { return new Promise(function (res) { q.push({ o: o, res: res }); if (document.body) next(); else document.addEventListener('DOMContentLoaded', next); }); }
  window.mfDialog = {
    confirm: function (m, o) { o = o || {}; o.message = m; o.confirm = true; return show(o); },
    alert: function (m, o) { o = o || {}; o.message = m; o.confirm = false; return show(o); }
  };
  // every plain alert() in the app now uses the modern dialog too ("title:" on the first line becomes the heading)
  window.__nativeAlert = window.alert;
  window.alert = function (m) {
    var s = String(m == null ? '' : m), lines = s.split('\n'), o = {};
    if (lines.length > 1 && /:\s*$/.test(lines[0])) { o.title = lines[0].replace(/:\s*$/, ''); s = lines.slice(1).join('\n'); }
    var head = (o.title || s);
    if (/هەڵە|نەبوو|نادروست/.test(head)) o.type = 'err';
    window.mfDialog.alert(s, o);
  };
})();
