window.mfParseStorage = window.mfParseStorage || function(key, fallbackJson, useSession) {
  try {
    const store = useSession ? sessionStorage : localStorage;
    const raw = store.getItem(key);
    if (raw == null || raw === '') return JSON.parse(fallbackJson);
    try { return JSON.parse(raw); } catch (e) {
      try { store.setItem(key + '_corrupt_backup_' + Date.now(), raw); store.removeItem(key); } catch (_) {}
      return JSON.parse(fallbackJson);
    }
  } catch (e) {
    try { return JSON.parse(fallbackJson); } catch (_) { return null; }
  }
};
(function(){
  function tick(){
    try {
      const now=new Date();
      const hh=String(now.getHours()).padStart(2,'0'), mm=String(now.getMinutes()).padStart(2,'0'), ss=String(now.getSeconds()).padStart(2,'0');
      const days=['یەکشەممە','دووشەممە','سێشەممە','چوارشەممە','پێنجشەممە','هەینی','شەممە'];
      const d=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
      const t=hh+':'+mm+':'+ss;
      const a=document.getElementById('nb-live-time'); if(a) a.textContent=t;
      const b=document.getElementById('nb-live-date'); if(b) b.textContent=d;
      const c=document.getElementById('nb-live-day'); if(c) c.textContent=days[now.getDay()];
      const m=document.getElementById('mosque-clock'); if(m) m.innerHTML=hh+':'+mm+'<span class="mosque-sec">:'+ss+'</span>';
      const topTime=document.getElementById('tnc-time');
      const topDay=document.getElementById('tnc-day');
      const topDate=document.getElementById('tnc-date');
      const h12=(now.getHours()%12)||12;
      if(topTime) topTime.innerHTML=String(h12).padStart(2,'0')+':'+mm+' <span class=\"tnc-divider\">|</span> <span class=\"tnc-ampm\" id=\"tnc-ampm\">'+(now.getHours()>=12?'PM':'AM')+'</span>';
      if(topDay) topDay.textContent=days[now.getDay()];
      if(topDate) topDate.textContent=String(now.getFullYear())+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0');
      const ah=document.getElementById('tnc-hand-hour'), am=document.getElementById('tnc-hand-minute'), as=document.getElementById('tnc-hand-second');
      if(ah) ah.style.transform='rotate('+(now.getHours()%12*30+now.getMinutes()*0.5)+'deg)';
      if(am) am.style.transform='rotate('+(now.getMinutes()*6+now.getSeconds()*0.1)+'deg)';
      if(as) as.style.transform='rotate('+(now.getSeconds()*6)+'deg)';
      const an=document.getElementById('tnc-analog'); if(an) an.style.setProperty('--tnc-s',String((now.getSeconds()+1)/60*100));
    } catch(e) {}
  }
  tick();
  setInterval(tick,1000);
})();
