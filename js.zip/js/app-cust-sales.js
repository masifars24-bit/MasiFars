(function () {
    var KEY = 'mf_cust_sales', editId = null;
    function $(id) { return document.getElementById(id); }
    function toEn(v) { return String(v || '').replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; }).replace(/[۰-۹]/g, function (d) { return d.charCodeAt(0) - 1776; }).replace(/[٬,\s]/g, '').replace(/٫/g, '.'); }
    function num(v) { var n = parseFloat(toEn(v)); return isFinite(n) ? n : 0; }
    function fmt(n) { return Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 }); }
    function esc(t) { return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function load() { try { var o = JSON.parse(localStorage.getItem(KEY) || '{}'); return (o && typeof o === 'object') ? o : {}; } catch (e) { return {}; } }
    function save(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }
    function pk() { try { return String(currentOrdersPageKey()); } catch (e) { try { return String(notebookState.currentPage); } catch (e2) { return '1'; } } }
    function loadMig() { var o = load(), ch = false, p = pk(); Object.keys(o).forEach(function (id) { if (o[id].page === undefined) { o[id].page = p; ch = true; } }); if (ch) save(o); return o; }
    window.csalesPageTotal = function (key) { var o = loadMig(), t = 0; key = String(key == null ? pk() : key); Object.keys(o).forEach(function (id) { if (String(o[id].page) === key && !o[id].skipDay) t += o[id].total || 0; }); return t; };
    window.csalesPageStats = function (key) { var o = loadMig(), r = { n: 0, count: 0, grams: 0, total: 0 }; key = String(key == null ? pk() : key); Object.keys(o).forEach(function (id) { var x = normRec(o[id]); if (String(x.page) === key) { r.n++; r.count += Number(x.count) || 0; r.grams += (Number(x.kilo) || 0) * 1000 + (Number(x.gram) || 0); r.total += Number(x.total) || 0; } }); return r; };
    function icons() { try { if (window.safeCreateIcons) window.safeCreateIcons(); else if (window.lucide) window.lucide.createIcons(); } catch (e) {} }
    function alertMsg(m) { if (window.mfDialog && window.mfDialog.alert) window.mfDialog.alert(m); else alert(m); }
    function normRec(r) {
        if (r.kilo === undefined) { var k = r.kg || 0; r.kilo = Math.floor(k); r.gram = Math.round((k - r.kilo) * 1000); }
        r.gram = r.gram || 0; r.count = r.count || 0; return r;
    }
    function weightKg() { var k = Math.floor(num($('csales-f-kilo').value)), g = Math.floor(num($('csales-f-gram').value)); return k + g / 1000; }
    window.csalesCalc = function () { $('csales-f-total').textContent = fmt(Math.round(num($('csales-f-price').value) * weightKg())); };
    window.csalesOpen = function (id) {
        var r = id ? load()[id] : null; editId = r ? id : null; if (window.mfCount) mfCount.setState('cs', !(r && r.skipDay));
        $('csales-title').textContent = r ? 'دەستکاریکردنی فرۆشتن' : 'فرۆشتنی نوێ';
        if (r) normRec(r); $('csales-f-name').value = r ? r.name : ''; $('csales-f-price').value = r ? r.price : ''; $('csales-f-count').value = r && r.count ? r.count : ''; $('csales-f-kilo').value = r && r.kilo ? r.kilo : ''; $('csales-f-gram').value = r && r.gram ? r.gram : '';
        csalesCalc(); $('popup-csales').classList.add('active'); icons();
        setTimeout(function () { try { $('csales-f-name').focus(); } catch (e) {} }, 120);
    };
    window.csalesClose = function () { $('popup-csales').classList.remove('active'); editId = null; };
    window.csalesSave = function () {
        var name = $('csales-f-name').value.trim(), price = num($('csales-f-price').value), count = Math.floor(num($('csales-f-count').value)), kilo = Math.floor(num($('csales-f-kilo').value)), gram = Math.floor(num($('csales-f-gram').value));
        kilo += Math.floor(gram / 1000); gram = gram % 1000;
        if (!name) return alertMsg('تکایە ناوی فرۆشیار بنووسە.');
        if (price <= 0) return alertMsg('تکایە نرخ دیاری بکە.');
        if (kilo + gram <= 0) return alertMsg('تکایە کیلۆ یان گرام بنووسە.');
        var o = load(), id = editId || ('s' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5));
        o[id] = { name: name, price: price, count: count, kilo: kilo, gram: gram, total: Math.round(price * (kilo + gram / 1000)), at: (o[id] && o[id].at) || Date.now(), page: (o[id] && o[id].page !== undefined) ? o[id].page : pk() };
        if (window.mfCount && mfCount.skip('cs')) o[id].skipDay = true;
        save(o); csalesClose(); csalesRender();
    };
    window.csalesDelete = function (id) {
        var run = function () { var o = load(); delete o[id]; save(o); csalesRender(); };
        if (window.mfDialog && window.mfDialog.confirm) window.mfDialog.confirm('ئەم فرۆشتنە دەسڕدرێتەوە. دڵنیایت؟', { title: 'سڕینەوە', ok: 'سڕینەوە', cancel: 'پاشگەزبوونەوە' }).then(function (ok) { if (ok) run(); });
        else if (confirm('ئەم فرۆشتنە دەسڕدرێتەوە. دڵنیایت؟')) run();
    };
    window.csalesRender = function () {
        var list = $('csales-list'); if (!list) return;
        var o = loadMig(), cur = pk(), q = ($('csales-search') ? $('csales-search').value : '').trim().toLowerCase();
        var all = Object.keys(o).map(function (id) { var r = normRec(o[id]); r.id = id; return r; }).filter(function (r) { return String(r.page) === cur; }).sort(function (a, b) { return (b.at || 0) - (a.at || 0); });
        var shown = q ? all.filter(function (r) { return String(r.name).toLowerCase().indexOf(q) > -1; }) : all;
        var sum = 0, tg = 0; all.forEach(function (r) { sum += r.total || 0; tg += (r.kilo || 0) * 1000 + (r.gram || 0); });
        $('csales-sum-val').textContent = fmt(sum); $('csales-n').textContent = all.length; $('csales-kg').textContent = Math.floor(tg / 1000) + ' کیلۆ و ' + (tg % 1000) + ' گرام';
        $('csales-count-label').textContent = all.length ? (all.length + ' فرۆشتن') : 'هیچ فرۆشتنێک نییە';
        $('csales-empty').style.display = shown.length ? 'none' : '';
        list.innerHTML = shown.map(function (r) {
            var d = new Date(r.at || Date.now()), ds = d.toLocaleDateString('en-GB'), tm = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
            function t(ic, lb, v, tone) { return '<div class="cs2-t" style="--t:' + tone + '"><i data-lucide="' + ic + '"></i><span>' + lb + '</span><b>' + fmt(v) + '</b></div>'; }
            return '<div class="cs2"><div class="cs2-top"><div class="cs2-ico"><i data-lucide="banknote"></i></div>' +
                '<div class="cs2-info"><b>' + esc(r.name) + '</b><small><i data-lucide="clock"></i>' + ds + ' · ' + tm + '</small></div>' +
                '<div class="cs2-tot"><b>' + fmt(r.total) + '</b><em>د.ع</em></div>' +
                '<div class="cs2-acts"><button type="button" onclick="csalesOpen(\'' + r.id + '\')" aria-label="دەستکاری"><i data-lucide="pencil"></i></button><button type="button" class="del" onclick="csalesDelete(\'' + r.id + '\')" aria-label="سڕینەوە"><i data-lucide="trash-2"></i></button></div></div>' +
                '<div class="cs2-grid">' + t('package', 'ژمارە', r.count, 'var(--c-7)') + t('scale', 'کیلۆ', r.kilo, 'var(--c-11)') + t('weight', 'گرام', r.gram, 'var(--c-5)') + t('tag', 'نرخ/کیلۆ', r.price, 'var(--c-4)') + '</div></div>';
        }).join('');
        icons();
    };
    $('popup-csales').addEventListener('click', function (e) { if (e.target === this) csalesClose(); });
    setTimeout(csalesRender, 400);
})();
