(function () {
    function qs(r, sel) { return r.querySelector(sel); }
    var sheet = null, current = null;
    function buildSheet() {
        if (sheet) return sheet;
        sheet = document.createElement('div');
        sheet.id = 'popup-note-manage-add';
        sheet.className = 'custom-popup-overlay';
        sheet.style.zIndex = '3800';
        sheet.innerHTML = '<div class="order-builder-window order-status-sheet">'
            + '<div class="order-builder-header"><h3 id="nm-sheet-title">زیادکردن</h3>'
            + '<button type="button" class="order-builder-close" id="nm-sheet-close"><i data-lucide="x"></i></button></div>'
            + '<div class="order-builder-body"><div class="ob-section">'
            + '<label id="nm-sheet-label">ناو</label>'
            + '<div class="ob-icon-field"><i data-lucide="pencil-line"></i><input type="text" id="nm-sheet-input" autocomplete="off"></div>'
            + '<button type="button" class="ob-create-btn" id="nm-sheet-save" style="margin-top:16px;"><i data-lucide="plus"></i> زیادکردن</button>'
            + '</div></div></div>';
        document.body.appendChild(sheet);
        var close = function () { sheet.classList.remove('active'); };
        sheet.addEventListener('click', function (e) { if (e.target === sheet) close(); });
        qs(sheet, '#nm-sheet-close').onclick = close;
        var input = qs(sheet, '#nm-sheet-input');
        var save = function () {
            var v = input.value.trim();
            if (!v || !current) return;
            current.input.value = v;
            current.btn.click();
            input.value = '';
            close();
        };
        qs(sheet, '#nm-sheet-save').onclick = save;
        input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); save(); } });
        if (window.safeCreateIcons) safeCreateIcons();
        return sheet;
    }
    function openAdd(info) {
        current = info;
        var sh = buildSheet();
        qs(sh, '#nm-sheet-title').textContent = info.title;
        qs(sh, '#nm-sheet-label').textContent = info.title;
        var inp = qs(sh, '#nm-sheet-input');
        inp.placeholder = info.input.placeholder || '';
        inp.value = '';
        sh.classList.add('active');
        setTimeout(function () { inp.focus(); }, 120);
    }
    function enhance(box) {
        if (box.classList.contains('nm2')) return;
        var header = qs(box, '.note-manage-header'), row = qs(box, '.note-manage-add-row'), list = qs(box, '.note-manage-list');
        if (!header || !row || !list) return;
        var input = qs(row, 'input'), btn = qs(row, 'button');
        if (!input || !btn) return;
        var title = (qs(header, '.note-manage-title') || {}).textContent || 'تێبینی';
        var sub = (qs(header, '.note-manage-sub') || {}).textContent || '';
        var iconEl = qs(header, '.note-manage-icon');
        box.classList.add('nm2');
        var top = document.createElement('div');
        top.className = 'nm-head';
        top.innerHTML = '<div><h3 class="orders-panel-title"></h3><p class="orders-panel-sub"></p></div>'
            + '<button type="button" class="order-add-fab" title="زیادکردن" aria-label="زیادکردن"><i data-lucide="plus"></i></button>';
        qs(top, '.orders-panel-title').textContent = title;
        box.insertBefore(top, header);
        var count = qs(top, '.orders-panel-sub');
        var info = { title: title, input: input, btn: btn };
        qs(top, '.order-add-fab').onclick = function () { openAdd(info); };
        var upd = function () { count.textContent = list.querySelectorAll('.note-manage-pill').length + ' دانە'; };
        new MutationObserver(upd).observe(list, { childList: true });
        upd();
    }
    function run() {
        document.querySelectorAll('.note-manage-box').forEach(enhance);
        if (window.safeCreateIcons) safeCreateIcons();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run); else run();
})();
