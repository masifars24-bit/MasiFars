(function () {
  'use strict';
  var curId = null, timer = null, confirmTimer = null, confirming = false;
  function $(id) { return document.getElementById(id); }
  function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]; }); }
  function money(n) { return (Number(n) || 0).toLocaleString('en-US') + ' د.ع'; }
  function pad(n) { return String(n).padStart(2, '0'); }
  function todayStr() { return new Date().toLocaleDateString('en-CA'); }
  function fmtTime(ts) { if (!ts) return '—'; var d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function fmtDur(ms) { var t = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60; return (h ? h + ':' : '') + pad(m) + ':' + pad(sec); }
  function getC() { return (typeof couriersData !== 'undefined' ? couriersData : []).find(function (x) { return x.id === curId; }) || null; }
  function findOrder(c) {
    if (!c || !c.currentOrderId) return null;
    return (ordersByPage[String(c.currentOrderPage)] || []).find(function (o) { return o.id == c.currentOrderId; }) || null;
  }
  function feeOf(o) { var d = o && o.draft && o.draft.delivery; return d && d.enabled ? (Number(d.price) || 0) : 0; }
  function collectOf(o) {
    if (!o) return 0;
    if (o.debtType === 'debt-full') return 0;
    if (o.debtType === 'debt-partial') return Math.max(0, (o.total || 0) - (Number(o.debtRemaining) || 0));
    return o.total || 0;
  }
  function payLabel(o) {
    if (!o) return '—';
    if (o.debtType === 'debt-full') return 'هەمووی بەقەرز — پارە وەرناگیرێت';
    if (o.debtType === 'debt-partial') return 'بەشێکی بەقەرز — ' + money(collectOf(o)) + ' وەربگیرێت';
    return 'نەقد — وەرگرتنی تەواوی بڕەکە';
  }
  function tile(icon, label, valHtml, cls) { return '<div class="mf-ct-tile ' + (cls || '') + '"><label><i data-lucide="' + icon + '"></i>' + label + '</label><div>' + valHtml + '</div></div>'; }
  function telHref(p) { return 'tel:' + String(p || '').replace(/[^0-9+]/g, ''); }

  function todayStats(c) {
    var t = todayStr(), list = (c.deliveryHistory || []).filter(function (h) { return h.date === t && h.status === 'success'; });
    var fees = 0, coll = 0, total = 0;
    list.forEach(function (h) { fees += Number(h.fee) || 0; coll += (h.collected != null ? Number(h.collected) : Number(h.amount)) || 0; total += Number(h.amount) || 0; });
    return { list: list, count: list.length, fees: fees, collected: coll, total: total };
  }

  /* ================= Modern map engine (MapLibre GL + OpenFreeMap vector tiles) ================= */
  var mapSt = null, savingPin = false;
  var ML_SRC = [
    { js: 'https://cdnjs.cloudflare.com/ajax/libs/maplibre-gl/4.7.1/maplibre-gl.js', css: 'https://cdnjs.cloudflare.com/ajax/libs/maplibre-gl/4.7.1/maplibre-gl.css' },
    { js: 'https://cdn.jsdelivr.net/npm/maplibre-gl@4.7.1/dist/maplibre-gl.js', css: 'https://cdn.jsdelivr.net/npm/maplibre-gl@4.7.1/dist/maplibre-gl.css' },
    { js: 'https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js', css: 'https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.css' }
  ];
  var STYLES = { clean: 'https://tiles.openfreemap.org/styles/positron', street: 'https://tiles.openfreemap.org/styles/liberty' };
  var DEF_CENTER = [36.1911, 44.0092];
  function isDark() { return document.documentElement.getAttribute('data-theme') === 'dark'; }
  function accent() { var v = ''; try { v = getComputedStyle(document.documentElement).getPropertyValue('--c-1').trim(); } catch (e) { } return /^#[0-9a-f]{6}$/i.test(v) ? v : '#6366f1'; }
  function icons() { if (typeof safeCreateIcons === 'function') safeCreateIcons(); }
  function loadMap(ok, fail) {
    if (window.maplibregl && maplibregl.Map) { ok(); return; }
    var done = false, i = 0;
    var to = setTimeout(function () { if (!done) { done = true; fail('lib'); } }, 16000);
    (function next() {
      if (done) return;
      if (i >= ML_SRC.length) { done = true; clearTimeout(to); fail('lib'); return; }
      var src = ML_SRC[i++];
      var old = document.getElementById('mf-ml-css'); if (old) old.remove();
      var l = document.createElement('link'); l.id = 'mf-ml-css'; l.rel = 'stylesheet'; l.href = src.css; document.head.appendChild(l);
      var sc = document.createElement('script'); sc.src = src.js;
      sc.onload = function () { if (!done && window.maplibregl) { done = true; clearTimeout(to); ok(); } else next(); };
      sc.onerror = function () { try { sc.remove(); } catch (e) { } next(); };
      document.head.appendChild(sc);
    })();
  }
  function geoGet(a) { try { return (JSON.parse(localStorage.getItem('mf_geo_cache') || '{}'))[a] || null; } catch (e) { return null; } }
  function geoSet(a, v) { try { var m = JSON.parse(localStorage.getItem('mf_geo_cache') || '{}'); m[a] = v; localStorage.setItem('mf_geo_cache', JSON.stringify(m)); } catch (e) { } }
  function geocode(a, cb) {
    var c = geoGet(a); if (c) { cb(c); return; }
    fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=iq&accept-language=ckb,ar,en&q=' + encodeURIComponent(a))
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j && j[0]) { var v = { lat: +j[0].lat, lng: +j[0].lon }; geoSet(a, v); cb(v); } else cb(null); })
      .catch(function () { cb(null); });
  }
  function pinHtml() {
    return '<div class="mf-pin"><i class="r1"></i><i class="r2"></i><svg viewBox="0 0 44 56" width="44" height="56"><defs><linearGradient id="mfpg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--c-1,#6366f1)"/><stop offset="1" style="stop-color:var(--c-2,#a855f7)"/></linearGradient></defs><path d="M22 54C22 54 4 34 4 20a18 18 0 0 1 36 0c0 14-18 34-18 34z" fill="url(#mfpg)" stroke="#fff" stroke-width="2.5"/><circle cx="22" cy="20" r="8" fill="#fff"/><circle cx="22" cy="20" r="3.6" style="fill:var(--c-1,#6366f1)"/></svg></div>';
  }
  function setInfo(st, html) { var b = st.el.querySelector('.mf-ct-mapx-info'); if (b) { b.innerHTML = html || ''; b.style.display = html ? 'flex' : 'none'; icons(); } }
  function mapSlotHtml(addr) {
    var h = '<div id="mf-ct-mapslot"></div>';
    h += '<div class="mf-ct-links"><button type="button" class="mf-ct-link" id="mf-ct-pin"><i data-lucide="crosshair"></i>دیاریکردنی شوێن</button>' +
      '<button type="button" class="mf-ct-link" id="mf-ct-copy"><i data-lucide="copy"></i>کۆپی ناونیشان</button>' +
      (addr ? '<a class="mf-ct-link" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(addr) + '&travelmode=driving"><i data-lucide="external-link"></i>Google Maps</a>' : '') + '</div>';
    return h;
  }
  function destroyMap() { if (mapSt) { try { if (mapSt.map) mapSt.map.remove(); } catch (e) { } try { mapSt.el.remove(); } catch (e) { } mapSt = null; } }
  function fallbackIframe(st, why) {
    if (mapSt !== st) return;
    try { if (st.map) st.map.remove(); } catch (e) { } st.map = null;
    var cv = st.el.querySelector('.mf-ct-mapx-canvas');
    cv.innerHTML = st.addr ? '<iframe title="نەخشە" src="' + esc('https://maps.google.com/maps?q=' + encodeURIComponent(st.addr) + '&z=16&output=embed') + '" loading="lazy" allowfullscreen style="position:absolute;inset:0;width:100%;height:100%;border:0"></iframe>' : '';
    var ld = st.el.querySelector('.mf-ct-mapx-load'); if (ld) ld.remove();
    setInfo(st, '<span class="mf-ct-mchip warn"><i data-lucide="wifi-off"></i>' + (why === 'tiles' ? 'داتای نەخشەی ستایلدار بار نەبوو — نەخشەی Google پیشان دەدرێت' : why === 'webgl' ? 'ئامێرەکەت WebGL پشتگیری ناکات — نەخشەی Google پیشان دەدرێت' : 'کتێبخانەی نەخشە بار نەبوو — نەخشەی Google پیشان دەدرێت') + '</span>');
  }
  function mountMap(addr, o) {
    var slot = $('mf-ct-mapslot'); if (!slot) return;
    var dl = (o && o.draft && o.draft.delivery) || {};
    var key = (addr || '') + '|' + (dl.lat == null ? '' : dl.lat) + '|' + (dl.lng == null ? '' : dl.lng) + '|' + (isDark() ? 'd' : 'l');
    if (mapSt && mapSt.key === key) { slot.appendChild(mapSt.el); var mm = mapSt; setTimeout(function () { try { if (mm.map) mm.map.resize(); } catch (e) { } }, 60); return; }
    destroyMap();
    var el = document.createElement('div'); el.className = 'mf-ct-mapx';
    el.innerHTML = '<div class="mf-ct-mapx-canvas"></div><div class="mf-ct-mapx-load"><span></span><small>نەخشە ئامادە دەکرێت…</small></div>' +
      (addr ? '<div class="mf-ct-mapx-addr"><i data-lucide="map-pin"></i><span>' + esc(addr) + '</span></div>' : '') +
      '<div class="mf-ct-mapx-ctl"><button type="button" data-a="in" aria-label="+"><i data-lucide="plus"></i></button><button type="button" data-a="out" aria-label="-"><i data-lucide="minus"></i></button><button type="button" data-a="route" aria-label="ڕێگا"><i data-lucide="navigation"></i></button><button type="button" data-a="layers" aria-label="ستایل"><i data-lucide="layers"></i></button><button type="button" data-a="fs" aria-label="تەواوشاشە"><i data-lucide="maximize-2"></i></button></div>' +
      '<div class="mf-ct-mapx-info" style="display:none"></div>';
    slot.appendChild(el);
    var mode = 'clean'; try { mode = localStorage.getItem('mf_map_mode') || 'clean'; } catch (e) { }
    if (!STYLES[mode]) mode = 'clean';
    var st = mapSt = { key: key, el: el, map: null, marker: null, pin: false, route: null, me: null, addr: addr, mode: mode };
    icons();
    loadMap(function () {
      if (mapSt !== st) return;
      if (dl.lat != null && dl.lng != null) { build(st, +dl.lat, +dl.lng, false); return; }
      if (!addr) { build(st, DEF_CENTER[0], DEF_CENTER[1], true); return; }
      geocode(addr, function (g) { if (mapSt !== st) return; if (g) build(st, g.lat, g.lng, false); else build(st, DEF_CENTER[0], DEF_CENTER[1], true); });
    }, function (why) { fallbackIframe(st, why || 'lib'); });
  }
  /* dark mode: CSS-invert the vector canvas; pre-invert overlay colors so they look right */
  function useInvert(st) { return isDark() && st.mode === 'clean'; }
  function fcolor(hex, inv) {
    if (!inv) return hex;
    var r = 255 - parseInt(hex.slice(1, 3), 16), g = 255 - parseInt(hex.slice(3, 5), 16), b = 255 - parseInt(hex.slice(5, 7), 16);
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, h = 0, sa = 0, d = mx - mn;
    if (d) { sa = l > .5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    h = (h + .5) % 1;
    function f(p, q, t) { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < .5) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; }
    var q = l < .5 ? l * (1 + sa) : l + sa - l * sa, pp = 2 * l - q, R = f(pp, q, h + 1 / 3), G = f(pp, q, h), B = f(pp, q, h - 1 / 3);
    return '#' + [R, G, B].map(function (v) { return ('0' + Math.round(v * 255).toString(16)).slice(-2); }).join('');
  }
  function syncTheme(st) { st.el.classList.toggle('inv', useInvert(st)); }
  function drawRoute(st) {
    var m = st.map; if (!m || !st.route) return;
    var inv = useInvert(st);
    try {
      ['mf-route', 'mf-route-case'].forEach(function (i) { if (m.getLayer(i)) m.removeLayer(i); });
      if (m.getSource('mf-route')) m.removeSource('mf-route');
      m.addSource('mf-route', { type: 'geojson', data: { type: 'Feature', geometry: { type: 'LineString', coordinates: st.route } } });
      m.addLayer({ id: 'mf-route-case', type: 'line', source: 'mf-route', layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': fcolor(isDark() ? '#0b1020' : '#ffffff', inv), 'line-width': 11, 'line-opacity': .95 } });
      m.addLayer({ id: 'mf-route', type: 'line', source: 'mf-route', layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': fcolor(accent(), inv), 'line-width': 6 } });
    } catch (e) { }
  }
  function build(st, lat, lng, approx) {
    var el = st.el, cv = el.querySelector('.mf-ct-mapx-canvas'), map;
    try {
      map = st.map = new maplibregl.Map({ container: cv, style: STYLES[st.mode], center: [lng, lat], zoom: approx ? 11 : 16, maxZoom: 20, attributionControl: false, dragRotate: false, pitchWithRotate: false, touchPitch: false, fadeDuration: 150 });
    } catch (e) { fallbackIframe(st, 'webgl'); return; }
    try { map.touchZoomRotate.disableRotation(); } catch (e) { }
    map.addControl(new maplibregl.AttributionControl({ compact: true, customAttribution: 'OpenFreeMap © OpenMapTiles · Data from OpenStreetMap' }), 'bottom-left');
    syncTheme(st);
    var pe = document.createElement('div'); pe.className = 'mf-pin-wrap'; pe.innerHTML = pinHtml();
    st.marker = new maplibregl.Marker({ element: pe, anchor: 'bottom' }).setLngLat([lng, lat]).addTo(map);
    st.approx = approx;
    var loaded = false, errs = 0;
    map.on('load', function () { loaded = true; var ld = el.querySelector('.mf-ct-mapx-load'); if (ld) ld.remove(); });
    map.on('error', function () { errs++; if (!loaded && errs >= 3) fallbackIframe(st, 'tiles'); });
    var checked = false;
    map.on('idle', function () {
      if (checked) return; checked = true;
      setTimeout(function () {
        if (mapSt !== st || !st.map) return;
        var n = 0; try { n = map.queryRenderedFeatures().length; } catch (e) { n = 1; }
        if (n === 0 && (errs > 0 || !loaded)) fallbackIframe(st, 'tiles');
      }, 1800);
    });
    setTimeout(function () { if (mapSt === st && st.map && !loaded) fallbackIframe(st, 'tiles'); }, 12000);
    setTimeout(function () { var ld = el.querySelector('.mf-ct-mapx-load'); if (ld) ld.remove(); }, 9000);
    map.on('click', function (e) { if (st.pin) setPoint(st, e.lngLat); });
    el.querySelector('.mf-ct-mapx-ctl').addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b || !st.map) return; var a = b.getAttribute('data-a');
      if (a === 'in') map.zoomIn(); else if (a === 'out') map.zoomOut();
      else if (a === 'route') routeFromMe(st);
      else if (a === 'layers') cycleStyle(st);
      else if (a === 'fs') { var full = el.classList.toggle('full'); b.innerHTML = '<i data-lucide="' + (full ? 'minimize-2' : 'maximize-2') + '"></i>'; icons(); setTimeout(function () { map.resize(); map.easeTo({ center: st.marker.getLngLat(), duration: 250 }); }, 60); }
    });
    if (approx) { setPinMode(st, true); setInfo(st, '<span class="mf-ct-mchip warn"><i data-lucide="map-pin-off"></i>ناونیشانەکە بە خۆکار نەدۆزرایەوە — لەسەر نەخشە شوێنەکە دیاری بکە</span>'); }
  }
  function cycleStyle(st) {
    var order = ['clean', 'street'], nx = order[(order.indexOf(st.mode) + 1) % order.length];
    st.mode = nx; try { localStorage.setItem('mf_map_mode', nx); } catch (e) { }
    syncTheme(st);
    st.map.once('style.load', function () { drawRoute(st); });
    st.map.setStyle(STYLES[nx]);
    setInfo(st, '<span class="mf-ct-mchip"><i data-lucide="layers"></i>' + (nx === 'clean' ? 'ستایلی ئارام' : 'ستایلی وردی شەقام') + '</span>');
    setTimeout(function () { if (mapSt === st) setInfo(st, ''); }, 1800);
  }
  function setPinMode(st, on) {
    st.pin = !!on; st.el.classList.toggle('pinning', st.pin);
    var b = $('mf-ct-pin'); if (b) b.classList.toggle('on', st.pin);
    if (st.pin && !st.approx) setInfo(st, '<span class="mf-ct-mchip"><i data-lucide="crosshair"></i>کلیک لەسەر نەخشە بکە بۆ دیاریکردنی شوێنی ڕاستەقینەی کڕیار</span>');
    else if (!st.pin) setInfo(st, '');
  }
  function setPoint(st, ll) {
    st.marker.setLngLat([ll.lng, ll.lat]); st.map.easeTo({ center: [ll.lng, ll.lat], duration: 300 }); st.approx = false;
    var c = getC(), o = findOrder(c);
    if (o && o.draft && o.draft.delivery) {
      o.draft.delivery.lat = +ll.lat.toFixed(6); o.draft.delivery.lng = +ll.lng.toFixed(6);
      if (st.addr) geoSet(st.addr, { lat: o.draft.delivery.lat, lng: o.draft.delivery.lng });
      savingPin = true; try { persistOrders(); } catch (e) { } savingPin = false;
      st.key = (st.addr || '') + '|' + o.draft.delivery.lat + '|' + o.draft.delivery.lng + '|' + (isDark() ? 'd' : 'l');
    }
    setPinMode(st, false);
    setInfo(st, '<span class="mf-ct-mchip ok"><i data-lucide="check-circle-2"></i>شوێنی کڕیار پاشەکەوت کرا</span>');
    setTimeout(function () { if (mapSt === st) setInfo(st, ''); }, 2600);
  }
  function hav(a, b) { var R = 6371, t = Math.PI / 180, dLa = (b[1] - a[1]) * t, dLo = (b[0] - a[0]) * t, x = Math.sin(dLa / 2) * Math.sin(dLa / 2) + Math.cos(a[1] * t) * Math.cos(b[1] * t) * Math.sin(dLo / 2) * Math.sin(dLo / 2); return 2 * R * Math.asin(Math.sqrt(x)); }
  function fit(st, pts) { var b = new maplibregl.LngLatBounds(pts[0], pts[0]); pts.forEach(function (p) { b.extend(p); }); st.map.fitBounds(b, { padding: 64, maxZoom: 17, duration: 600 }); }
  function routeFromMe(st) {
    if (!st.map || !navigator.geolocation) { setInfo(st, '<span class="mf-ct-mchip warn"><i data-lucide="map-pin-off"></i>ئامێرەکەت پشتگیری شوێن ناکات</span>'); return; }
    setInfo(st, '<span class="mf-ct-mchip"><i data-lucide="loader"></i>خەریکی دۆزینەوەی شوێنی تۆم…</span>');
    navigator.geolocation.getCurrentPosition(function (pos) {
      if (mapSt !== st || !st.map) return;
      var me = [pos.coords.longitude, pos.coords.latitude], dm = st.marker.getLngLat(), dest = [dm.lng, dm.lat];
      if (st.me) { try { st.me.remove(); } catch (e) { } }
      var dot = document.createElement('div'); dot.className = 'mf-me-dot';
      st.me = new maplibregl.Marker({ element: dot }).setLngLat(me).addTo(st.map);
      var fb = function () {
        st.route = [me, dest]; drawRoute(st); fit(st, [me, dest]);
        setInfo(st, '<span class="mf-ct-mchip"><i data-lucide="route"></i><b>' + hav(me, dest).toFixed(1) + '</b> کم (هێڵی ڕاست)</span>');
      };
      fetch('https://router.project-osrm.org/route/v1/driving/' + me[0] + ',' + me[1] + ';' + dest[0] + ',' + dest[1] + '?overview=full&geometries=geojson')
        .then(function (r) { return r.json(); })
        .then(function (j) {
          var r0 = j && j.routes && j.routes[0]; if (!r0) throw 0; if (mapSt !== st) return;
          st.route = r0.geometry.coordinates; drawRoute(st); fit(st, st.route.length > 1 ? [me, dest].concat(st.route.filter(function (_, i) { return i % 8 === 0; })) : [me, dest]);
          setInfo(st, '<span class="mf-ct-mchip"><i data-lucide="route"></i><b>' + (r0.distance / 1000).toFixed(1) + '</b> کم</span><span class="mf-ct-mchip"><i data-lucide="timer"></i><b>' + Math.max(1, Math.round(r0.duration / 60)) + '</b> خولەک</span>');
        }).catch(fb);
    }, function () { setInfo(st, '<span class="mf-ct-mchip warn"><i data-lucide="map-pin-off"></i>ڕێگەپێدانی شوێن (GPS) پێویستە</span>'); }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 20000 });
  }

  function render() {
    var c = getC(); if (!c) return;
    var meta = (typeof COURIER_STATUS_META !== 'undefined' && COURIER_STATUS_META[c.status]) || { color: '#94a3b8', label: '—', icon: 'moon' };
    var view = $('view-courier-task'); view.style.setProperty('--ct', meta.color);
    var chip = $('mf-ct-chip'); chip.style.setProperty('--ct', meta.color);
    chip.innerHTML = '<i data-lucide="' + meta.icon + '"></i>' + esc(meta.label);
    var o = findOrder(c), d = (o && o.draft) || {}, dl = d.delivery || {};
    var addr = (dl.location || c.currentOrderLocation || '').trim();
    var start = c.assignedAt || (o && o.createdAtTs) || 0;
    var veh = c.vehicle || {}, vehTxt = [veh.name, veh.color, veh.plate].filter(Boolean).join(' · ');
    var st = todayStats(c), pend = o ? collectOf(o) : 0;
    var h = '';

    h += '<div class="mf-ct-hero"><div class="mf-ct-av">' + (typeof supplyIconHtml === 'function' ? supplyIconHtml(c.icon) : '<i data-lucide="user-round"></i>') + '</div>' +
      '<div class="mf-ct-hero-info"><div class="mf-ct-name">' + esc(c.name || 'گەیەنەر') + '</div><div class="mf-ct-sub">' +
      (c.phone ? '<span><i data-lucide="phone"></i><bdi dir="ltr">' + esc(c.phone) + '</bdi></span>' : '') +
      (vehTxt ? '<span><i data-lucide="car"></i>' + esc(vehTxt) + '</span>' : '') + '</div></div>' +
      '<div class="mf-ct-timer"><b data-ct-elapsed>' + (start ? fmtDur(Date.now() - start) : '--:--') + '</b><small>ماوەی ئەرک</small></div></div>';

    h += '<div class="mf-ct-sec"><div class="mf-ct-sec-h"><i data-lucide="receipt-text"></i>کارتی داواکاری' + (o ? '<em>#' + esc(o.id) + '</em>' : '') + '</div>';
    if (o && typeof renderOrderCard === 'function') h += '<div class="mf-ct-ocwrap" id="mf-ct-oc">' + renderOrderCard(o) + '</div>';
    else h += '<div class="mf-ct-empty">کارتی ئەم داواکارییە نەدۆزرایەوە (ڕەنگە سڕابێتەوە). ناونیشانی گەیاندن لە خوارەوە ماوە.</div>';
    h += '</div>';

    h += '<div class="mf-ct-sec"><div class="mf-ct-sec-h"><i data-lucide="map"></i>نەخشەی گەیاندن</div>' + mapSlotHtml(addr) + '</div>';

    h += '<div class="mf-ct-sec"><div class="mf-ct-sec-h"><i data-lucide="clipboard-list"></i>زانیاری ئەرکەکە</div><div class="mf-ct-grid">';
    h += tile('hash', 'ژمارەی داواکاری', o ? '<span class="num">#' + esc(o.id) + '</span>' : '—');
    h += tile('package', 'ژمارەی بابەتەکان', o ? esc((o.lines || []).length) + ' بابەت' : '—');
    h += tile('user', 'ناوی کڕیار', esc(d.customerName || 'بێ ناو'));
    h += tile('phone', 'مۆبایلی کڕیار', d.customerPhone ? '<a href="' + telHref(d.customerPhone) + '">' + esc(d.customerPhone) + '</a>' : 'تۆمار نەکراوە');
    h += tile('map-pin', 'ناونیشانی گەیاندن', esc(addr || 'دیارینەکراوە'), 'wide hl');
    h += tile('calendar-clock', 'کاتی داواکاری', o && o.createdAt ? esc(o.createdAt.day + ' · ' + o.createdAt.date + ' · ' + String(o.createdAt.time).slice(0, 5)) : '—', 'wide');
    h += tile('user-check', 'ڕادەستکرا بە گەیەنەر', start ? esc(fmtTime(start)) : '—');
    h += tile(c.status === 'returning' ? 'rotate-ccw' : 'navigation', c.status === 'returning' ? 'کاتی گەڕانەوە' : 'دۆخی ئێستا', c.status === 'returning' ? esc(fmtTime(c.returningAt)) : esc(meta.label));
    if (o) {
      h += tile('utensils', 'نرخی خواردن', esc(money((o.total || 0) - feeOf(o))));
      h += tile('truck', 'کرێی گەیاندن', esc(money(feeOf(o))));
      h += tile('wallet', 'کۆی گشتی داواکاری', '<span class="num">' + esc(money(o.total)) + '</span>', 'hl');
      h += tile('banknote', 'دۆخی پارە', esc(payLabel(o)), 'hl');
      if (d.note && d.note.enabled && d.note.text) h += tile('sticky-note', 'تێبینی', esc(d.note.text), 'wide');
    }
    h += '</div></div>';

    h += '<div class="mf-ct-sec"><div class="mf-ct-sec-h"><i data-lucide="calendar-check"></i>گەیاندنی ئەمرۆ<em>' + esc(todayStr()) + '</em></div>' +
      '<div class="mf-ct-sum">' +
      '<div class="mf-ct-stat" style="--k:#3b82f6"><i data-lucide="truck"></i><b>' + st.count + '</b><small>گەیاندنی تەواوکراو</small></div>' +
      '<div class="mf-ct-stat" style="--k:#16a34a"><i data-lucide="trending-up"></i><b>' + esc(money(st.fees)) + '</b><small>دەستکەوتی ئەمرۆ (کرێی گەیاندن)</small></div>' +
      '<div class="mf-ct-stat" style="--k:#f59e0b"><i data-lucide="wallet"></i><b>' + esc(money(st.collected)) + '</b><small>پارەی لای گەیەنەر ئەمرۆ</small></div></div>';
    if (o) h += '<div class="mf-ct-note"><span>چاوەڕوانکراو لەم ئەرکە (وەرگرتن لە کڕیار)</span><b>' + esc(money(pend)) + '</b></div>' +
      '<div class="mf-ct-note"><span>کۆی پارەی لای گەیەنەر دوای ئەم ئەرکە</span><b>' + esc(money(st.collected + pend)) + '</b></div>';
    h += '<div class="mf-ct-sec-h" style="margin-top:14px"><i data-lucide="list-checks"></i>وردەکاری گەیاندنەکانی ئەمرۆ<em>' + st.count + ' گەیاندن</em></div>';
    if (!st.list.length) h += '<div class="mf-ct-empty">هێشتا هیچ گەیاندنێک ئەمرۆ تەواو نەکراوە.</div>';
    else h += '<div class="mf-ct-list">' + st.list.map(function (x) {
      var coll = x.collected != null ? x.collected : x.amount;
      return '<div class="mf-ct-row"><div class="mf-ct-row-t">' + esc(x.time || '') + '<small>' + esc(x.code || '') + '</small></div>' +
        '<div class="mf-ct-row-m"><b>' + esc(x.customerName || 'کڕیار') + '</b><span>' + esc(x.dropoff || 'ناونیشان نیە') + (x.durationMin ? ' · ' + x.durationMin + ' خولەک' : '') + '</span></div>' +
        '<div class="mf-ct-row-a">' + esc(money(coll)) + (x.fee ? '<small>+ ' + esc(money(x.fee)) + '</small>' : '') + '</div></div>';
    }).join('') + '</div>';
    h += '</div>';

    $('mf-ct-body').innerHTML = h;
    mountMap(addr, o);

    var bar = '';
    if (d.customerPhone) bar += '<a class="mf-ct-act call" href="' + telHref(d.customerPhone) + '"><i data-lucide="phone"></i></a>';
    if (c.status === 'busy') bar += '<button type="button" class="mf-ct-act ret" id="mf-ct-ret"><i data-lucide="rotate-ccw"></i>گەڕایەوە</button>';
    else if (c.status === 'returning') bar += '<button type="button" class="mf-ct-act fin' + (confirming ? ' confirm' : '') + '" id="mf-ct-fin"><i data-lucide="check-circle-2"></i>' + (confirming ? 'دڵنیایت؟ دووبارە کلیک بکە' : 'تەواوبوو') + '</button>';
    $('mf-ct-bar').innerHTML = bar;

    var oc = $('mf-ct-oc'); if (oc) { var card = oc.querySelector('.oc'); if (card) card.classList.add('oc-open'); }
    bind();
    if (typeof safeCreateIcons === 'function') safeCreateIcons();
  }

  function bind() {
    var pb = $('mf-ct-pin');
    if (pb) { if (mapSt && mapSt.pin) pb.classList.add('on'); pb.onclick = function () { if (mapSt && mapSt.map) setPinMode(mapSt, !mapSt.pin); }; }
    var cp = $('mf-ct-copy');
    if (cp) cp.onclick = function () {
      var c = getC(), o = findOrder(c), a = ((o && o.draft && o.draft.delivery && o.draft.delivery.location) || (c && c.currentOrderLocation) || '');
      try { navigator.clipboard.writeText(a); } catch (e) { }
      cp.innerHTML = '<i data-lucide="check"></i>کۆپی کرا'; icons();
    };
    var ret = $('mf-ct-ret');
    if (ret) ret.onclick = function () { setCourierStatus(curId, 'returning'); render(); };
    var fin = $('mf-ct-fin');
    if (fin) fin.onclick = function () {
      if (!confirming) { confirming = true; render(); clearTimeout(confirmTimer); confirmTimer = setTimeout(function () { confirming = false; if (curId) render(); }, 3500); return; }
      clearTimeout(confirmTimer); confirming = false;
      var id = curId; completeCourierDelivery(id); closeCourierTask();
    };
  }

  function tick() {
    var c = getC(); if (!c) return;
    var start = c.assignedAt || (findOrder(c) && findOrder(c).createdAtTs) || 0;
    document.querySelectorAll('[data-ct-elapsed]').forEach(function (el) { el.textContent = start ? fmtDur(Date.now() - start) : '--:--'; });
  }

  window.openCourierTask = function (id, focusMap) {
    var c = (typeof couriersData !== 'undefined' ? couriersData : []).find(function (x) { return x.id === id; });
    if (!c) return;
    if (typeof ensureCourierExtras === 'function') ensureCourierExtras(c);
    curId = id; confirming = false;
    render();
    var v = $('view-courier-task'); v.classList.add('active'); v.setAttribute('aria-hidden', 'false');
    clearInterval(timer); timer = setInterval(tick, 1000);
    var b = $('mf-ct-body'); b.scrollTop = 0;
    if (focusMap) setTimeout(function () { var m = $('mf-ct-map'); if (m) m.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 120);
  };
  window.closeCourierTask = function () {
    var v = $('view-courier-task'); if (!v) return;
    v.classList.remove('active'); v.setAttribute('aria-hidden', 'true');
    clearInterval(timer); clearTimeout(confirmTimer); confirming = false; curId = null; destroyMap();
    $('mf-ct-body').innerHTML = '';
    if (typeof renderCouriersList === 'function') renderCouriersList();
  };

  var _persist = window.persistOrders;
  if (typeof _persist === 'function') window.persistOrders = function () {
    var r = _persist.apply(this, arguments);
    try { if (curId && !savingPin && $('view-courier-task').classList.contains('active')) render(); } catch (e) { }
    return r;
  };
})();
