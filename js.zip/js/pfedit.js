(function(){
  var COLORS=['#ea580c','#4f46e5','#06b6d4','#ef4444','#f43f5e','#8b5cf6','#3b82f6','#ec4899','#10b981','#eab308'];
  var cur=null; // {kind,id}
  var rmImg=false, rmDoc=false;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function ctx(kind){
    if(kind==='purchase')return {store:function(){return (purchaseProfiles[currentPurchaseCategory]||{});},save:function(){savePurchaseProfiles();},render:function(){renderPurchaseProfiles();if(document.getElementById('popup-purchase-profile').classList.contains('active'))renderPurchaseProfileDetailBody();},title:'دەستکاری پڕۆفایلی فرۆشیار',who:'ناوی فرۆشیار'};
    if(kind==='debt')return {extras:[['debtType','جۆری قەرز'],['productType','جۆری کاڵا']],store:function(){return debtProfiles;},save:function(){saveDebtProfiles();},render:function(){renderDebtProfilesAll();if(document.getElementById('popup-debt-profile')&&document.getElementById('popup-debt-profile').classList.contains('active'))renderDebtProfileDetailBody();},title:'دەستکاری پڕۆفایلی قەرزار'};
    if(kind==='mydebt')return {extras:[['receiver','ناوی وەرگر'],['lender','ناوی ئەو کەسەی قەرزەکەی داوەتەوە'],['witness','ناوی شاهید'],['debtType','جۆری قەرز'],['productType','جۆری کاڵا']],sync:true,store:function(){return myDebtProfiles;},save:function(){saveMyDebtProfiles();},render:function(){renderMyDebtProfiles();var d=document.getElementById('popup-my-debt-detail');if(d&&d.classList.contains('active'))renderMyDebtDetail();},title:'دەستکاری پڕۆفایلی قەرز'};
    return {store:function(){return (saleProfiles[currentSaleCategory]||{});},save:function(){saveSaleProfiles();},render:function(){renderSaleProfiles();if(document.getElementById('popup-sale-profile').classList.contains('active'))renderSaleProfileDetailBody();},title:'دەستکاری پڕۆفایلی کڕیار',who:'ناوی کڕیار'};
  }
  function build(){
    if(document.getElementById('popup-pf-edit'))return;
    var d=document.createElement('div');d.id='popup-pf-edit';d.className='custom-popup-overlay';d.style.zIndex='3700';
    d.innerHTML='<div class="order-builder-window order-status-sheet"><div class="order-builder-header"><h3 id="pfe-title">دەستکاری پڕۆفایل</h3><button class="order-builder-close" onclick="mfPfEditClose()"><i data-lucide="x"></i></button></div><div class="order-builder-body">'+
    '<div class="pfe-prev" id="pfe-prev"><div class="av" id="pfe-av"></div><div><div class="nm" id="pfe-nm"></div><div class="ph" id="pfe-ph"></div></div></div>'+
    '<div class="ob-section"><div class="ob-customer-card-fields"><div class="ob-icon-field"><i data-lucide="user-round"></i><input id="pfe-name" type="text" placeholder="ناو" oninput="mfPfeLive()"></div><div class="ob-icon-field"><i data-lucide="phone"></i><input id="pfe-phone" type="text" inputmode="tel" placeholder="ژمارەی موبایل" oninput="mfPfeLive()"></div></div>'+
    '<div id="pfe-extras"></div><label style="margin-top:16px;">ڕەنگی پڕۆفایل</label><div class="pfe-colors" id="pfe-colors"></div>'+
    '<label style="margin-top:16px;">تێبینی</label><textarea id="pfe-note" class="ob-textarea" placeholder="تێبینی دەربارەی ئەم پڕۆفایلە"></textarea>'+
    '<div class="debt-media-fields"><div class="debt-media-field"><div class="debt-media-label"><i data-lucide="image"></i> وێنەی پڕۆفایل</div><input class="debt-media-input" type="file" id="pfe-img" accept="image/*" onchange="previewDebtImage(this,\'pfe-img-prev\');mfPfeLive()"><img id="pfe-img-prev" class="debt-media-preview" alt="وێنەی پڕۆفایل"><button type="button" class="pfe-rm" id="pfe-img-rm" onclick="mfPfeRmImg()" style="display:none"><i data-lucide="trash-2" style="width:13px;height:13px;vertical-align:-2px"></i> سڕینەوەی وێنە</button></div>'+
    '<div class="debt-media-field"><div class="debt-media-label"><i data-lucide="id-card"></i> ناسنامە / بەڵگە</div><select id="pfe-doc-type" class="debt-doc-type"><option value="">جۆری بەڵگە هەڵبژێرە</option><option>ناسنامە</option><option>کارتی نیشتیمانی</option><option>پاسپۆرت</option><option>مۆڵەتی شۆفێری</option></select><input class="debt-media-input" style="margin-top:8px" type="file" id="pfe-doc" accept="image/*" onchange="previewDebtImage(this,\'pfe-doc-prev\')"><img id="pfe-doc-prev" class="debt-media-preview" alt="وێنەی بەڵگە"><button type="button" class="pfe-rm" id="pfe-doc-rm" onclick="mfPfeRmDoc()" style="display:none"><i data-lucide="trash-2" style="width:13px;height:13px;vertical-align:-2px"></i> سڕینەوەی بەڵگە</button></div></div>'+
    '<button class="ob-create-btn" style="margin-top:16px;background:var(--c-29);" onclick="mfPfEditSave()"><i data-lucide="save"></i> پاشەکەوتکردنی گۆڕانکاری</button></div></div></div>';
    document.body.appendChild(d);
  }
  var color=COLORS[0];
  function paintColors(){
    var h='';COLORS.forEach(function(c){h+='<button type="button" class="pfe-sw'+(c.toLowerCase()===String(color).toLowerCase()?' on':'')+'" style="background:'+c+'" onclick="mfPfeColor(\''+c+'\')"><i data-lucide="check"></i></button>';});
    var custom=COLORS.some(function(c){return c.toLowerCase()===String(color).toLowerCase();})?'':' on';
    h+='<span class="pfe-sw pfe-custom'+custom+'" style="'+(custom?'background:'+color:'')+'"><i data-lucide="check"></i><input type="color" value="'+(/^#[0-9a-f]{6}$/i.test(color)?color:'#4f46e5')+'" oninput="mfPfeColor(this.value)"></span>';
    document.getElementById('pfe-colors').innerHTML=h;if(window.safeCreateIcons)safeCreateIcons();
  }
  window.mfPfeColor=function(c){color=c;paintColors();mfPfeLive();};
  window.mfPfeLive=function(){
    var pv=document.getElementById('pfe-prev');pv.style.setProperty('--pfe',color);
    document.getElementById('pfe-nm').textContent=document.getElementById('pfe-name').value||'—';
    document.getElementById('pfe-ph').textContent=document.getElementById('pfe-phone').value||'';
    var f=document.getElementById('pfe-img').files&&document.getElementById('pfe-img').files[0];
    var av=document.getElementById('pfe-av'),pr=document.getElementById('pfe-img-prev');
    var src=(f&&pr.getAttribute('src'))||(!rmImg&&cur&&cur.img)||'';
    av.innerHTML=src?'<img src="'+esc(src)+'" alt="">':'<i data-lucide="user-round"></i>';
    document.getElementById('pfe-img-rm').style.display=(src)?'inline-block':'none';
    if(window.safeCreateIcons)safeCreateIcons();
  };
  window.mfPfeRmImg=function(){rmImg=true;var i=document.getElementById('pfe-img');i.value='';previewDebtImage(i,'pfe-img-prev');mfPfeLive();};
  window.mfPfeRmDoc=function(){rmDoc=true;var i=document.getElementById('pfe-doc');i.value='';previewDebtImage(i,'pfe-doc-prev');document.getElementById('pfe-doc-type').value='';document.getElementById('pfe-doc-rm').style.display='none';};
  window.mfPfEdit=function(kind,id){
    if(typeof notebookMutationBlocked==='function'&&notebookMutationBlocked())return;
    var c=ctx(kind),pf=c.store()[id];if(!pf)return;
    build();cur={kind:kind,id:id,img:pf.profileImage||''};rmImg=false;rmDoc=false;
    color=pf.color&&/^#[0-9a-f]{6}$/i.test(pf.color)?pf.color:COLORS[0];
    document.getElementById('pfe-title').textContent=c.title;
    document.getElementById('pfe-name').value=pf.name||'';
    document.getElementById('pfe-phone').value=pf.phone||'';
    document.getElementById('pfe-note').value=pf.note||'';
    document.getElementById('pfe-doc-type').value=pf.docType||'';
    ['pfe-img','pfe-doc'].forEach(function(x){document.getElementById(x).value='';});
    ['pfe-img-prev','pfe-doc-prev'].forEach(function(x){var e=document.getElementById(x);e.removeAttribute('src');e.classList.remove('show');});
    if(pf.docImage){var dp=document.getElementById('pfe-doc-prev');dp.src=pf.docImage;dp.classList.add('show');document.getElementById('pfe-doc-rm').style.display='inline-block';}else document.getElementById('pfe-doc-rm').style.display='none';
    var ex='';(c.extras||[]).forEach(function(x){ex+='<label style="margin-top:16px;">'+x[1]+'</label><input type="text" class="ob-text-input" data-pfx="'+x[0]+'" value="'+esc(pf[x[0]]||'')+'">';});
    document.getElementById('pfe-extras').innerHTML=ex;
    paintColors();mfPfeLive();
    document.getElementById('popup-pf-edit').classList.add('active');
  };
  window.mfPfEditClose=function(){var d=document.getElementById('popup-pf-edit');if(d)d.classList.remove('active');cur=null;};
  window.mfPfEditSave=async function(){
    if(!cur)return;var c=ctx(cur.kind),store=c.store(),pf=store[cur.id];if(!pf)return;
    var name=document.getElementById('pfe-name').value.trim(),phone=document.getElementById('pfe-phone').value.trim();
    if(!name){showInfoPrompt('تێبینی','ناو نابێت بەتاڵ بێت.');return;}
    var pi=document.getElementById('pfe-img'),di=document.getElementById('pfe-doc');
    var img=pi.files&&pi.files[0]?await debtReadImage(pi):null, doc=di.files&&di.files[0]?await debtReadImage(di):null;
    pf.name=name;pf.phone=phone;pf.color=color;pf.note=document.getElementById('pfe-note').value.trim();
    if(img)pf.profileImage=img;else if(rmImg)pf.profileImage='';
    if(doc)pf.docImage=doc;else if(rmDoc)pf.docImage='';
    var dt=document.getElementById('pfe-doc-type').value;pf.docType=dt;
    document.querySelectorAll('#pfe-extras [data-pfx]').forEach(function(i){pf[i.getAttribute('data-pfx')]=i.value.trim();});
    if(c.sync){(pf.ledger||[]).forEach(function(e){if(e.type==='debt'){e.debtType=pf.debtType;e.productType=pf.productType;}});if(!pf.lender)pf.lender=name;}
    c.save();mfPfEditClose();c.render();
  };
  window.mfPfDelete=function(kind,id){
    if(typeof notebookMutationBlocked==='function'&&notebookMutationBlocked())return;
    if(kind==='purchase'){activePurchaseProfileId=id;deletePurchaseProfileConfirm();}else{activeSaleProfileId=id;deleteSaleProfileConfirm();}
  };
})();
