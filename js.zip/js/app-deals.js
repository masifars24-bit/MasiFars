(function () {
    'use strict';
    var DEALS = [
        { value: 'cash',        label: 'نەقد',                              short: 'نەقد',   sub: 'پارەکە دەستبەجێ دەدرێت',        icon: 'banknote',       color: '#10b981' },
        { value: 'debt',        label: 'پارەدان بەشێوازی قەرز',             short: 'قەرز',   sub: 'پارەکە دواتر دەدرێتەوە',        icon: 'hand-coins',     color: '#f59e0b' },
        { value: 'installment', label: 'پارەدان بەشێوازی قیست',             short: 'قیست',   sub: 'بە چەند بەشێک دەدرێت',          icon: 'layers',         color: '#8b5cf6' },
        { value: 'date',        label: 'پارەدان بەشێوازی دیارکردنی بەروار', short: 'بەروار', sub: 'لە بەروارێکی دیاریکراودا دەدرێت', icon: 'calendar-clock', color: '#3b82f6' }
    ];
    var METHODS = [
        { value: 'cash',       label: 'شێوازی پارەدانی کاش',        short: 'کاش',        sub: 'پارەی دەستی',                      icon: 'wallet',      color: '#10b981' },
        { value: 'electronic', label: 'شێوازی پارەدانی ئەلیکترۆنی', short: 'ئەلیکترۆنی', sub: 'کارت یان گواستنەوەی ئەلیکترۆنی', icon: 'credit-card', color: '#0ea5e9' }
    ];
    var S = {}, sheetKey = null, sheetKind = null;

    function list(kind) { return kind === 'method' ? METHODS : DEALS; }
    function find(kind, v) { var a = list(kind); for (var i = 0; i < a.length; i++) if (a[i].value === v) return a[i]; return a[0]; }
    function st(k) { if (!S[k]) S[k] = { type: 'cash', method: 'cash', date: '', installments: '', firstDate: '' }; return S[k]; }
    function esc(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function digits(v) {
        return String(v || '').replace(/[0-9]/g, function (d) { return String(d.charCodeAt(0) - 1632); })
                              .replace(/[0-9]/g, function (d) { return String(d.charCodeAt(0) - 1776); })
                              .replace(/[^0-9]/g, '');
    }
    function icons() { try { if (typeof safeCreateIcons === 'function') safeCreateIcons(); else if (window.lucide) window.lucide.createIcons(); } catch (e) {} }

    function render(k) {
        var host = document.getElementById('mf-deal-host-' + k);
        if (!host) return;
        var s = st(k), d = find('type', s.type), m = find('method', s.method), extra = '';
        var q = "'" + k + "'";
        if (s.type === 'date') {
            extra = '<div class="mf-deal-field mf-full"><label><i data-lucide="calendar-days"></i><span>بەرواری پارەدان</span></label>' +
                    '<input type="date" class="ob-text-input" value="' + esc(s.date) + '" onchange="mfDeal.set(' + q + ',\'date\',this.value)"></div>';
        } else if (s.type === 'installment') {
            extra = '<div class="mf-deal-field"><label><i data-lucide="hash"></i><span>ژمارەی قیستەکان</span></label>' +
                    '<input type="text" inputmode="numeric" class="ob-text-input" placeholder="بۆ نموونە: 4" value="' + esc(s.installments) + '" oninput="mfDeal.set(' + q + ',\'installments\',this.value)"></div>' +
                    '<div class="mf-deal-field"><label><i data-lucide="calendar-days"></i><span>بەرواری یەکەم قیست</span></label>' +
                    '<input type="date" class="ob-text-input" value="' + esc(s.firstDate) + '" onchange="mfDeal.set(' + q + ',\'firstDate\',this.value)"></div>';
        }
        host.innerHTML =
            '<div class="mf-deal-bar">' +
                '<button type="button" class="mf-deal-orb" style="--dc:' + d.color + '" onclick="mfDeal.pick(' + q + ',\'type\')" title="شێوازی مامەڵە"><i data-lucide="handshake"></i></button>' +
                '<span class="mf-deal-pill" style="--dc:' + d.color + '"><i data-lucide="' + d.icon + '"></i>' + esc(d.short) + '</span>' +
                '<span class="mf-deal-gap"></span>' +
                '<span class="mf-deal-pill" style="--dc:' + m.color + '"><i data-lucide="' + m.icon + '"></i>' + esc(m.short) + '</span>' +
                '<button type="button" class="mf-deal-orb" style="--dc:' + m.color + '" onclick="mfDeal.pick(' + q + ',\'method\')" title="شێوازی پارەدان"><i data-lucide="wallet-cards"></i></button>' +
            '</div>' +
            '<div class="mf-deal-extra">' + extra + '</div>';
        icons();
    }

    function ensureSheet() {
        if (document.getElementById('mf-deal-sheet')) return;
        var el = document.createElement('div');
        el.id = 'mf-deal-sheet';
        el.className = 'mf-deal-sheet-overlay';
        el.setAttribute('onclick', 'if(event.target===this) mfDeal.close()');
        el.innerHTML = '<div class="mf-deal-sheet-panel"><div class="mf-deal-handle"></div>' +
            '<div class="mf-deal-sheet-head"><span class="mf-deal-sheet-ico" id="mf-deal-sheet-ico"></span><div><h4 id="mf-deal-sheet-title"></h4><p id="mf-deal-sheet-sub"></p></div></div>' +
            '<div class="mf-deal-options" id="mf-deal-options"></div></div>';
        document.body.appendChild(el);
    }

    function pick(k, kind) {
        ensureSheet();
        sheetKey = k; sheetKind = kind;
        var isM = kind === 'method', cur = st(k)[isM ? 'method' : 'type'];
        document.getElementById('mf-deal-sheet-ico').innerHTML = '<i data-lucide="' + (isM ? 'wallet-cards' : 'handshake') + '"></i>';
        document.getElementById('mf-deal-sheet-title').textContent = isM ? 'شێوازی پارەدان' : 'شێوازی مامەڵە';
        document.getElementById('mf-deal-sheet-sub').textContent = isM ? 'پارەکە چۆن دەدرێت؟' : 'مامەڵەکە بە چ شێوازێک ئەنجام دەدرێت؟';
        document.getElementById('mf-deal-options').innerHTML = list(kind).map(function (o) {
            return '<button type="button" class="mf-deal-opt' + (o.value === cur ? ' active' : '') + '" style="--dc:' + o.color + '" onclick="mfDeal.choose(\'' + o.value + '\')">' +
                '<span class="mf-deal-opt-check"><i data-lucide="check"></i></span>' +
                '<span class="mf-deal-opt-ico"><i data-lucide="' + o.icon + '"></i></span>' +
                '<span class="mf-deal-opt-label">' + esc(o.label) + '</span>' +
                '<span class="mf-deal-opt-sub">' + esc(o.sub) + '</span></button>';
        }).join('');
        document.getElementById('mf-deal-sheet').classList.add('active');
        icons();
    }
    function choose(v) {
        if (!sheetKey) return;
        st(sheetKey)[sheetKind === 'method' ? 'method' : 'type'] = v;
        var k = sheetKey; close(); render(k);
    }
    function close() {
        var el = document.getElementById('mf-deal-sheet');
        if (el) el.classList.remove('active');
        sheetKey = null; sheetKind = null;
    }
    function set(k, field, v) { st(k)[field] = (field === 'installments') ? digits(v) : v; }

    function reset(k) { S[k] = { type: 'cash', method: 'cash', date: '', installments: '', firstDate: '' }; render(k); }
    function get(k) {
        var s = st(k), o = { type: s.type, method: s.method };
        if (s.type === 'date' && s.date) o.date = s.date;
        if (s.type === 'installment') {
            var n = parseInt(s.installments) || 0;
            if (n) o.installments = n;
            if (s.firstDate) o.firstDate = s.firstDate;
        }
        return o;
    }
    function validate(k) {
        var s = st(k);
        if (s.type === 'date' && !s.date) return 'تکایە بەرواری پارەدان دیاری بکە.';
        if (s.type === 'installment' && (parseInt(s.installments) || 0) < 2) return 'تکایە ژمارەی قیستەکان بنووسە (لانی کەم 2).';
        return '';
    }

    function typeText(deal) {
        var d = find('type', deal.type), t = d.short;
        if (deal.type === 'date' && deal.date) t += ': ' + deal.date;
        if (deal.type === 'installment') {
            t += ': ' + (deal.installments || '؟') + ' قیست';
            if (deal.firstDate) t += ' · یەکەم ' + deal.firstDate;
        }
        return t;
    }
    function chip(o, text) {
        return '<span class="mf-deal-chip" style="color:' + o.color + ';background:' + o.color + '22;border:1px solid ' + o.color + '55;"><i data-lucide="' + o.icon + '"></i>' + esc(text) + '</span>';
    }
    window.mfDealChipsHtml = function (deal) {
        if (!deal || !deal.type) return '';
        return '<div class="mf-deal-chips">' + chip(find('type', deal.type), typeText(deal)) + chip(find('method', deal.method || 'cash'), find('method', deal.method || 'cash').short) + '</div>';
    };
    window.mfDealInfoList = function (deal) {
        if (!deal || !deal.type) return '';
        function row(icon, label, text) {
            return '<div class="txd-info-row"><div class="txd-info-icon"><i data-lucide="' + icon + '"></i></div><div class="txd-info-text"><span>' + label + '</span><b>' + esc(text) + '</b></div></div>';
        }
        return '<div class="txd-info-list">' + row('handshake', 'شێوازی مامەڵە', typeText(deal)) + row('wallet-cards', 'شێوازی پارەدان', find('method', deal.method || 'cash').short) + '</div>';
    };
    window.mfDealGet = get;
    window.mfDealReset = reset;
    window.mfDealValidate = validate;
    window.mfDeal = { pick: pick, choose: choose, close: close, set: set, render: render };

    ['pur', 'sl', 'debtnew', 'debtborrow', 'mydebt', 'rcpt'].forEach(render);
})();
