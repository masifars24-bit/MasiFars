(function(){
  var APPS={whatsapp:{n:'واتساپ',k:'wa'},viber:{n:'ڤایبەر',k:'vb'},telegram:{n:'تێلیگرام',k:'tg'}};
  var ROLES=['کاشێر','کارگوزار','ئاشپەز','گەیاندن','کارمەندی تر'];
  var el=null,app='whatsapp',role='',ref='',lastInfo=null,tid=0;
  function $(s){return el.querySelector(s);}
  function norm(v){return String(v||'').replace(/[٠-٩]/g,function(d){return d.charCodeAt(0)-1632;}).replace(/[۰-۹]/g,function(d){return d.charCodeAt(0)-1776;});}
  function icons(){try{if(window.lucide)lucide.createIcons({root:el});}catch(e){}}
  function newRef(){var d=new Date(),p=function(n){return (n<10?'0':'')+n;};return 'MF-'+String(d.getFullYear()).slice(2)+p(d.getMonth()+1)+p(d.getDate())+'-'+(1000+Math.floor(Math.random()*9000));}
  function info(){return{name:$('#mfrq-name').value.trim().replace(/\s+/g,' '),phone:norm($('#mfrq-phone').value).replace(/[^\d+]/g,''),role:role,user:$('#mfrq-user').value.trim(),note:$('#mfrq-note').value.trim().replace(/\s+/g,' '),ref:ref};}
  function nameOk(v){return Array.from(v).length>=3;}
  function phoneOk(v){var n=v.replace(/\D/g,'').length;return n>=10&&n<=15;}
  function setState(id,ok,err){var w=$('#mfrq-w-'+id);w.classList.toggle('ok',!!ok);if(err!==undefined){w.classList.toggle('err',!!err);}}
  function update(){
    var i=info(),nm=nameOk(i.name),ph=phoneOk(i.phone);
    setState('name',nm);setState('phone',ph);setState('user',!!i.user);setState('note',!!i.note);
    if(nm)$('#mfrq-w-name').classList.remove('err');if(ph)$('#mfrq-w-phone').classList.remove('err');
    var pct=(nm?30:0)+(ph?30:0)+(i.role?15:0)+(i.user?10:0)+(i.note?15:0);
    $('#mfrq-bar').style.transform='scaleX('+(pct/100)+')';$('#mfrq-pct').textContent=pct+'%';
    $('#mfrq-send').classList.toggle('dim',!(nm&&ph));
    $('#mfrq-cnt').textContent=Array.from($('#mfrq-note').value).length+'/200';
    try{$('#mfrq-pv').textContent=window.mfAccessMsg(i);}catch(e){}
  }
  function selectApp(a){
    app=APPS[a]?a:'whatsapp';
    Array.prototype.forEach.call(el.querySelectorAll('.mfrq-app'),function(b){b.classList.toggle('on',b.getAttribute('data-app')===app);});
    $('#mfrq-send').setAttribute('data-app',app);
    $('#mfrq-sendtxt').textContent='ناردن بە '+APPS[app].n;
  }
  function field(id,ic,lab,req,inner,ta){
    return '<div class="mfrq-fw" id="mfrq-w-'+id+'"><div class="mfrq-lb"><span>'+lab+'</span>'+(req?'<b class="mfrq-req">*</b>':'<em class="mfrq-opt">دڵخوازانە</em>')+'</div><label class="mfrq-f'+(ta?' ta':'')+'"><span class="mfrq-ic"><i data-lucide="'+ic+'"></i></span>'+inner+'<span class="mfrq-ck"><i data-lucide="check"></i></span></label><div class="mfrq-er"></div></div>';
  }
  function svgOf(k){var s=document.querySelector('#mf-req-'+k+' .mfg-tile-ic svg');return s?s.outerHTML:'';}
  function build(){
    if(el)return;
    el=document.createElement('div');el.id='mfrq';
    var apps=Object.keys(APPS).map(function(a){return '<button type="button" class="mfrq-app '+APPS[a].k+'" data-app="'+a+'">'+svgOf(APPS[a].k)+'<span>'+APPS[a].n+'</span></button>';}).join('');
    var chips=ROLES.map(function(r){return '<button type="button" class="mfrq-chip" data-role="'+r+'">'+r+'</button>';}).join('');
    el.innerHTML=
      '<div class="mfrq-bd" data-x="1"></div>'+
      '<div class="mfrq-sh" role="dialog" aria-modal="true" aria-label="داواکاری هەژماری نوێ">'+
        '<div class="mfrq-form">'+
          '<div class="mfrq-hd"><div class="mfrq-grab"></div>'+
            '<div class="mfrq-top"><div class="mfrq-badge"><i data-lucide="user-plus"></i></div>'+
            '<div><div class="mfrq-ttl">داواکاری هەژماری نوێ</div><div class="mfrq-sub">زانیارییەکانت پڕبکەرەوە، پاشان بینێرە بۆ ئادمین</div></div>'+
            '<button type="button" class="mfrq-x" data-x="1" aria-label="داخستن"><i data-lucide="x"></i></button></div>'+
            '<div class="mfrq-prog"><div class="mfrq-bar"><i id="mfrq-bar"></i></div><span class="mfrq-pct" id="mfrq-pct">0%</span></div>'+
          '</div>'+
          '<div class="mfrq-bd2">'+
            '<div class="mfrq-sec">زانیاری سەرەکی</div>'+
            field('name','user-round','ناوی تەواو',true,'<input id="mfrq-name" type="text" autocomplete="name" maxlength="40" placeholder="نموونە: ئەحمەد محەمەد">')+
            field('phone','phone','ژمارەی مۆبایل',true,'<input id="mfrq-phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="16" dir="ltr" placeholder="07501234567">')+
            '<div class="mfrq-sec">زانیاری کارەکەت</div>'+
            '<div class="mfrq-lb"><span>پلەی کارکردن</span><em class="mfrq-opt">دڵخوازانە</em></div><div class="mfrq-chips" id="mfrq-chips">'+chips+'</div>'+
            field('user','at-sign','ناوی بەکارهێنەری دڵخواز',false,'<input id="mfrq-user" type="text" dir="ltr" autocapitalize="none" autocorrect="off" spellcheck="false" maxlength="24" placeholder="username">')+
            field('note','message-square-text','تێبینی بۆ ئادمین',false,'<textarea id="mfrq-note" rows="3" maxlength="200" placeholder="هەر زانیارییەکی تر کە دەتەوێت ئادمین بیزانێت..."></textarea>',true)+
            '<div class="mfrq-cnt" id="mfrq-cnt">0/200</div>'+
            '<div class="mfrq-sec">ناردن لە ڕێگەی</div>'+
            '<div class="mfrq-seg" style="margin-top:12px">'+apps+'</div>'+
            '<button type="button" class="mfrq-pvt" id="mfrq-pvt"><span><i data-lucide="eye"></i>پێشبینینی نامەکە</span><i class="mfrq-chev" data-lucide="chevron-down"></i></button>'+
            '<div class="mfrq-pv" id="mfrq-pv"></div>'+
          '</div>'+
          '<div class="mfrq-ft"><button type="button" class="mfrq-send dim" id="mfrq-send" data-app="whatsapp"><i data-lucide="send"></i><span id="mfrq-sendtxt">ناردن</span></button>'+
          '<div class="mfrq-priv"><i data-lucide="shield-check"></i>زانیارییەکان تەنها بۆ ئادمینی سیستەم دەنێردرێن</div></div>'+
        '</div>'+
        '<div class="mfrq-done"><div class="mfrq-dc"><i data-lucide="check"></i></div>'+
          '<div class="mfrq-dt">نامەکە ئامادە کرا</div><div class="mfrq-dn" id="mfrq-dn"></div>'+
          '<button type="button" class="mfrq-btn p" id="mfrq-again"><i data-lucide="external-link"></i><span id="mfrq-againtxt">کردنەوەی دووبارە</span></button>'+
          '<button type="button" class="mfrq-btn s" id="mfrq-back"><i data-lucide="pencil"></i>گەڕانەوە و دەستکاریکردن</button>'+
          '<button type="button" class="mfrq-btn s" data-x="1"><i data-lucide="x"></i>داخستن</button>'+
        '</div>'+
      '</div>';
    (document.getElementById('app-login-gate')||document.body).appendChild(el);
    icons();
    el.addEventListener('click',function(e){
      var t=e.target;
      if(t.closest('[data-x]')){close();return;}
      var ab=t.closest('.mfrq-app');if(ab){selectApp(ab.getAttribute('data-app'));return;}
      var ch=t.closest('.mfrq-chip');if(ch){var r=ch.getAttribute('data-role');role=(role===r)?'':r;Array.prototype.forEach.call(el.querySelectorAll('.mfrq-chip'),function(c){c.classList.toggle('on',c.getAttribute('data-role')===role);});update();return;}
      if(t.closest('#mfrq-pvt')){$('#mfrq-pvt').classList.toggle('open');$('#mfrq-pv').classList.toggle('open');update();return;}
      if(t.closest('#mfrq-send')){send();return;}
      if(t.closest('#mfrq-again')){if(lastInfo)window.mfRequestSend(app,lastInfo);return;}
      if(t.closest('#mfrq-back')){el.classList.remove('sent');return;}
    });
    el.addEventListener('input',function(e){
      var t=e.target;
      if(t.id==='mfrq-phone')t.value=norm(t.value).replace(/[^\d+\s]/g,'');
      if(t.id==='mfrq-user')t.value=t.value.replace(/[^a-zA-Z0-9._-]/g,'').toLowerCase();
      update();
    });
    el.addEventListener('focusin',function(e){
      var t=e.target;if(!t||!/INPUT|TEXTAREA/.test(t.tagName))return;
      setTimeout(function(){try{t.scrollIntoView({block:'center',behavior:'smooth'});}catch(x){}},320);
    });
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&el&&el.classList.contains('on'))close();});
  }
  function send(){
    var i=info(),bad=null;
    if(!nameOk(i.name)){setState('name',false,true);$('#mfrq-w-name .mfrq-er').textContent='تکایە ناوی تەواوت بنووسە (لانیکەم ٣ پیت).';bad=bad||'#mfrq-name';}
    if(!phoneOk(i.phone)){setState('phone',false,true);$('#mfrq-w-phone .mfrq-er').textContent='ژمارەی مۆبایل دروست نییە. نموونە: 07501234567';bad=bad||'#mfrq-phone';}
    if(bad){var f=$(bad);try{f.focus();}catch(e){}return;}
    var note=window.mfRequestSend(app,i);
    if(note===null){var w=$('#mfrq-w-phone');return;}
    lastInfo=i;
    var def={whatsapp:'ئەپی واتساپ کرایەوە و نامەکە ئامادەیە. تەنها دوگمەی ناردن دابگرە.',viber:'نامەکە کۆپی کرا. کاتێک چاتی ئادمین لە ڤایبەر کرایەوە، paste بکە و بینێرە.',telegram:'ئەپی تێلیگرام کرایەوە. ئەگەر نامەکە نەنووسرا، نامەکە کۆپی کراوە و لە چاتەکەدا paste بکە.'};
    $('#mfrq-dn').textContent=note||def[app];
    $('#mfrq-againtxt').textContent='کردنەوەی دووبارەی '+APPS[app].n;
    el.classList.add('sent');icons();
  }
  function close(){
    if(!el)return;el.classList.remove('show');clearTimeout(tid);tid=setTimeout(function(){el.classList.remove('on');},380);
  }
  window.mfReqOpen=function(a){
    build();clearTimeout(tid);
    if(!ref)ref=newRef();
    el.classList.remove('sent');selectApp(a);update();
    el.classList.add('on');
    requestAnimationFrame(function(){requestAnimationFrame(function(){el.classList.add('show');});});
  };
})();
