(function(){
    window.mfToggleTopMenu=function(e){
        if(e)e.stopPropagation();
        var menu=document.getElementById('mf-top-menu'), btn=document.getElementById('mf-top-launcher');
        if(!menu||!btn)return;
        var open=menu.classList.toggle('open'); btn.classList.toggle('open',open); btn.setAttribute('aria-expanded',open?'true':'false');
        if(window.lucide) lucide.createIcons();
    };
    window.mfTopAction=function(action){
        try{
            if(action==='theme' && typeof handleThemeToggle==='function') handleThemeToggle();
            else if(action==='tools' && typeof mfOpenTools==='function') mfOpenTools();
            else if(typeof handleNavigation==='function') handleNavigation(action);
        }catch(err){console.warn('Massi Fars top menu action:',err)}
        var menu=document.getElementById('mf-top-menu'),btn=document.getElementById('mf-top-launcher');
        if(menu)menu.classList.remove('open'); if(btn){btn.classList.remove('open');btn.setAttribute('aria-expanded','false')}
        document.querySelectorAll('.mf-top-action').forEach(function(x){x.classList.toggle('active',x.dataset.mfAction===action)});
    };
    document.addEventListener('click',function(e){
        var wrap=document.querySelector('.mf-top-launcher-wrap'); if(wrap && !wrap.contains(e.target)){
            var menu=document.getElementById('mf-top-menu'),btn=document.getElementById('mf-top-launcher');
            if(menu)menu.classList.remove('open'); if(btn){btn.classList.remove('open');btn.setAttribute('aria-expanded','false')}
        }
    },true);
})();
