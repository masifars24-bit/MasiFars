(function () {
  var KEY = 'mf_team_logo';
  function get() { try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; } }
  window.mfTeamLogoGet = get;
  function icons() { try { if (typeof safeCreateIcons === 'function') safeCreateIcons(); else if (window.lucide) window.lucide.createIcons(); } catch (e) {} }
  function apply() {
    var img = get(), el = document.getElementById('mf-tl-preview');
    if (el) {
      var has = el.getAttribute('data-tl') === 'img';
      if (img) { if (!has || el.__src !== img) { el.innerHTML = ''; var im = document.createElement('img'); im.alt = ''; im.src = img; el.appendChild(im); el.__src = img; el.setAttribute('data-tl', 'img'); } }
      else if (has) { el.innerHTML = '<i data-lucide="users"></i>'; el.removeAttribute('data-tl'); el.__src = ''; icons(); }
    }
    var r = document.getElementById('mf-tl-reset'); if (r) r.classList.toggle('show', !!img);
  }
  function msg(text, type, title) { try { window.mfDialog.alert(text, { title: title || 'ئاگاداری', type: type || 'info' }); } catch (e) { alert(text); } }
  function save(src, w, h) {
    var max = 320, k = Math.min(1, max / Math.max(w, h));
    var cw = Math.max(1, Math.round(w * k)), ch = Math.max(1, Math.round(h * k));
    var cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
    cv.getContext('2d').drawImage(src, 0, 0, cw, ch);
    var url = '';
    try { url = cv.toDataURL('image/webp', 0.9); } catch (e) {}
    if (url.indexOf('data:image/webp') !== 0) url = cv.toDataURL('image/png');
    try { localStorage.setItem(KEY, url); } catch (e) { msg('شوێنی ئامێرەکە پڕە، وێنەیەکی بچووکتر هەڵبژێرە', 'err', 'هەڵە'); return; }
    apply();
    msg('لۆگۆی تیمەکەت بە سەرکەوتوویی پاشەکەوت کرا', 'ok', 'سەرکەوتوو');
  }
  function handle(inp) {
    var f = inp.files && inp.files[0]; if (!f) return;
    function bad() { msg('ئەم وێنەیە ناکرێتەوە، تکایە وێنەیەکی تر هەڵبژێرە', 'err', 'هەڵە'); }
    try {
      var url = URL.createObjectURL(f), im = new Image();
      im.onload = function () {
        try { save(im, im.naturalWidth || im.width, im.naturalHeight || im.height); } catch (e) { bad(); }
        try { URL.revokeObjectURL(url); } catch (e) {}
        try { inp.value = ''; } catch (e) {}
      };
      im.onerror = function () {
        try { URL.revokeObjectURL(url); } catch (e) {}
        var rd = new FileReader();
        rd.onload = function () { var i2 = new Image(); i2.onload = function () { try { save(i2, i2.naturalWidth, i2.naturalHeight); } catch (e) { bad(); } }; i2.onerror = bad; i2.src = rd.result; };
        rd.onerror = bad; rd.readAsDataURL(f);
      };
      im.src = url;
    } catch (e) { bad(); }
  }
  // delegated: works even if the settings page is re-rendered
  document.addEventListener('change', function (e) { var t = e.target; if (t && t.id === 'mf-tl-file') handle(t); }, true);
  window.mfTeamLogoPick = function () { var i = document.getElementById('mf-tl-file'); if (i) i.click(); };
  window.mfTeamLogoReset = function () { try { localStorage.removeItem(KEY); } catch (e) {} apply(); };
  document.addEventListener('click', function (e) { if (e.target && e.target.closest && e.target.closest('[data-card-key]')) setTimeout(apply, 80); }, true);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply); else apply();
  setTimeout(apply, 800); setTimeout(apply, 2500);
})();
