(function () {
    ['renderEmployeeDetailMessages', 'renderEmployeeDetailComplaints', 'renderEmployeeDetailStars'].forEach(function (name) {
        var orig = window[name];
        if (typeof orig !== 'function') return;
        window[name] = function () {
            var r = orig.apply(this, arguments);
            if (typeof mfpRefreshDetail === 'function') mfpRefreshDetail();
            return r;
        };
    });
})();
