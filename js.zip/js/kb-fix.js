// Keeps the focused input visible above the on-screen keyboard (in every sheet, popup and page)
(function () {
  'use strict';
  var FIELD = 'input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([type=button]):not([type=submit]):not([type=color]),textarea,select,[contenteditable="true"]';
  var padded = null;
  function isField(el) { return !!(el && el.matches && el.matches(FIELD)); }
  function scroller(el) {
    var n = el.parentElement;
    while (n && n !== document.body && n !== document.documentElement) {
      var o = getComputedStyle(n).overflowY;
      if ((o === 'auto' || o === 'scroll') && n.scrollHeight > n.clientHeight + 2) return n;
      n = n.parentElement;
    }
    return null;
  }
  function unpad() { if (padded) { padded.style.paddingBottom = padded.__pb || ''; padded.__pb = undefined; padded = null; } }
  function reveal(el) {
    if (!el || !el.isConnected) return;
    var sc = scroller(el);
    if (sc && padded !== sc) {   // give the container room to scroll the last field above the keyboard
      unpad(); sc.__pb = sc.style.paddingBottom;
      sc.style.paddingBottom = ((parseFloat(getComputedStyle(sc).paddingBottom) || 0) + Math.round(innerHeight * 0.45)) + 'px';
      padded = sc;
    }
    try { el.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) { el.scrollIntoView(true); }
    var vv = window.visualViewport;   // browsers that overlay the keyboard instead of resizing the page
    if (vv) {
      var r = el.getBoundingClientRect(), limit = vv.offsetTop + vv.height - 16;
      if (r.bottom > limit) (sc || document.scrollingElement || document.documentElement).scrollTop += (r.bottom - limit) + 12;
    }
  }
  document.addEventListener('focusin', function (e) {
    var el = e.target; if (!isField(el)) return;
    [60, 350, 700].forEach(function (ms) { setTimeout(function () { if (document.activeElement === el) reveal(el); }, ms); });
  });
  document.addEventListener('focusout', function () {
    setTimeout(function () { if (!isField(document.activeElement)) unpad(); }, 250);
  });
  if (window.visualViewport) window.visualViewport.addEventListener('resize', function () {
    var a = document.activeElement; if (isField(a)) setTimeout(function () { reveal(a); }, 80);
  });
})();
