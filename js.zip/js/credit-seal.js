(function () {
  var KEY = 'mf_credit_seal_img';
  function get() { try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; } }
  function icons() { try { if (typeof safeCreateIcons === 'function') safeCreateIcons(); else if (window.lucide) window.lucide.createIcons(); } catch (e) {} }
  function paint(el, img, small) {
    if (!el) return;
    var has = el.getAttribute('data-seal') === 'img';
    if (img) {
      if (!has || el.__src !== img) { el.innerHTML = ''; var im = document.createElement('img'); im.alt = ''; im.src = img; el.appendChild(im); el.__src = img; el.setAttribute('data-seal', 'img'); }
      if (!small) el.classList.add('has-img');
    } else if (has) {
      el.innerHTML = '<i data-lucide="shield-check"></i>'; el.removeAttribute('data-seal'); el.__src = ''; el.classList.remove('has-img'); icons();
    }
  }
  function apply() {
    var img = get();
    document.querySelectorAll('.mf-credit-seal').forEach(function (el) { paint(el, img, false); });
    paint(document.getElementById('mf-seal-preview'), img, true);
    var r = document.getElementById('mf-seal-reset'); if (r) r.classList.toggle('show', !!img);
  }
  function fail(msg) { try { window.mfDialog.alert(msg, { title: 'هەڵە', type: 'err' }); } catch (e) { alert(msg); } }
  window.mfSealPick = function () {
    var inp = document.getElementById('mf-seal-file'); if (!inp) return;
    inp.value = '';
    inp.onchange = function () {
      var f = inp.files && inp.files[0]; if (!f) return;
      if (!/^image\//.test(f.type)) { fail('تکایە فایلی وێنە هەڵبژێرە'); return; }
      var rd = new FileReader();
      rd.onload = function () {
        var im = new Image();
        im.onload = function () {
          var max = 256, w = im.naturalWidth, h = im.naturalHeight, k = Math.min(1, max / Math.max(w, h));
          var cw = Math.max(1, Math.round(w * k)), ch = Math.max(1, Math.round(h * k));
          var cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
          cv.getContext('2d').drawImage(im, 0, 0, cw, ch);
          var url = cv.toDataURL('image/webp', 0.9);
          if (url.indexOf('data:image/webp') !== 0) url = cv.toDataURL('image/png');
          try { localStorage.setItem(KEY, url); } catch (e) { fail('شوێنی ئامێرەکە پڕە، وێنەیەکی بچووکتر هەڵبژێرە'); return; }
          apply();
        };
        im.onerror = function () { fail('ئەم وێنەیە ناکرێتەوە'); };
        im.src = rd.result;
      };
      rd.readAsDataURL(f);
    };
    inp.click();
  };
  window.mfSealReset = function () { try { localStorage.removeItem(KEY); } catch (e) {} apply(); };
  document.addEventListener('click', function (e) { if (e.target && e.target.closest && e.target.closest('[data-card-key]')) setTimeout(apply, 80); }, true);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply); else apply();
  setTimeout(apply, 800); setTimeout(apply, 2500);
})();
