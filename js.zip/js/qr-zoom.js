(function(){
  'use strict';
  var ov=null, wake=null, cur=null, bound=false, rt=null;
  function esc(v){ return String(v==null?'':v).replace(/[&<>"]/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  /* the enlarged QR is a clean vector code: same link, no logo in the middle and the lowest
     error-correction level, so it has the fewest and therefore the biggest squares */
  function svgFor(text){
    var qr=window.qrcode(0,'M'); qr.addData(text); qr.make();
    var n=qr.getModuleCount(), q=4, t=n+q*2, d='', r, c, s;
    for(r=0;r<n;r++){
      c=0;
      while(c<n){
        if(qr.isDark(r,c)){ s=c; while(c<n&&qr.isDark(r,c)) c++; d+='M'+(s+q)+' '+(r+q)+'h'+(c-s)+'v1h-'+(c-s)+'z'; }
        else c++;
      }
    }
    return { t:t, html:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+t+' '+t+'" shape-rendering="crispEdges" role="img" aria-label="QR"><rect width="'+t+'" height="'+t+'" fill="#fff"/><path d="'+d+'" fill="#000"/></svg>' };
  }
  function onKey(e){ if(e.key==='Escape') closeQr(); }
  function onResize(){ clearTimeout(rt); rt=setTimeout(function(){ if(cur) openQr(cur.text,cur.code,cur.fb); },150); }
  function closeQr(keep){
    if(ov&&ov.parentNode) ov.parentNode.removeChild(ov);
    ov=null;
    if(keep) return;
    cur=null;
    if(bound){ document.removeEventListener('keydown',onKey); window.removeEventListener('resize',onResize); bound=false; }
    try{ if(wake&&wake.release) wake.release(); }catch(e){}
    wake=null;
  }
  function openQr(text,code,fb){
    closeQr(true);
    var sv=null;
    try{ if(typeof window.qrcode==='function') sv=svgFor(text); }catch(e){ sv=null; }
    if(!sv&&!fb) return;
    cur={text:text,code:code,fb:fb};
    var avail=Math.max(160,Math.min(window.innerWidth*0.9,window.innerHeight*0.6,640))-28;
    var size, inner;
    if(sv){ size=Math.max(sv.t*2,Math.floor(avail/sv.t)*sv.t); inner=sv.html; }
    else { size=Math.floor(avail); inner='<img alt="QR" src="'+esc(fb)+'" style="width:100%;height:100%;display:block;image-rendering:pixelated">'; }
    ov=document.createElement('div'); ov.className='mfqz'; ov.setAttribute('role','dialog'); ov.setAttribute('aria-modal','true');
    ov.innerHTML=
      '<button type="button" class="mfqz-x" aria-label="داخستن"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'+
      '<div class="mfqz-card"><div class="mfqz-title">QR کۆدی وەسڵ</div>'+
      '<div class="mfqz-plate" style="width:'+(size+28)+'px;height:'+(size+28)+'px"><div style="width:'+size+'px;height:'+size+'px">'+inner+'</div></div>'+
      (code?'<div class="mfqz-code">'+esc(code)+'</div>':'')+
      '<div class="mfqz-hint">مۆبایلەکەت بەرەو QR ڕابگرە بۆ سکانکردن. ئەگەر سکان نەکرا، ڕووناکی شاشەکە زیاد بکە.</div></div>';
    ov.addEventListener('click',function(e){
      if(e.target.closest&&e.target.closest('.mfqz-plate')) return;
      closeQr();
    });
    document.body.appendChild(ov);
    if(!bound){ document.addEventListener('keydown',onKey); window.addEventListener('resize',onResize); bound=true; }
    try{
      if(!wake&&navigator.wakeLock&&navigator.wakeLock.request){
        navigator.wakeLock.request('screen').then(function(l){ if(ov) wake=l; else { try{ l.release(); }catch(e){} } },function(){});
      }
    }catch(e){}
  }
  document.addEventListener('click',function(e){
    var t=e.target; if(!t||!t.closest) return;
    var w=t.closest('#receipt-qr-wrap,#order-receipt-qr-wrap');
    if(!w||!w.dataset||!w.dataset.qrText) return;
    e.preventDefault(); e.stopPropagation();
    var im=w.querySelector('img'), fb=im?im.getAttribute('src'):'';
    var go=function(){ openQr(w.dataset.qrText,w.dataset.qrCode||'',fb); };
    if(typeof window.qrcode==='function') go();
    else if(typeof window.withQrLibrary==='function') window.withQrLibrary(go);
    else go();
  },true);
})();
