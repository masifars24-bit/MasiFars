/* Massi Fars — System Control (box 15): shutdown · timed pause · update notice/hold · secret-code lock.
   State lives in one Supabase row (key "__sysctl__"), polled every 4s by every device. Admin is never blocked. */
(function () {
  'use strict';
  if (window.__MF_VIEWER || window.__mfSysctl) return;
  var KEY = '__sysctl__', CK = 'sysctl_cache', UK = 'sysctl_unlock', FK = 'sysctl_fail', SK = 'sysctl_seen', AK = 'sysctl_acode';
  var SBU = 'https://wtzffmorfclxivopvsit.supabase.co', SBK = 'sb_publishable_YDz--eVlnrTgZJ6hKJwLig_bzY1-Fjg';
  var LS = localStorage, SS = sessionStorage, D = document, st = null, off = 0, pv = null, ov, an, bn, tt;
  var ui = { dur: 15, lead: 2, pcus: '', pmsg: '', cmsg: '', ver: (window.mfNextVersion ? window.mfNextVersion() : (window.MF_VERSION || (D.querySelector('meta[name=mf-build]') || {}).content || '')), utitle: '', notes: '', code: '', tab: 'closed' };

  function $(s, r) { return (r || D).querySelector(s); }
  function jg(k, d) { try { var v = LS.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function js(k, v) { try { LS.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function now() { return Date.now() + off; }
  function isAdmin() { try { return LS.getItem('mf_admin_session') === '1'; } catch (e) { return false; } }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function p2(n) { return n < 10 ? '0' + n : '' + n; }
  function parts(ms) { ms = Math.max(0, Math.ceil(ms / 1000)); return { h: Math.floor(ms / 3600), m: Math.floor(ms % 3600 / 60), s: ms % 60 }; }
  function fmt(ms) { var p = parts(ms); return (p.h ? p2(p.h) + ':' : '') + p2(p.m) + ':' + p2(p.s); }
  function clock(ts) { var d = new Date(ts); return p2(d.getHours()) + ':' + p2(d.getMinutes()); }
  function rid() { return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
  function mk(id) { var e = D.createElement('div'); e.id = id; D.body.appendChild(e); return e; }
  function reload() {
    if (window.mfApplyUpdate) { window.mfApplyUpdate(); return; }
    var go = function () { location.reload(); }; setTimeout(go, 2500);
    try { navigator.serviceWorker.getRegistrations().then(function (r) { return Promise.all(r.map(function (x) { return x.update(); })); }).catch(function () {}).then(go); } catch (e) { go(); }
  }

  /* ---- SHA-256 (pure JS, works on http/file too) ---- */
  function sha256(a) {
    function rr(v, n) { return (v >>> n) | (v << (32 - n)); }
    var mp = Math.pow, mw = mp(2, 32), i, j, res = '', w = [], bl = a.length * 8, h = [], k = [], pc = 0, ic = {};
    for (var c = 2; pc < 64; c++) if (!ic[c]) { for (i = 0; i < 313; i += c) ic[i] = c; h[pc] = (mp(c, .5) * mw) | 0; k[pc++] = (mp(c, 1 / 3) * mw) | 0; }
    a = unescape(encodeURIComponent(a)); bl = a.length * 8; a += '\x80'; while (a.length % 64 - 56) a += '\x00';
    for (i = 0; i < a.length; i++) w[i >> 2] |= a.charCodeAt(i) << ((3 - i) % 4) * 8;
    w[w.length] = (bl / mw) | 0; w[w.length] = bl;
    for (j = 0; j < w.length;) {
      var x = w.slice(j, j += 16), oh = h; h = h.slice(0, 8);
      for (i = 0; i < 64; i++) {
        var w15 = x[i - 15], w2 = x[i - 2], A = h[0], E = h[4];
        var t1 = h[7] + (rr(E, 6) ^ rr(E, 11) ^ rr(E, 25)) + ((E & h[5]) ^ (~E & h[6])) + k[i] + (x[i] = i < 16 ? x[i] : (x[i - 16] + (rr(w15, 7) ^ rr(w15, 18) ^ (w15 >>> 3)) + x[i - 7] + (rr(w2, 17) ^ rr(w2, 19) ^ (w2 >>> 10))) | 0);
        var t2 = (rr(A, 2) ^ rr(A, 13) ^ rr(A, 22)) + ((A & h[1]) ^ (A & h[2]) ^ (h[1] & h[2]));
        h = [(t1 + t2) | 0].concat(h); h[4] = (h[4] + t1) | 0;
      }
      for (i = 0; i < 8; i++) h[i] = (h[i] + oh[i]) | 0;
    }
    for (i = 0; i < 8; i++) for (j = 3; j + 1; j--) { var b = (h[i] >> (j * 8)) & 255; res += (b < 16 ? '0' : '') + b.toString(16); }
    return res;
  }
  function norm(v) { return String(v).replace(/[\u0660-\u0669]/g, function (c) { return c.charCodeAt(0) - 1632; }).replace(/[\u06F0-\u06F9]/g, function (c) { return c.charCodeAt(0) - 1776; }).toUpperCase().replace(/[^0-9A-Z]/g, '').slice(0, 10); }
  function codeOk(c) { return /^[0-9A-Z]{10}$/.test(c) && c.replace(/\D/g, '').length === 6; }
  function genCode() {
    var r = new Uint32Array(10); (window.crypto || {}).getRandomValues ? crypto.getRandomValues(r) : r.forEach(function (_, i) { r[i] = Math.random() * 4e9; });
    var L = 'ABCDEFGHJKLMNPQRSTUVWXYZ', o = [], i;
    for (i = 0; i < 6; i++) o.push(String(r[i] % 10));
    for (i = 6; i < 10; i++) o.push(L[r[i] % L.length]);
    for (i = o.length - 1; i > 0; i--) { var j = r[i] % (i + 1), t = o[i]; o[i] = o[j]; o[j] = t; }
    return o.join('');
  }

  /* ---- icons / kinds ---- */
  var IC = {
    power: '<path d="M12 2v9"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
    timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9.5 2h5"/>',
    down: '<path d="M12 11v8m0 0-3.5-3.5M12 19l3.5-3.5"/><path d="M4.5 14.5A6.5 6.5 0 1 1 15.8 7.7h1.2a4.5 4.5 0 0 1 1.5 8.7"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2.5"/><path d="M8 11V7.5a4 4 0 0 1 8 0V11"/>',
    ok: '<path d="m5 12.5 4.5 4.5L19 7.5"/>'
  };
  function svg(n, z) { return '<svg viewBox="0 0 24 24" width="' + z + '" height="' + z + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + IC[n] + '</svg>'; }
  var KM = {
    closed: { c: '#ff4d6d', i: 'power', t: 'سیستەمەکە داخراوە' },
    pause: { c: '#ffb020', i: 'timer', t: 'سیستەمەکە ئێستا وەستێندراوە' },
    hold: { c: '#22d3ee', i: 'down', t: 'سیستەمەکە لە بارکردنی وەشانی نوێدایە' },
    lock: { c: '#34d399', i: 'lock', t: 'سیستەمەکە قفڵکراوە' }
  };

  /* ---- what a normal user must see (priority: closed > update hold > pause > code lock) ---- */
  function unlocked(s) { var u = jg(UK, {}); return u.v === s.lock.v && !!u.k && sha256('2:' + u.k) === s.lock.h; }
  function view(s) {
    s = s || st; if (!s) return null; var t = now();
    if (s.closed && s.closed.on) return 'closed';
    if (s.upd && s.upd.hold) return 'hold';
    if (s.pause && t >= s.pause.from && t < s.pause.to) return 'pause';
    if (s.lock && s.lock.on && !unlocked(s)) return 'lock';
    return null;
  }

  /* ---- user overlay ---- */
  function body(k, s) {
    var m = KM[k], u = s.upd || {}, x = '<div class="sx-c"><div class="sx-i">' + svg(m.i, 44) + '</div><h1>' + m.t + '</h1>';
    if (k === 'closed') x += '<p>' + esc((s.closed && s.closed.msg) || 'ئەم سیستەمە لە لایەن ئادمینەوە بە تەواوی داخراوە.\nکاتێک بکرێتەوە، ئەم پەیامە خۆکار لادەچێت.') + '</p>';
    else if (k === 'pause') {
      var p = s.pause;
      x += '<p>' + esc(p.msg || 'سیستەمەکە لە لایەن ئادمینەوە بۆ ماوەیەکی کاتی وەستێندراوە. دوای کۆتایی کات خۆکار دەکرێتەوە.') + '</p>' +
        '<div class="sx-t"><div><b id="sx-h">00</b><small>کاتژمێر</small></div><div><b id="sx-m">00</b><small>خولەک</small></div><div><b id="sx-s">00</b><small>چرکە</small></div></div>' +
        '<div class="sx-bar"><i id="sx-pb"></i></div><div class="sx-n">دەکرێتەوە لە کاتژمێر ' + clock(p.to) + '</div>';
    } else if (k === 'hold') x += '<p>' + esc(u.msg || 'تکایە چاوەڕێ بکە. ئەپەکە خۆکار نوێ دەبێتەوە و دەکرێتەوە.') + '</p>' + (u.ver ? '<span class="sx-pill">' + esc(u.ver) + '</span>' : '') + '<div class="sx-bar ind"><i></i></div>';
    else x += '<p>بۆ کردنەوەی سیستەم، کۆدی نهێنی بنووسە کە ئادمین پێی داویت.</p><input id="sx-in" class="sx-in" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="10" placeholder="123456ABCD"><div class="sx-ch"><span id="sx-c1">0/6 ژمارە</span><span id="sx-c2">0/4 پیتی کەپیتەڵ</span></div><div class="sx-e" id="sx-er"></div><button class="sx-b" id="sx-go">کردنەوە</button>';
    x += '<button class="sx-a" id="sx-adm">چوونەژوورەوەی ئادمین</button></div>';
    return (pv ? '<button class="sx-x" id="sx-x">داخستنی پێشبینین ✕</button>' : '') + x;
  }
  function bindOv(k) {
    var x = $('#sx-x', ov); if (x) x.onclick = function () { pv = null; paint(); };
    var a = $('#sx-adm', ov); if (a) a.onclick = function () { try { SS.setItem('sx_peek', '1'); } catch (e) {} paint(); };
    if (k !== 'lock') return;
    var i = $('#sx-in', ov), c1 = $('#sx-c1', ov), c2 = $('#sx-c2', ov), er = $('#sx-er', ov), go = $('#sx-go', ov);
    function chips() { var d = i.value.replace(/\D/g, '').length, l = i.value.length - d; c1.textContent = d + '/6 ژمارە'; c2.textContent = l + '/4 پیتی کەپیتەڵ'; c1.className = d === 6 ? 'ok' : ''; c2.className = l === 4 ? 'ok' : ''; }
    i.oninput = function () { i.value = norm(i.value); er.textContent = ''; chips(); };
    function bad(t) { er.textContent = t; i.classList.remove('shake'); void i.offsetWidth; i.classList.add('shake'); }
    function submit() {
      if (pv) { pv = null; paint(); return; }
      var f = jg(FK, { n: 0, u: 0 }), c = i.value;
      if (now() < f.u) return bad('هەوڵی زۆرت دا. ' + Math.ceil((f.u - now()) / 1000) + ' چرکە چاوەڕێ بکە.');
      if (!codeOk(c)) return bad('کۆدەکە دەبێت ٦ ژمارە و ٤ پیتی کەپیتەڵ بێت.');
      var h1 = st && st.lock ? sha256(st.lock.s + ':' + c) : '';
      if (st && st.lock && sha256('2:' + h1) === st.lock.h) { js(UK, { v: st.lock.v, k: h1 }); js(FK, { n: 0, u: 0 }); paint(); return; }
      f.n++; if (f.n >= 5) f.u = now() + Math.min(600, 30 * Math.pow(2, f.n - 5)) * 1000; js(FK, f);
      bad(f.n >= 5 ? 'کۆدەکە هەڵەیە. بۆ ماوەیەک بلۆک کرایت.' : 'کۆدەکە هەڵەیە. ' + (5 - f.n) + ' هەوڵ ماوە.');
    }
    go.onclick = submit; i.onkeydown = function (e) { if (e.key === 'Enter') submit(); };
  }
  function paint() {
    var adm = isAdmin(), real = pv ? pv.k : (adm ? null : view()), k = real, s = pv ? pv.s : st;
    if (!pv && k) { try { if (SS.getItem('sx_peek') && D.body.classList.contains('app-locked')) k = null; } catch (e) {} }
    if (!ov) ov = mk('sx-ov');
    if (!real) { var pre = $('#sx-pre'); if (pre) pre.remove(); }
    if (k) {
      var sig = k + '|' + (s.rev || 0) + '|' + (pv ? 'p' : '');
      if (ov.__s !== sig) { ov.__s = sig; ov.style.setProperty('--ac', KM[k].c); ov.innerHTML = body(k, s); bindOv(k); }
      ov.classList.add('on');
      
    } else {
      if (ov.__s) { ov.__s = ''; ov.classList.remove('on'); ov.innerHTML = ''; }
    }
    try { if (real === 'hold' && !pv) SS.setItem('sx_held', '1'); else if (!real && !pv && !adm && SS.getItem('sx_held')) { SS.removeItem('sx_held'); reload(); } } catch (e) {}
    /* what's-new notice (once per release) */
    var u = st && st.upd, need = !adm && !pv && !k && u && !u.hold && u.rid && jg(SK, '') !== u.rid && !D.body.classList.contains('app-locked') && !window.mfApplyUpdate;
    if (!an) an = mk('sx-an');
    if (need) {
      if (an.__r !== u.rid) {
        an.__r = u.rid;
        an.innerHTML = '<div class="sx-c"><div class="sx-i">' + svg('down', 44) + '</div><h1>' + esc(u.title || 'وەشانێکی نوێ بەردەستە') + '</h1>' + (u.ver ? '<span class="sx-pill">' + esc(u.ver) + '</span>' : '') +
          '<ul class="sx-l">' + (u.notes || []).map(function (n) { return '<li>' + svg('ok', 18) + '<span>' + esc(n) + '</span></li>'; }).join('') + '</ul>' +
          '<button class="sx-b" id="sx-up">نوێکردنەوە ئێستا</button><button class="sx-b2" id="sx-lt">دواتر</button></div>';
        var done = function () { js(SK, u.rid); paint(); };
        $('#sx-up', an).onclick = function () { js(SK, u.rid); this.textContent = 'نوێ دەکرێتەوە...'; (window.mfApplyUpdate ? window.mfApplyUpdate() : reload()); };
        $('#sx-lt', an).onclick = done;
      }
      an.classList.add('on');
    } else if (an.__r) { an.__r = ''; an.classList.remove('on'); an.innerHTML = ''; }
    /* fixed pre-pause warning */
    var p = st && st.pause, t = now(), showB = !adm && p && t < p.from;
    if (!bn) bn = mk('sx-bn');
    if (showB) {
      if (bn.__r !== st.rev) { bn.__r = st.rev; bn.innerHTML = svg('timer', 22) + '<div><b>سیستەمەکە دوای <em id="sx-bt"></em> دەوەستێت</b><small>' + esc(p.msg || 'کارەکانت تەواو بکە و پاشەکەوتی بکە.') + '</small></div>'; }
      bn.classList.add('on');
    } else if (bn.__r) { bn.__r = ''; bn.classList.remove('on'); bn.innerHTML = ''; }
  }
  function tick() {
    var s = pv ? pv.s : st, t = now();
    if (ov && ov.__s && ov.__s.indexOf('pause') === 0 && s && s.pause) {
      var p = s.pause, q = parts(p.to - t), a = $('#sx-h', ov);
      if (a) { a.textContent = p2(q.h); $('#sx-m', ov).textContent = p2(q.m); $('#sx-s', ov).textContent = p2(q.s); $('#sx-pb', ov).style.setProperty('--p', Math.min(100, Math.max(0, (t - p.from) / (p.to - p.from) * 100)) + '%'); }
    }
    if (ov && ov.__s && (!ov.firstChild || !D.body.contains(ov))) { ov.__s = ''; if (!D.body.contains(ov)) D.body.appendChild(ov); }
    if (ov && ov.__s && !ov.classList.contains('on')) ov.classList.add('on');
    var e = $('#sx-bt'); if (e && st && st.pause) e.textContent = fmt(st.pause.from - t);
    D.querySelectorAll('#sysctl-dashboard [data-cd]').forEach(function (n) { n.textContent = fmt(+n.getAttribute('data-cd') - t); });
    paint();
  }

  /* ---- network ---- */
  function apply(d) { st = d; js(CK, d); paint(); renderAdmin(true); }
  window.__mfSysState = function () { return st; };
  function pull() {
    if (!window.__mfSync || !navigator.onLine || D.hidden) return;
    window.__mfSync.api('sync_records?select=data&key=eq.' + KEY + '&path=eq.&limit=1').then(function (r) {
      var d = (r && r[0] && r[0].data) || { rev: 0 };
      if (!st || d.rev !== st.rev) apply(d);
    }).catch(function () {});
  }
  function calib() {
    try { fetch(SBU + '/auth/v1/health', { headers: { apikey: SBK }, cache: 'no-store' }).then(function (r) { var d = r.headers.get('date'); if (d) { var o = Date.parse(d) - Date.now(); if (Math.abs(o) < 864e5) off = o; } }).catch(function () {}); } catch (e) {}
  }
  function save(mut) {
    if (!isAdmin()) return Promise.reject(new Error('تەنیا ئادمین'));
    if (!window.__mfSync) return Promise.reject(new Error('NOAUTH'));
    var n = JSON.parse(JSON.stringify(st || {})); mut(n); n.rev = Date.now();
    return window.__mfSync.api('sync_records?on_conflict=key,path', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify([{ key: KEY, path: '', data: n, deleted: false, device: 'sysctl' }]) }).then(function () { apply(n); });
  }

  /* ---- admin panel (box 15) ---- */
  function toast(m) { if (!tt) tt = mk('sx-toast'); tt.textContent = m; tt.classList.add('on'); clearTimeout(tt.__t); tt.__t = setTimeout(function () { tt.classList.remove('on'); }, 2600); }
  function warn(m) { window.mfDialog && window.mfDialog.alert ? window.mfDialog.alert(m, { title: 'ناتوانرێت', type: 'err' }) : alert(m); }
  function ask(m, o) { return window.mfDialog && window.mfDialog.confirm ? window.mfDialog.confirm(m, o) : Promise.resolve(confirm(m)); }
  function put(mut, ok) {
    return save(mut).then(function () { toast(ok || 'جێبەجێ کرا ✓'); return true; }, function (e) {
      warn(e.message === 'NOAUTH' ? 'گونجاندن لەگەڵ سێرڤەر چالاک نییە. سەرەتا لە ئایکۆنی هەور (cloud) بچۆ ژوورەوە.' : 'نەنێردرا: ' + (e.message || 'هەڵەی ئینتەرنێت')); return false;
    });
  }
  function mode(s) { var t = now(); if (s.closed && s.closed.on) return 'closed'; if (s.upd && s.upd.hold) return 'hold'; var p = s.pause; if (p && t < p.to) return t >= p.from ? 'pause' : 'soon'; return 'open'; }
  var HM = {
    open: ['#22c55e', 'سیستەم کراوەیە', 'هەموو بەکارهێنەران بەئاسایی کار دەکەن.'],
    closed: ['#ff4d6d', 'سیستەم بە تەواوی داخراوە', 'هیچ بەکارهێنەرێک ناتوانێت کار بکات.'],
    pause: ['#ffb020', 'سیستەم وەستێندراوە', 'دوای کۆتایی کات خۆکار دەکرێتەوە.'],
    soon: ['#ffb020', 'وەستاندن نزیکە', 'ئاگاداری جێگیر بۆ بەکارهێنەران نیشان دەدرێت.'],
    hold: ['#22d3ee', 'سیستەم لە ئەپدێتدایە', 'تا کۆتایی ئەپدێت بەکارهێنەران چاوەڕێ دەکەن.']
  };
  var TABS = [['closed', 'power', 'داخستن', '#ff4d6d'], ['pause', 'timer', 'وەستاندن', '#ffb020'], ['upd', 'down', 'ئەپدێت', '#22d3ee'], ['lock', 'lock', 'قفڵ', '#34d399']];
  function fld(f, ph, rows, dir, cls) {
    return rows ? '<textarea class="sxa-f" rows="' + rows + '" data-f="' + f + '" placeholder="' + ph + '">' + esc(ui[f]) + '</textarea>'
      : '<input class="sxa-f ' + (cls || '') + '" ' + (dir ? 'dir="ltr" ' : '') + 'data-f="' + f + '" placeholder="' + ph + '" value="' + esc(ui[f]) + '">';
  }
  function btn(a, t, c) { return '<button class="sxa-b ' + (c || '') + '" data-a="' + a + '">' + t + '</button>'; }
  function adminHTML() {
    var s = st || {}, t = now(), md = mode(s), H = HM[md], u = s.upd, p = s.pause, lk = s.lock && s.lock.on, cl = s.closed && s.closed.on, ann = u && !u.hold && u.rid;
    var tab = TABS.filter(function (x) { return x[0] === ui.tab; })[0] || TABS[0], on = { closed: cl, pause: md === 'pause' || md === 'soon', upd: !!u, lock: lk }, b = '';
    if (tab[0] === 'closed') {
      b = '<h4>داخستنی تەواوی سیستەم</h4><p class="sxa-d">هەموو بەکارهێنەران پەیامی «سیستەم داخراوە» لە ناوەڕاستی شاشە دەبینن. تۆ هەمیشە سیستەم دەبینیت.</p>' +
        (cl ? '<div class="sxa-r">' + btn('open', 'کردنەوەی سیستەم', 'ok') + btn('pv:closed', 'پێشبینین', 'g') + '</div>'
          : fld('cmsg', 'پەیامی دڵخواز (ئارەزوومەندانە)', 2) + '<div class="sxa-r">' + btn('close', 'داخستنی سیستەم') + btn('pv:closed', 'پێشبینین', 'g') + '</div>');
    } else if (tab[0] === 'pause') {
      b = '<h4>وەستاندن بۆ ماوەیەک</h4><p class="sxa-d">کاتژمێری گەڕانەوە بۆ دواوە بۆ بەکارهێنەران، لەگەڵ ئاگاداری جێگیری پێش وەستاندن.</p>';
      if (p && t < p.to) {
        var go = t >= p.from;
        b += '<div class="sxa-big"><small>' + (go ? 'ماوە تا هەڵگیرسانەوە' : 'دەستپێدەکات دوای') + '</small><b data-cd="' + (go ? p.to : p.from) + '"></b></div><div class="sxa-r">' + btn('pcancel', go ? 'هەڵگیرساندنەوە ئێستا' : 'هەڵوەشاندنەوە', 'ok') + btn('pv:pause', 'پێشبینین', 'g') + '</div>';
      } else {
        b += '<div class="sxa-l">ماوەی وەستاندن</div><div class="sxa-tiles">' + [5, 15, 30, 60, 120, 180].map(function (d) { return '<button data-d="' + d + '" class="' + (!ui.pcus && ui.dur === d ? 'on' : '') + '"><b>' + (d < 60 ? d : d / 60) + '</b><small>' + (d < 60 ? 'خولەک' : 'کاتژمێر') + '</small></button>'; }).join('') + '</div>' +
          fld('pcus', 'یان ژمارەی خولەک بنووسە', 0, 1) +
          '<div class="sxa-l">ئاگاداری جێگیر پێش وەستاندن</div><div class="sxa-chs">' + [0, 2, 5, 10].map(function (l) { return '<button data-l="' + l + '" class="' + (ui.lead === l ? 'on' : '') + '">' + (l ? l + ' خولەک پێشتر' : 'دەستبەجێ') + '</button>'; }).join('') + '</div>' +
          fld('pmsg', 'هۆکار / پەیام (ئارەزوومەندانە)', 2) + '<div class="sxa-r">' + btn('pause', 'وەستاندنی سیستەم') + btn('pv:pause', 'پێشبینین', 'g') + '</div>';
      }
    } else if (tab[0] === 'upd') {
      b = '<h4>ئەپدێتی سیستەم</h4><p class="sxa-d">ئاگاداری وەشانی نوێ بنێرە، یان سیستەم ڕابگرە تا ئەپدێت تەواو دەبێت.</p>' + fld('ver', 'وەشان، نموونە V1.2.0', 0, 1) + fld('utitle', 'ناونیشان', 0) + fld('notes', 'هەر دێڕێک = یەک نوێکاری', 4);
      b += u && u.hold ? '<div class="sxa-r">' + btn('release', 'کۆتایی ئەپدێت — کردنەوە', 'ok') + btn('pv:hold', 'پێشبینین', 'g') + '</div>'
        : '<div class="sxa-r">' + btn('ann', 'ناردنی ئاگاداری') + btn('hold', 'ڕاگرتن بۆ ئەپدێت', 'alt') + '</div><div class="sxa-r">' + btn('pv:hold', 'پێشبینینی ڕاگرتن', 'g') + (ann ? btn('annrm', 'سڕینەوەی ئاگاداری', 'g') : '') + '</div>';
    } else {
      var ac = LS.getItem(AK);
      b = '<h4>قفڵکردنی سیستەم</h4><p class="sxa-d">هەر بەکارهێنەرێک دەبێت کۆدی نهێنی (٦ ژمارە + ٤ پیتی کەپیتەڵ) یەکجار بنووسێت.</p>' + (lk && ac ? '<div class="sxa-l">کۆدی ئێستا</div><div class="sxa-code" dir="ltr">' + esc(ac) + '</div>' : '') +
        '<div class="sxa-l">' + (lk ? 'گۆڕینی کۆد' : 'کۆدی نوێ') + '</div>' + fld('code', '123456ABCD', 0, 1, 'sxa-cd') + '<div class="sxa-hint" id="sx-hint"></div>' +
        '<div class="sxa-r">' + btn('rand', 'ڕاندۆم', 'g') + btn('lockset', lk ? 'گۆڕین' : 'چالاککردنی قفڵ') + '</div>' + (lk ? '<div class="sxa-r">' + btn('lockrm', 'لابردنی قفڵ', 'g') + btn('pv:lock', 'پێشبینین', 'g') + '</div>' : '');
    }
    return '<div class="sxa" style="--ac:' + tab[3] + '"><div class="sxa-hero" style="--hc:' + H[0] + '"><div class="sxa-ring">' + svg(md === 'open' ? 'ok' : md === 'closed' ? 'power' : md === 'hold' ? 'down' : 'timer', 30) + '</div><div class="sxa-ht"><small>دۆخی ئێستای سیستەم</small><h3>' + H[1] + '</h3><p>' + H[2] +
      (md === 'pause' ? ' <b data-cd="' + p.to + '"></b>' : md === 'soon' ? ' <b data-cd="' + p.from + '"></b>' : '') + '</p></div></div>' +
      '<nav class="sxa-tabs">' + TABS.map(function (x) { return '<button data-t="' + x[0] + '" class="' + (x[0] === tab[0] ? 'on' : '') + '" style="--tc:' + x[3] + '">' + (on[x[0]] ? '<i></i>' : '') + svg(x[1], 21) + '<span>' + x[2] + '</span></button>'; }).join('') + '</nav>' +
      '<div class="sxa-pn">' + b + '</div></div>';
  }
  function hint() { var e = $('#sx-hint'); if (!e) return; var c = ui.code, d = c.replace(/\D/g, '').length, l = c.length - d; e.textContent = d + '/6 ژمارە · ' + l + '/4 پیتی کەپیتەڵ'; e.className = 'sxa-hint' + (codeOk(c) ? ' ok' : ''); }
  function renderAdmin(soft) {
    var el = $('#sysctl-dashboard'); if (!el || el.style.display === 'none') return;
    if (!isAdmin()) { el.innerHTML = '<div class="sxa-deny">' + svg('lock', 34) + '<b>ئەم بەشە تەنیا بۆ ئادمینە</b></div>'; return; }
    if (soft && el.contains(D.activeElement) && /INPUT|TEXTAREA/.test(D.activeElement.tagName)) return;
    el.innerHTML = adminHTML(); hint();
  }
  function preview(k) {
    var n = now();
    pv = { k: k, s: { rev: 'pv', closed: { on: true, msg: ui.cmsg }, pause: { from: n, to: n + ((+ui.pcus || ui.dur) * 60000), msg: ui.pmsg }, upd: { hold: true, ver: ui.ver }, lock: { on: true } } };
    paint();
  }
  function act(a) {
    if (!isAdmin()) return;
    if (a.indexOf('pv:') === 0) return preview(a.slice(3));
    var dur = +ui.pcus || ui.dur, notes = ui.notes.split('\n').map(function (x) { return x.trim(); }).filter(Boolean);
    function upd(hold) { return { rid: rid(), ver: ui.ver.trim(), title: ui.utitle.trim(), notes: notes, hold: hold, at: now() }; }
    if (a === 'rand') { ui.code = genCode(); renderAdmin(); }
    else if (a === 'close') ask('هەموو بەکارهێنەران (جگە لە تۆ) ناتوانن سیستەمەکە بەکاربهێنن تا خۆت بیکەیتەوە.', { title: 'داخستنی تەواوی سیستەم', type: 'danger', icon: 'power', ok: 'بەڵێ، دایبخە', cancel: 'پاشگەزبوونەوە' }).then(function (y) { if (y) put(function (n) { n.closed = { on: true, msg: ui.cmsg.trim(), at: now() }; }, 'سیستەم داخرا'); });
    else if (a === 'open') put(function (n) { n.closed = null; }, 'سیستەم کرایەوە');
    else if (a === 'pause') { if (!(dur > 0 && dur <= 1440)) return warn('ماوەی وەستاندن دەبێت لە ١ تا ١٤٤٠ خولەک بێت.'); put(function (n) { var f = now() + ui.lead * 60000; n.pause = { from: f, to: f + dur * 60000, msg: ui.pmsg.trim() }; }, ui.lead ? 'ئاگاداری وەستاندن نێردرا' : 'سیستەم وەستێندرا'); }
    else if (a === 'pcancel') put(function (n) { n.pause = null; }, 'سیستەم هەڵگیرسایەوە');
    else if (a === 'ann' || a === 'hold') {
      if (!ui.ver.trim() && !ui.utitle.trim() && !notes.length && a === 'ann') return warn('لانی کەم وەشان یان ناونیشان یان یەک تایبەتمەندی بنووسە.');
      var vv = ui.ver.trim(), cur = window.mfCurrentVersion ? window.mfCurrentVersion() : '';
      if (a === 'ann' && !vv) return warn('ژمارەی وەشانی نوێ بنووسە (بۆ نموونە ' + (window.mfNextVersion ? window.mfNextVersion() : 'V1.0.2') + '). بێ ژمارەی وەشان ئاگادارییەکە بۆ بەکارهێنەران نیشان نادرێت.');
      if (vv && cur && window.mfIsNewer && !window.mfIsNewer(vv, cur)) return warn('ژمارەی وەشان («' + vv + '») دەبێت لە وەشانی ئێستا («' + cur + '») نوێتر بێت، دەنا ئاگادارییەکە هیچ کات نیشان نادرێت.');
      var go = function () { put(function (n) { n.upd = upd(a === 'hold'); }, a === 'hold' ? 'سیستەم ڕاگیرا' : 'ئاگاداری نێردرا'); };
      a === 'hold' ? ask('سیستەم بۆ هەموو بەکارهێنەران ڕادەگیرێت و «لە بارکردنی وەشانی نوێدایە» نیشان دەدرێت تا کۆتایی ئەپدێت بێنیت.', { title: 'ڕاگرتن بۆ ئەپدێت', type: 'warn', icon: 'power', ok: 'ڕایبگرە', cancel: 'پاشگەزبوونەوە' }).then(function (y) { if (y) go(); }) : go();
    }
    else if (a === 'release') put(function (n) { var u = n.upd || {}; n.upd = (u.ver || u.title || (u.notes || []).length) ? { rid: rid(), ver: u.ver, title: u.title, notes: u.notes, hold: false, at: now() } : null; }, 'ئەپدێت تەواو بوو، سیستەم کرایەوە');
    else if (a === 'annrm') put(function (n) { n.upd = null; }, 'ئاگاداری سڕایەوە');
    else if (a === 'lockset') {
      if (!codeOk(ui.code)) return warn('کۆدەکە دەبێت دەقاودەق ٦ ژمارە و ٤ پیتی کەپیتەڵ بێت (١٠ نیشانە).');
      var code = ui.code;
      ask('هەموو بەکارهێنەران (جگە لە تۆ) دەبێت ئەم کۆدە بنووسن تا سیستەمەکە بۆیان بکرێتەوە.', { title: 'قفڵکردنی سیستەم', type: 'warn', icon: 'lock', ok: 'قفڵی بکە', cancel: 'پاشگەزبوونەوە' }).then(function (y) {
        if (!y) return;
        var salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
        put(function (n) { n.lock = { on: true, s: salt, h: sha256('2:' + sha256(salt + ':' + code)), v: rid() }; }, 'سیستەم قفڵکرا').then(function (ok) { if (!ok) return; try { LS.setItem(AK, code); } catch (e) {} ui.code = ''; renderAdmin(); });
      });
    }
    else if (a === 'lockrm') put(function (n) { n.lock = null; }, 'قفڵ لابرا').then(function (ok) { if (ok) try { LS.removeItem(AK); } catch (e) {} });
  }

  D.addEventListener('click', function (e) {
    var el = $('#sysctl-dashboard'); if (!el || !el.contains(e.target)) return;
    var b = e.target.closest('[data-a],[data-d],[data-l],[data-t]'); if (!b) return;
    if (b.hasAttribute('data-t')) { ui.tab = b.getAttribute('data-t'); renderAdmin(); return; }
    if (b.hasAttribute('data-d')) { ui.dur = +b.getAttribute('data-d'); ui.pcus = ''; var c = $('[data-f=pcus]', el); if (c) c.value = ''; }
    if (b.hasAttribute('data-l')) ui.lead = +b.getAttribute('data-l');
    if (b.hasAttribute('data-d') || b.hasAttribute('data-l')) { b.parentNode.querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); }); return; }
    act(b.getAttribute('data-a'));
  });
  D.addEventListener('input', function (e) {
    var t = e.target, f = t.getAttribute && t.getAttribute('data-f'); if (!f || !t.closest('#sysctl-dashboard')) return;
    if (f === 'code') { t.value = norm(t.value); }
    if (f === 'pcus') { t.value = t.value.replace(/\D/g, '').slice(0, 4); if (t.value) t.parentNode.querySelectorAll('[data-d]').forEach(function (x) { x.classList.remove('on'); }); }
    ui[f] = t.value; if (f === 'code') hint();
  });

  window.mfSysctlOpen = function () { renderAdmin(); pull(); };
  window.__mfSysctl = { state: function () { return st; }, pull: pull };

  /* ---- styles ---- */
  var st_ = D.createElement('style'); st_.id = 'mf-sysctl-css';
  st_.textContent = [
    '#sx-ov,#sx-an{position:fixed;inset:0;z-index:2147483600;display:none;padding:20px;direction:rtl;font-family:var(--main-font,system-ui,sans-serif);color:#fff;overflow:auto;-webkit-overflow-scrolling:touch;box-sizing:border-box}',
    '#sx-ov.on,#sx-an.on{display:flex!important;visibility:visible!important;opacity:1!important}',
    'html body.app-locked>#sx-ov.on:not(#_a):not(#_b):not(#_c),html body.app-locked>#sx-an.on:not(#_a):not(#_b):not(#_c){display:flex!important}',
    'html body.app-locked>#sx-bn.on:not(#_a):not(#_b):not(#_c){display:flex!important}html body.app-locked>#sx-toast.on:not(#_a):not(#_b):not(#_c){display:block!important}',
    '#sx-ov{background:#070a13;--ac:#ff4d6d}',
    '#sx-ov::before,#sx-ov::after{content:"";position:absolute;width:420px;height:420px;border-radius:50%;filter:blur(90px);background:var(--ac);opacity:.36;pointer-events:none}',
    '#sx-ov::before{top:-170px;right:-150px}#sx-ov::after{bottom:-210px;left:-170px;opacity:.2}',
    '#sx-an{background:rgba(5,8,18,.74);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);--ac:#22d3ee}',
    '.sx-c{position:relative;z-index:1;width:100%;max-width:400px;margin:auto;padding:0 24px 24px;border-radius:32px;background:linear-gradient(180deg,rgba(255,255,255,.1),rgba(255,255,255,.03)),#0d1220;border:1px solid rgba(255,255,255,.14);box-shadow:0 30px 80px rgba(0,0,0,.55);text-align:center;animation:sxIn .55s cubic-bezier(.2,.9,.3,1)}',
    '.sx-i{width:88px;height:88px;margin:34px auto 20px;border-radius:30px;display:grid;place-items:center;background:var(--ac);color:#0a0d16;box-shadow:0 0 0 9px color-mix(in srgb,var(--ac) 16%,transparent),0 18px 46px color-mix(in srgb,var(--ac) 50%,transparent);animation:sxHalo 2.8s ease-in-out infinite}',
    '.sx-c h1{margin:0 0 10px;font-size:25px;font-weight:900;line-height:1.45;color:#fff}',
    '.sx-c p{margin:0;font-size:14.5px;line-height:1.95;color:rgba(255,255,255,.76);white-space:pre-line}',
    '.sx-t{display:flex;gap:9px;justify-content:center;direction:ltr;margin:22px 0 4px}',
    '.sx-t div{flex:1;max-width:96px;padding:12px 4px 9px;border-radius:20px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12)}',
    '.sx-t b{display:block;font:900 36px/1.1 system-ui,sans-serif;font-variant-numeric:tabular-nums}.sx-t small{font-size:11px;font-weight:700;opacity:.62}',
    '.sx-bar{height:6px;margin-top:16px;border-radius:6px;background:rgba(255,255,255,.1);overflow:hidden}',
    '.sx-bar i{display:block;height:100%;width:var(--p,0%);background:var(--ac);border-radius:6px;transition:width 1s linear}',
    '.sx-bar.ind i{width:36%;transition:none;animation:sxInd 1.5s ease-in-out infinite}',
    '.sx-n{margin-top:14px;font-size:13px;font-weight:800;color:var(--ac)}',
    '.sx-pill{display:inline-block;margin-top:14px;padding:5px 14px;border-radius:99px;font:800 13px system-ui,sans-serif;direction:ltr;background:color-mix(in srgb,var(--ac) 18%,transparent);color:var(--ac);border:1px solid color-mix(in srgb,var(--ac) 40%,transparent)}',
    '.sx-in{width:100%;box-sizing:border-box;margin-top:20px;padding:16px 8px;border-radius:18px;border:1.5px solid rgba(255,255,255,.22);background:rgba(255,255,255,.07);color:#fff;font:900 24px/1 ui-monospace,Menlo,monospace;letter-spacing:.26em;text-align:center;direction:ltr;outline:0;text-transform:uppercase}',
    '.sx-in:focus{border-color:var(--ac);box-shadow:0 0 0 4px color-mix(in srgb,var(--ac) 20%,transparent)}.sx-in.shake{animation:sxShake .4s}',
    '.sx-ch{display:flex;gap:8px;justify-content:center;margin-top:12px}.sx-ch span{padding:4px 11px;border-radius:99px;font-size:12px;font-weight:800;background:rgba(255,255,255,.08);color:rgba(255,255,255,.6)}.sx-ch span.ok{background:color-mix(in srgb,var(--ac) 25%,transparent);color:var(--ac)}',
    '.sx-e{min-height:20px;margin-top:10px;font-size:13px;font-weight:800;color:#ffb4b4}',
    '.sx-b,.sx-b2{display:block;width:100%;margin-top:12px;padding:15px;border:0;border-radius:18px;font:900 16px var(--main-font,inherit);cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.sx-b{background:var(--ac);color:#0a0d16;box-shadow:0 12px 28px color-mix(in srgb,var(--ac) 40%,transparent)}.sx-b:active{transform:scale(.97)}.sx-b2{background:transparent;color:rgba(255,255,255,.7)}',
    '.sx-a{display:none;margin:16px auto 0;background:none;border:0;color:rgba(255,255,255,.4);font:700 12px var(--main-font,inherit);text-decoration:underline;cursor:pointer;padding:6px}body.app-locked .sx-a{display:block}',
    '.sx-x{position:fixed;top:calc(12px + env(safe-area-inset-top,0px));left:12px;z-index:5;padding:10px 16px;border:0;border-radius:99px;background:#fff;color:#111;font:900 13px var(--main-font,inherit);box-shadow:0 8px 24px rgba(0,0,0,.4)}',
    '.sx-l{list-style:none;margin:18px 0 0;padding:0;text-align:right;display:grid;gap:10px}.sx-l li{display:flex;gap:10px;align-items:flex-start;font-size:14px;line-height:1.7;color:rgba(255,255,255,.9)}.sx-l svg{flex:none;margin-top:3px;color:var(--ac)}',
    '#sx-bn{position:fixed;top:calc(8px + env(safe-area-inset-top,0px));left:10px;right:10px;max-width:460px;margin:0 auto;z-index:2147483500;display:none;align-items:center;gap:12px;padding:12px 16px;border-radius:20px;direction:rtl;pointer-events:none;color:#fff;font-family:var(--main-font,inherit);background:rgba(28,19,4,.92);border:1.5px solid #ffb020;box-shadow:0 14px 34px rgba(0,0,0,.4),0 0 0 4px rgba(255,176,32,.14)}',
    '#sx-bn.on{display:flex}#sx-bn svg{flex:none;color:#ffb020}#sx-bn b{display:block;font-size:14px;font-weight:900}#sx-bn em{font:900 15px system-ui;font-style:normal;direction:ltr;display:inline-block;color:#ffb020}#sx-bn small{display:block;margin-top:2px;font-size:12px;opacity:.75}',
    '#sx-toast{position:fixed;left:50%;bottom:calc(96px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:2147483550;display:none;max-width:90vw;padding:12px 18px;border-radius:99px;background:#111827;color:#fff;font:800 13px var(--main-font,inherit);box-shadow:0 12px 30px rgba(0,0,0,.35)}#sx-toast.on{display:block}',
    '@keyframes sxIn{from{opacity:0;transform:translateY(26px) scale(.96)}to{opacity:1;transform:none}}',
    '@keyframes sxHalo{0%,100%{box-shadow:0 0 0 9px color-mix(in srgb,var(--ac) 16%,transparent),0 18px 46px color-mix(in srgb,var(--ac) 50%,transparent)}50%{box-shadow:0 0 0 20px color-mix(in srgb,var(--ac) 4%,transparent),0 18px 56px color-mix(in srgb,var(--ac) 60%,transparent)}}',
    '@keyframes sxInd{0%{transform:translateX(300%)}100%{transform:translateX(-300%)}}@keyframes sxShake{20%,60%{transform:translateX(-7px)}40%,80%{transform:translateX(7px)}}@keyframes sxPulse{50%{box-shadow:0 0 0 12px transparent}}',
    '@media(prefers-reduced-motion:reduce){.sx-c,.sx-i,.sx-bar.ind i,.sxa-dot{animation:none!important}}',
    /* admin panel */
    '.sxa{--ac:#ff4d6d;display:grid;gap:12px;padding:14px;margin-bottom:30px;border-radius:32px;color:#eef1ff;background:radial-gradient(120% 70% at 100% 0%,color-mix(in srgb,var(--ac) 24%,transparent),transparent 62%),#0a0f1e;border:1px solid rgba(255,255,255,.08);box-shadow:0 26px 60px rgba(6,9,24,.4);transition:background .4s}',
    '.sxa-hero{display:flex;align-items:center;gap:14px;padding:16px;border-radius:26px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09)}',
    '.sxa-ring{width:62px;height:62px;flex:none;border-radius:50%;display:grid;place-items:center;color:var(--hc);background:color-mix(in srgb,var(--hc) 16%,#0a0f1e);border:2px solid var(--hc);animation:sxPulse 2.4s infinite;box-shadow:0 0 28px color-mix(in srgb,var(--hc) 45%,transparent)}',
    '.sxa-ht{min-width:0}.sxa-ht small{font-size:11.5px;font-weight:800;opacity:.55}.sxa-ht h3{margin:2px 0 0;font-size:20px;font-weight:900;color:#fff;line-height:1.35}.sxa-ht p{margin:4px 0 0;font-size:12.5px;line-height:1.7;opacity:.72}.sxa-ht b{font:900 14px system-ui;direction:ltr;display:inline-block;color:var(--hc);opacity:1}',
    '.sxa-tabs{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;padding:5px;border-radius:22px;background:rgba(255,255,255,.05)}',
    '.sxa-tabs button{position:relative;display:flex;flex-direction:column;align-items:center;gap:5px;padding:10px 2px 8px;border:0;border-radius:17px;background:transparent;color:rgba(255,255,255,.55);font:800 11.5px var(--main-font,inherit);cursor:pointer;transition:.25s;-webkit-tap-highlight-color:transparent}',
    '.sxa-tabs button.on{background:var(--tc);color:#0a0f1e;box-shadow:0 8px 22px color-mix(in srgb,var(--tc) 45%,transparent)}.sxa-tabs i{position:absolute;top:6px;right:8px;width:7px;height:7px;border-radius:50%;background:var(--tc);box-shadow:0 0 0 3px color-mix(in srgb,var(--tc) 30%,transparent)}.sxa-tabs .on i{background:#0a0f1e;box-shadow:none}',
    '.sxa-pn{padding:16px;border-radius:26px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);animation:sxIn .35s cubic-bezier(.2,.9,.3,1)}',
    '.sxa-pn h4{margin:0;font-size:17px;font-weight:900;color:#fff}.sxa-d{margin:6px 0 4px;font-size:12.5px;font-weight:600;line-height:1.85;color:rgba(255,255,255,.6)}',
    '.sxa-l{margin:14px 0 0;font-size:12px;font-weight:900;color:var(--ac)}',
    '.sxa-f{display:block;width:100%;box-sizing:border-box;margin-top:10px;padding:13px 15px;border-radius:16px;border:1.5px solid rgba(255,255,255,.12);background:rgba(255,255,255,.06);color:#fff;font:700 14px var(--main-font,inherit);outline:0;resize:vertical}.sxa-f::placeholder{color:rgba(255,255,255,.35)}.sxa-f:focus{border-color:var(--ac);box-shadow:0 0 0 4px color-mix(in srgb,var(--ac) 18%,transparent)}',
    '.sxa-tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:9px}.sxa-tiles button{display:flex;flex-direction:column;align-items:center;gap:1px;padding:12px 4px;border-radius:18px;border:1.5px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:#fff;cursor:pointer;font-family:inherit}.sxa-tiles b{font:900 24px/1.1 system-ui;font-variant-numeric:tabular-nums}.sxa-tiles small{font-size:11px;font-weight:700;opacity:.6}',
    '.sxa-tiles button.on{background:var(--ac);border-color:var(--ac);color:#0a0f1e;box-shadow:0 8px 22px color-mix(in srgb,var(--ac) 40%,transparent)}',
    '.sxa-chs{display:flex;flex-wrap:wrap;gap:7px;margin-top:9px}.sxa-chs button{padding:9px 14px;border-radius:99px;border:1.5px solid rgba(255,255,255,.14);background:transparent;color:rgba(255,255,255,.75);font:800 12.5px var(--main-font,inherit);cursor:pointer}.sxa-chs button.on{background:var(--ac);border-color:var(--ac);color:#0a0f1e}',
    '.sxa-big{margin:14px 0 2px;padding:18px;border-radius:22px;text-align:center;background:color-mix(in srgb,var(--ac) 14%,transparent);border:1px solid color-mix(in srgb,var(--ac) 40%,transparent)}.sxa-big small{display:block;font-size:12px;font-weight:800;opacity:.7}.sxa-big b{display:block;margin-top:4px;font:900 44px/1.1 system-ui;direction:ltr;font-variant-numeric:tabular-nums;color:var(--ac)}',
    '.sxa-r{display:flex;gap:8px;margin-top:14px}.sxa-b{flex:1;padding:14px 10px;border:0;border-radius:18px;font:900 14px var(--main-font,inherit);color:#0a0f1e;background:linear-gradient(135deg,var(--ac),color-mix(in srgb,var(--ac) 62%,#fff));box-shadow:0 12px 26px color-mix(in srgb,var(--ac) 32%,transparent);cursor:pointer;-webkit-tap-highlight-color:transparent}.sxa-b:active{transform:scale(.97)}',
    '.sxa-b.g{background:transparent;box-shadow:none;color:#fff;border:1.5px solid rgba(255,255,255,.2);flex:.7}.sxa-b.ok{--ac:#22c55e}.sxa-b.alt{--ac:#818cf8}',
    '.sxa-cd{font:900 19px ui-monospace,Menlo,monospace;letter-spacing:.22em;text-align:center;text-transform:uppercase}.sxa-hint{margin-top:8px;font-size:12px;font-weight:800;color:rgba(255,255,255,.5)}.sxa-hint.ok{color:var(--ac)}',
    '.sxa-code{margin-top:8px;padding:14px;border-radius:18px;text-align:center;font:900 21px ui-monospace,Menlo,monospace;letter-spacing:.26em;background:color-mix(in srgb,var(--ac) 14%,transparent);color:var(--ac);border:1px dashed var(--ac);user-select:all}',
    '.sxa-deny{display:grid;place-items:center;gap:10px;padding:50px 20px;text-align:center;color:var(--text-sub,#71717a)}.sxa-deny b{font-size:15px}'
  ].join('\n');
  D.head.appendChild(st_);
  try { new MutationObserver(function () { if (ov && ov.__s && !D.body.contains(ov)) { D.body.appendChild(ov); } }).observe(D.body, { childList: true }); } catch (e) {}

  /* ---- start ---- */
  st = jg(CK, null);
  paint(); calib();
  setInterval(tick, 1000); setInterval(pull, 12000); setInterval(calib, 300000);
  D.addEventListener('visibilitychange', function () { if (!D.hidden) { calib(); pull(); } });
  addEventListener('online', pull);
  setTimeout(pull, 1500);
  try { var ls_ = JSON.parse(LS.getItem('mf_last_section') || 'null'); if (ls_ && ls_.title === 'بەڕێوەبردنی سیستەم' && typeof window.openCardDashboard === 'function') window.openCardDashboard(ls_.title, ls_.icon, ls_.color); } catch (e) {}
})();


