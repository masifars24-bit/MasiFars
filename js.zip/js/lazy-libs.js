window.mfEnsurePdfLibs=function(){
  if(window.__mfPdfLibsLoaded) return; window.__mfPdfLibsLoaded=true;
  document.querySelectorAll('script[type="text/plain"][data-mf-lazy]').forEach(function(t){
    var src=t.getAttribute('data-mf-src');
    if(src){
      fetch(src).then(function(r){return r.text();}).then(function(code){
        var sc=document.createElement('script'); sc.text=code; document.head.appendChild(sc);
      }).catch(function(e){console.warn('mf lazy lib fail',src,e);});
    } else {
      var sc=document.createElement('script'); sc.text=t.textContent; document.head.appendChild(sc);
    }
  });
};
