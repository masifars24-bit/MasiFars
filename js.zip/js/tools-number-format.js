(function(){
  function clean(v){ return String(v ?? '').replace(/,/g,'').trim(); }
  function format(v){
    var raw=clean(v);
    if(!raw || !/^-?\d+(?:\.\d+)?$/.test(raw)) return String(v ?? '');
    var parts=raw.split('.');
    var sign=''; if(parts[0].startsWith('-')){sign='-';parts[0]=parts[0].slice(1)}
    parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,',');
    return sign+parts[0]+(parts.length>1?'.'+parts[1]:'');
  }
  window.mfFormatNumberInputs=function(root){
    var scope=root||document;
    scope.querySelectorAll('input[type="text"][inputmode="numeric"],input[type="tel"][inputmode="numeric"]').forEach(function(el){
      if(el.dataset.mfNumberBound==='1') return;
      el.dataset.mfNumberBound='1'; el.classList.add('mf-number-formatted');
      el.addEventListener('input',function(){
        var pos=this.selectionStart, before=this.value, digitsBefore=clean(before.slice(0,pos)).length;
        this.value=format(this.value);
        var i=0, p=0; while(p<this.value.length && i<digitsBefore){if(/\d/.test(this.value[p]))i++;p++} this.setSelectionRange(p,p);
      });
      el.addEventListener('blur',function(){this.value=format(this.value)});
    });
  };
  window.mfOpenTools=function(){
    var sheet=document.getElementById('mf-tools-sheet');
    if(sheet){sheet.classList.add('active'); if(window.lucide) lucide.createIcons();}
  };
  window.mfCloseTools=function(){var sheet=document.getElementById('mf-tools-sheet');if(sheet)sheet.classList.remove('active')};
  document.addEventListener('DOMContentLoaded',function(){mfFormatNumberInputs();});
  new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType===1)mfFormatNumberInputs(n)})})}).observe(document.documentElement,{childList:true,subtree:true});
})();
