(function () {
  'use strict';
  if (window.__mfFirebase || window.__MF_VIEWER) return;
  var CFG = { apiKey: 'AIzaSyApG6jOGscKAFsXNMro9bS1XUe4WJJNTjA', authDomain: 'massi-fars.firebaseapp.com', projectId: 'massi-fars', storageBucket: 'massi-fars.firebasestorage.app', messagingSenderId: '354918137719', appId: '1:354918137719:web:0f24f5de0ee0598154eb72' };
  var BASE = 'https://www.gstatic.com/firebasejs/13.1.0/', COL = 'mf_sync', CHUNK = 250000;
  var LS = window.localStorage, proto = Storage.prototype;
  var prevSet = proto.setItem, prevRem = proto.removeItem, getRaw = proto.getItem;
  var LOCAL = { mf_theme: 1, mf_size: 1, mf_font: 1, mf_color: 1, mf_custom_width: 1, mf_custom_fonts: 1, mf_custom_colors: 1, mf_login_type: 1, mf_employee_session: 1, mf_admin_session: 1, mf_last_section: 1, mf_dock_hidden: 1, mf_bot_pos: 1, mf_chat_geom: 1, mf_notebook_current_page: 1, mf_adhan_notified_log: 1, mf_gemini_config: 1, mf_tables_layout_mode: 1, mf_tables_edit_locked: 1 };
  function syncable(k) {
    if (typeof k !== 'string' || k.indexOf('mf_') !== 0) return false;
    if (k.indexOf('mf_sync_') === 0 || k.indexOf('mf_login_fails_') === 0 || k.indexOf('mf_chat_') === 0 || k.indexOf('_corrupt_backup_') > -1) return false;
    return !LOCAL[k];
  }

  // ---- server status card (bottom of the cloud panel): S = Supabase, F = Firebase ----
  var CC = { red: '#d93a3a', orange: '#ff7a00', yellow: '#f2c200', green: '#1fa35a', blue: '#2f7df6', gray: '#8a8fa8' };
  var TXT = { red: 'ناچالاکە', orange: 'کێشەی هەیە', yellow: 'لاواز یان چاوەڕێ', green: 'باشە', blue: 'پەیوەندی پچڕاوە', gray: 'بەستنەوە...' };
  var QUOTA = /quota|exhaust|limit|full|exceed|storage|429|507|payload|too large|size/i;
  var NET = /network|offline|unavailable|failed to fetch|fetch|timeout|timed out|dynamically imported|load failed|connection|ئینتەرنێت|ئۆفلاین/i;
  var lastSb = null;
  function sbState(s) {
    if (!s) return 'gray';
    if (s.c === 'off') return 'red';
    if (!navigator.onLine) return 'blue';
    if (s.c === 'err') return NET.test(s.err || '') ? 'blue' : QUOTA.test(s.err || '') ? 'yellow' : 'orange';
    if (s.c === 'pend') return 'yellow';
    return 'green';
  }
  function fbState() {
    if (!navigator.onLine) return 'blue';
    if (!status.ready) { if (!status.err) return 'gray'; return NET.test(status.err) ? 'blue' : 'red'; }
    if (status.err) return NET.test(status.err) ? 'blue' : QUOTA.test(status.err) ? 'yellow' : 'orange';
    if (busy || Object.keys(dirty).length) return 'yellow';
    return 'green';
  }
  function cloud(letter, color) {
    return '<svg viewBox="0 0 24 24" width="38" height="38" fill="none" stroke="' + color + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 19a4.5 4.5 0 0 0 .5-8.97A6 6 0 0 0 6.34 8.6 4.8 4.8 0 0 0 7 19z"/><text x="12" y="16" text-anchor="middle" font-size="9" font-weight="800" font-family="system-ui,sans-serif" fill="' + color + '" stroke="none">' + letter + '</text></svg>';
  }
  function fbDetail() {
    var n = Object.keys(dirty).length;
    if (status.err) return String(status.err).slice(0, 90);
    if (!navigator.onLine) return 'ئۆفلاین';
    if (!status.ready) return '';
    if (busy && status.cur) return 'ناردن: ' + status.cur.replace(/^mf_/, '') + ' (' + n + ' ماوە)';
    return n ? n + ' گۆڕانکاری چاوەڕێیە' : '';
  }
  function item(name, letter, st, detail) {
    return '<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;min-width:0">' + cloud(letter, CC[st]) +
      '<b style="font-size:13px;font-weight:900">' + mfEsc(name) + '</b><span style="font-size:11.5px;font-weight:800;color:' + CC[st] + '">' + TXT[st] + '</span>' + (detail ? '<small dir="auto" style="font-size:10.5px;opacity:.75;text-align:center;word-break:break-word;max-width:100%">' + detail.replace(/</g, '&lt;') + '</small>' : '') + '</div>';
  }
  function cardHTML() { return item('Supabase', 'S', sbState(lastSb), lastSb && lastSb.err && lastSb.err !== 'NOAUTH' ? String(lastSb.err).slice(0, 90) : '') + item('Firebase', 'F', fbState(), fbDetail()); }
  function paint() { var c = document.getElementById('mfx-card'); if (c) c.innerHTML = cardHTML(); }
  window.__mfServerCard = function (s) {
    lastSb = { c: s.c, err: s.err };
    var w = document.createElement('div'), lb = document.createElement('div'), card = document.createElement('div');
    lb.className = 'mfs-lb'; lb.textContent = 'دۆخی سێرڤەرەکان';
    card.id = 'mfx-card'; card.style.cssText = 'display:flex;gap:8px;padding:14px 8px;border-radius:20px;border:1px solid var(--border,rgba(128,128,128,.3));color:var(--text-main,#222)';
    card.innerHTML = cardHTML(); w.appendChild(lb); w.appendChild(card); return w;
  };
  window.__mfRenderCloud = function (chip, c, up, q, err) { lastSb = { c: c, err: err }; paint(); };
  setInterval(paint, 4000);
  var DK = 'mf_sync_fb_dirty', IK = 'mf_sync_fb_init';
  var FB = null, dirty = {}, timer = null, busy = false, restoring = false;
  var status = { ready: false, last: 0, err: '', pending: 0 }, lastMsg = '';
  function toast() {}
  try { dirty = JSON.parse(getRaw.call(LS, DK) || '{}') || {}; } catch (e) { dirty = {}; }
  function saveDirty() { try { prevSet.call(LS, DK, JSON.stringify(dirty)); } catch (e) {} status.pending = Object.keys(dirty).length; paint(); }
  function schedule(ms) { clearTimeout(timer); timer = setTimeout(function () { timer = null; flush(); }, ms); }
  function mark(k) { if (!dirty[k]) { dirty[k] = 1; saveDirty(); } if (!timer) schedule(3000); }
  proto.setItem = function (k, v) { var r = prevSet.call(this, k, v); if (this === LS && !restoring && syncable(k)) mark(k); return r; };
  proto.removeItem = function (k) { var r = prevRem.call(this, k); if (this === LS && !restoring && syncable(k)) mark(k); return r; };

  var API = 'https://firestore.googleapis.com/v1/projects/' + CFG.projectId + '/databases/(default)/documents/' + COL;
  function toFields(o) {
    var f = {};
    Object.keys(o).forEach(function (k) { var v = o[k]; f[k] = typeof v === 'string' ? { stringValue: v } : typeof v === 'boolean' ? { booleanValue: v } : { integerValue: String(v) }; });
    return f;
  }
  function fromFields(f) {
    var o = {};
    Object.keys(f || {}).forEach(function (k) { var v = f[k]; o[k] = 'stringValue' in v ? v.stringValue : 'booleanValue' in v ? v.booleanValue : 'integerValue' in v ? Number(v.integerValue) : null; });
    return o;
  }
  function rest(url, opt) {
    var ac = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var to = setTimeout(function () { if (ac) ac.abort(); }, 30000);
    opt = opt || {}; if (ac) opt.signal = ac.signal;
    return fetch(url, opt).then(function (r) {
      clearTimeout(to);
      if (r.ok) return r.json();
      return r.text().then(function (tx) { var m = ''; try { m = JSON.parse(tx).error.message; } catch (e) { m = String(tx).slice(0, 120); } throw new Error('HTTP ' + r.status + ': ' + m); });
    }, function (e) { clearTimeout(to); throw new Error(e && e.name === 'AbortError' ? 'timeout' : 'Failed to fetch'); });
  }
  function put(docId, data) {
    return rest(API + '/' + encodeURIComponent(docId) + '?key=' + CFG.apiKey, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: toFields(data) }) });
  }
  async function listDocs() {
    var out = [], tok = '';
    do {
      var r = await rest(API + '?pageSize=300&key=' + CFG.apiKey + (tok ? '&pageToken=' + encodeURIComponent(tok) : ''));
      (r.documents || []).forEach(function (d) { out.push(fromFields(d.fields)); });
      tok = r.nextPageToken || '';
    } while (tok);
    return out;
  }
  function hash(s) { var h = 5381, i = s.length; while (i) h = (h * 33) ^ s.charCodeAt(--i); return (h >>> 0).toString(36) + '.' + s.length; }
  function id(k, i) { return encodeURIComponent(k) + (i ? '~' + i : ''); }
  async function pushKey(k) {
    var raw = getRaw.call(LS, k), now = Date.now();
    if (raw == null) { await put(id(k), { key: k, deleted: true, n: 0, h: '', d: '', t: now }); return; }
    var n = Math.max(1, Math.ceil(raw.length / CHUNK));
    for (var i = 1; i < n; i++) await put(id(k, i), { key: k, part: i, d: raw.slice(i * CHUNK, (i + 1) * CHUNK), t: now });
    await put(id(k), { key: k, deleted: false, n: n, h: hash(raw), d: raw.slice(0, CHUNK), t: now });
  }
  async function flush() {
    if (!FB || busy || !navigator.onLine) return;
    var keys = Object.keys(dirty); if (!keys.length) return;
    keys.sort(function (a, b) { return (getRaw.call(LS, a) || '').length - (getRaw.call(LS, b) || '').length; });
    busy = true; status.err = '';
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i]; delete dirty[k]; status.cur = k; paint();
      try { await pushKey(k); } catch (e) { dirty[k] = 1; status.err = String((e && e.message) || e); break; }
    }
    status.cur = ''; saveDirty(); busy = false; paint();
    if (status.err) { toast('Firebase هەڵە: ' + status.err, true); schedule(20000); } else { toast('Firebase: داتا پارێزرا ✓'); status.last = Date.now(); if (Object.keys(dirty).length) schedule(2000); }
  }
  async function pull(force) {
    var docs = await listDocs(), remote = {}, parts = {}, restored = 0;
    docs.forEach(function (x) { if (x.part) (parts[x.key] = parts[x.key] || {})[x.part] = x.d; else remote[x.key] = x; });
    var rk = Object.keys(remote);
    rk.forEach(function (k) {
      var x = remote[k]; if (!syncable(k) || x.deleted || dirty[k]) return;
      var s = x.d || '', ok = true;
      for (var i = 1; i < x.n; i++) { if (parts[k] && parts[k][i] != null) s += parts[k][i]; else ok = false; }
      if (!ok || hash(s) !== x.h) return;
      if (getRaw.call(LS, k) === s) return;
      restoring = true; try { prevSet.call(LS, k, s); restored++; } catch (e) {} restoring = false;
    });
    for (var i = 0; i < LS.length; i++) { var k = LS.key(i); if (syncable(k) && !remote[k]) dirty[k] = 1; }
    saveDirty(); prevSet.call(LS, IK, '1');
    return restored;
  }
  async function boot() {
    try {
      if (!getRaw.call(LS, IK)) { if (await pull() > 0) { location.reload(); return; } }
      FB = true; status.ready = true; status.err = ''; paint(); flush();
    } catch (e) { status.err = String((e && e.message) || e); paint(); setTimeout(boot, 30000); }
  }
  window.addEventListener('online', function () { if (FB) schedule(1000); paint(); });
  window.addEventListener('offline', function () { paint(); });
  function start() { status.err = 'OFF'; /* disabled: Firestore REST had no auth */ }
  if (document.readyState !== 'loading') start(); else document.addEventListener('DOMContentLoaded', start);
  window.__mfFirebase = {
    status: function () { return status; },
    backupAll: function () { for (var i = 0; i < LS.length; i++) { var k = LS.key(i); if (syncable(k)) dirty[k] = 1; } saveDirty(); return flush(); },
    restoreAll: async function () { if (!FB) return -1; var n = await pull(); if (n > 0) location.reload(); return n; }
  };
})();
