    window.mfEsc=function(v){return String(v==null?'':v).replace(/[&<>"'`]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;','`':'&#96;'}[c];});};
    window.MF_AI_PROXY={enabled:false,url:'https://wtzffmorfclxivopvsit.supabase.co/functions/v1/ai-proxy',apikey:'sb_publishable_YDz--eVlnrTgZJ6hKJwLig_bzY1-Fjg',providers:['gemini','claude','openai','deepseek','groq','mistral']};
    window.mfAiProxyHas=function(p){var P=window.MF_AI_PROXY;return !!(P&&P.enabled&&P.providers.indexOf(p)>-1);};
    window.mfAiFetch=function(url,init){var P=window.MF_AI_PROXY,H={'api.openai.com':'openai','api.anthropic.com':'claude','generativelanguage.googleapis.com':'gemini','api.deepseek.com':'deepseek','api.groq.com':'groq','api.mistral.ai':'mistral'},host='';
      try{host=new URL(url).hostname;}catch(e){}
      if(!P||!P.enabled||!H[host]||P.providers.indexOf(H[host])<0||!window.__mfSync||!window.__mfSync.token)return fetch(url,init);
      return window.__mfSync.token().then(function(tok){return fetch(P.url,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tok,'apikey':P.apikey,'x-target-url':url},body:init.body,signal:init.signal});});};
    window.MF_AUTH={cloud:true,mode:'cloud',domain:'mf.local',fn:'',scrub:true}; /* cloud:true = per-user Supabase accounts; mode 'hybrid' (keeps old local login as fallback) or 'cloud' (strict) */
    window.MF_CONTACT={whatsapp:'9647511575756',viber:'9647511575756',telegram:'Zaidfars24'}; /* whatsapp/viber: full international number, digits only (e.g. 9647501234567). telegram: username without @ */
    window.mfGateForm=function(){var g=document.getElementById('app-login-gate');if(g){g.classList.remove('mf-wait','mf-rej','mf-ok');g.classList.add('mf-form');}setTimeout(function(){var u=document.getElementById('app-login-username');if(u)u.focus();},60);};
    window.mfGateHome=function(){var g=document.getElementById('app-login-gate');if(g)g.classList.remove('mf-form','mf-wait','mf-rej','mf-ok');var e=document.getElementById('app-login-error');if(e)e.classList.remove('show','visible','active');var h=document.getElementById('mf-req-hint');if(h)h.textContent='';};
    document.addEventListener('DOMContentLoaded',function(){var g=document.getElementById('app-login-gate');if(!g||!window.MutationObserver)return;var was=g.classList.contains('hidden');new MutationObserver(function(){var now=g.classList.contains('hidden');if(was&&!now)window.mfGateHome();was=now;}).observe(g,{attributes:true,attributeFilter:['class']});});
    window.mfRequestOpen=function(u){try{if(/^https?:/i.test(u)){var w=window.open(u,'_blank');if(!w)window.location.href=u;}else{window.location.href=u;}}catch(e){window.location.href=u;}};
    window.mfRequestInit=function(){var c=window.MF_CONTACT||{},any=false,m={wa:c.whatsapp,vb:c.viber,tg:c.telegram};for(var k in m){var b=document.getElementById('mf-req-'+k);if(b){var on=!!String(m[k]||'').trim();b.style.display='flex';if(on)any=true;}}var r=document.getElementById('mf-req');if(r)r.style.display='block';};
    document.addEventListener('DOMContentLoaded',function(){window.mfRequestInit();});
    window.mfAccessMsg=function(info){
      if(typeof info==='string')info={name:info};
      info=info||{};
      var d=new Date(),p=function(n){return (n<10?'0':'')+n;},L='━━━━━━━━━━━━━━━━━━',
        days=['یەکشەممە','دووشەممە','سێشەممە','چوارشەممە','پێنجشەممە','هەینی','شەممە'],
        date=d.getFullYear()+'/'+p(d.getMonth()+1)+'/'+p(d.getDate()),time=p(d.getHours())+':'+p(d.getMinutes()),
        ref=info.ref||('MF-'+String(d.getFullYear()).slice(2)+p(d.getMonth()+1)+p(d.getDate())+'-'+(1000+Math.floor(Math.random()*9000))),
        ua='',os='',br='',build='';
      try{
        ua=navigator.userAgent||'';
        os=/iPhone|iPad|iPod/i.test(ua)?'iOS':/Android/i.test(ua)?'Android':/Windows/i.test(ua)?'Windows':/Mac/i.test(ua)?'macOS':/Linux/i.test(ua)?'Linux':'';
        br=/SamsungBrowser/i.test(ua)?'Samsung Internet':/Edg\//i.test(ua)?'Edge':/OPR\//i.test(ua)?'Opera':/Firefox|FxiOS/i.test(ua)?'Firefox':/Chrome|CriOS/i.test(ua)?'Chrome':/Safari/i.test(ua)?'Safari':'';
        build=window.MF_VERSION||(document.querySelector('meta[name="mf-build"]')||{}).content||'';
      }catch(e){}
      var dev=[os,br].filter(Boolean).join(' • ');
      return [
        '📩 داواکاری هەژماری نوێ',
        L,
        '🏷️ ژمارەی داواکاری: '+ref,
        '🏢 سیستەم: Massi Fars — چێشتخانە',
        L,
        '',
        'بەڕێز ئادمینی سیستەم، سڵاو و ڕێزێکی تایبەت 🌹',
        '',
        'من کارمەندی نوێی چێشتخانەکەم و داوای دروستکردنی هەژمارێک دەکەم بۆ چوونەژوورەوە بۆ سیستەمەکە.',
        '',
        '📋 زانیاری داواکار',
        '👤 ناو: '+(info.name||'نەنووسراوە'),
        info.phone?('📞 ژمارەی مۆبایل: '+info.phone):null,
        '💼 پلە: '+(info.role||'کارمەندی نوێ'),
        info.user?('🔑 ناوی بەکارهێنەری دڵخواز: '+info.user):null,
        '📅 بەروار: '+days[d.getDay()]+' '+date,
        '🕒 کات: '+time,
        dev?('📱 ئامێر: '+dev):null,
        build?('🔖 وەشانی سیستەم: '+build):null,
        info.note?'':null,
        info.note?('📝 تێبینی: '+info.note):null,
        '',
        '📌 داواکراو',
        '▪️ ناوی بەکارهێنەر (Username)',
        '▪️ وشەی نهێنی (Password)',
        '',
        'تکایە دوای پشکنین و پەسەندکردن، زانیاری چوونەژوورەوەم بۆ بنێرن.',
        'پێشوەخت سوپاسگوزارم، لەگەڵ ڕێزدا.',
        L
      ].filter(function(x){return x!==null;}).join('\n');
    };
    window.mfCopyText=function(t){
      var ok=false;
      try{var ta=document.createElement('textarea');ta.value=t;ta.setAttribute('readonly','');ta.style.cssText='position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;font-size:16px';document.body.appendChild(ta);ta.focus();ta.select();ta.setSelectionRange(0,ta.value.length);ok=!!document.execCommand('copy');document.body.removeChild(ta);}catch(e){}
      try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(function(){},function(){});ok=true;}}catch(e){}
      return ok;
    };
    window.mfRequestSend=function(app,info){
      var c=window.MF_CONTACT||{},h=document.getElementById('mf-req-hint');
      var msg=window.mfAccessMsg(info),enc=encodeURIComponent(msg);
      var digits=function(v){return String(v||'').replace(/\D/g,'').replace(/^00/,'');};
      var ios=/iPhone|iPad|iPod/i.test(navigator.userAgent||'');
      var copied=window.mfCopyText(msg),cp=copied?'نامەکە کۆپی کرا. ':'',url='',fb='',note='';
      if(app==='whatsapp'){
        url='https://wa.me/'+digits(c.whatsapp)+'?text='+enc;
      }else if(app==='viber'){
        var vn=digits(c.viber);
        if(vn){url=ios?'viber://chat?number=%2B'+vn:'viber://chat?number='+vn;note=cp+'کاتێک چاتی ئادمین کرایەوە، نامەکە paste بکە و بینێرە. ئەگەر ڤایبەر نەکرایەوە، دڵنیابەرەوە لەسەر مۆبایلەکەت دامەزراوە.';}
        else{url='viber://forward?text='+enc;}
      }else if(app==='telegram'){
        var raw=String(c.telegram||'').trim(),isPhone=/^\+?\d{7,}$/.test(raw);
        if(raw&&!isPhone){url='https://t.me/'+raw.replace(/^@|^https?:\/\/t\.me\//i,'')+'?text='+enc;note=cp+'ئەگەر نامەکە لە تێلیگرام نەنووسرا، paste بکە.';}
        else if(isPhone){var ph=digits(raw);url='tg://resolve?phone='+ph;fb='https://t.me/+'+ph;note=cp+'کاتێک چاتی ئادمین کرایەوە، نامەکە paste بکە و بینێرە.';}
        else{url='https://t.me/share/url?url=%20&text='+enc;}
      }
      if(!url){if(h)h.textContent='ئەم ڕێگایە ڕێکنەخراوە.';return null;}
      if(h)h.textContent=note;
      window.mfRequestOpen(url);
      if(fb){setTimeout(function(){if(!document.hidden)window.mfRequestOpen(fb);},1500);}
      return note||'';
    };
    window.mfRequestAccess=function(app){
      if(window.mfReqOpen)window.mfReqOpen(app);else window.mfRequestSend(app,{name:''});
    };
    window.mfJs=function(v){return String(v==null?'':v).replace(/[^\w\-.: ]/g,function(c){var n=c.charCodeAt(0);return n<256?'\\x'+('0'+n.toString(16)).slice(-2):'\\u'+('000'+n.toString(16)).slice(-4);});};
    window.mfUrl=function(v,allowLinks){v=String(v==null?'':v).trim();if(!v)return'';var ok=/^data:image\/(png|jpe?g|gif|webp|bmp|svg\+xml|avif)[;,]/i.test(v)||/^data:video\/(mp4|webm|ogg)[;,]/i.test(v)||/^(https?:|blob:)/i.test(v)||(allowLinks&&/^(tel:|mailto:|sms:|whatsapp:)/i.test(v))||(/^[\w\-.\/]/.test(v)&&!/^[a-z][a-z0-9+.\-]*:/i.test(v));return ok?window.mfEsc(v):'';};
    window.mfHref=function(v){return window.mfUrl(v,true);};
