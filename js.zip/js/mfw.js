(function(){
  var RULES=[
    {n:'یاسای یەکەم',ic:'bell-ring',ac:'#f97316',t:['لە کاتی ڕووبەڕووبوونەوەی هەر کێشەیەک لە سیستەمەکەدا، پێویستە دەستبەجێ ئادمین ئاگادار بکرێتەوە.']},
    {n:'یاسای دووەم',ic:'phone-call',ac:'#10b981',t:['لە کاتی بەدیکردنی هەر هەڵەیەک لە سیستەمەکەدا، تکایە دەستبەجێ پەیوەندی بەم ژمارەیەوە بکەن:','07511575756','یان لە ڕێگەی تۆڕە کۆمەڵایەتییەکانەوە ئاگادارمان بکەنەوە.']},
    {n:'یاسای سێیەم',ic:'shield-alert',ac:'#ef4444',t:['دەستکاریکردنی سیستەمەکە بەبێ ئاگادارکردنەوەی پێشوەخت پێشێلکردنی یاساکانی سیستەمە.','هەر هەوڵێک بۆ دەستکاریکردنی هەژمارەکە دەبێتە هۆی قەدەغەکردنی هەژمارەکەتان.']},
    {n:'یاسای چوارەم',ic:'copyright',ac:'#8b5cf6',t:['بڵاوکردنەوە یان لەبەرگرتنەوەی سیستەمەکە پێشێلکردنی مافی خاوەندارێتی سیستەمەکەیە.','بۆیە ئاگادارتان دەکەینەوە کە هەر پێشێلکارییەک ڕووبەڕووی سزای یاسایی دەبێتەوە.']},
    {n:'یاسای پێنجەم',ic:'message-square-text',ac:'#06b6d4',t:['لە کاتی هەبوونی هەر تێبینییەک یان سەرنجێک، تکایە خاوەنی چێشتخانەکە یان ئادمین ئاگادار بکەنەوە.']}
  ];
  var step=0,total=RULES.length+4,emp=null,dir='f';
  function $(i){return document.getElementById(i);}
  function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function icons(){try{if(window.lucide)lucide.createIcons({root:$('mfw')});else if(window.safeCreateIcons)safeCreateIcons();}catch(e){}}
  function confetti(){
    var c=$('mfw-conf');if(!c)return;c.innerHTML='';var cols=['#6366f1','#22d3ee','#f97316','#ec4899','#10b981','#eab308'];
    for(var i=0;i<26;i++){var s=document.createElement('span');s.style.left=(Math.random()*100)+'%';s.style.background=cols[i%cols.length];s.style.animationDuration=(2.6+Math.random()*2.4)+'s';s.style.animationDelay=(Math.random()*1.2)+'s';c.appendChild(s);}
  }
  function render(){
    var bars='';for(var i=0;i<total;i++)bars+='<i class="'+(i<=step?'d':'')+'"></i>';$('mfw-bars').innerHTML=bars;
    var st=$('mfw-stage'),h='',nextTxt='بەردەوامبە',nextIc='arrow-left',ac='var(--c-1)';
    if(step===0){
      var nm=esc(emp&&emp.name||emp&&emp.username||''),ph=emp&&emp.photo?'<img src="'+esc(emp.photo)+'" alt="">':'';
      var ini=Array.from(String(emp&&(emp.name||emp.username)||'?').trim()||'?')[0].toUpperCase();
      h='<div class="mfw-av"><b>'+esc(ini)+'</b>'+ph+'</div><div class="mfw-hi">بەخێربێیت</div><div class="mfw-wel">'+nm+'</div>';
      h='<div class="mfw-card"><div class="mfw-av"><b>'+esc(ini)+'</b>'+ph+'</div><div class="mfw-wel">بەخێربێیت</div><div class="mfw-name">'+nm+'</div></div>';
    }else if(step===1){
      ac='#6366f1';
      var lg='';try{lg=window.mfTeamLogoGet?window.mfTeamLogoGet():'';}catch(e){}
      h='<div class="mfw-card" style="--ac:'+ac+'"><div class="mfw-logo">'+(lg?'<img src="'+esc(lg)+'" alt="">':'<i data-lucide="users"></i>')+'</div>'
        +'<div class="mfw-num">دەربارەی ئێمە</div>'
        +'<div class="mfw-name mfw-team ltr">Z01</div>'
        +'<div class="mfw-txt" style="margin-top:6px"><p class="mfw-ln" style="font-size:18px;font-weight:900;color:var(--ac)">تیمی بەرنامەسازی و گەشەپێدانی سیستەم</p>'
        +'<p class="mfw-ln">Z01 سیستەمی تایبەت بۆ بەڕێوەبردنی کار دروست دەکات. ئامانجمان ئەوەیە کارە بڵاوەکان لە یەک سیستەمی ڕێکخراودا کۆبکەینەوە، تا کارکردن لەسەریان خێراتر و ئاسانتر بێت.</p>'
        +'<div class="mfw-chips"><span class="mfw-chip"><i data-lucide="calendar"></i>دامەزراوە لە 2025 - 2026</span></div></div></div>';
    }else if(step===2){
      ac='#0ea5e9';
      h='<div class="mfw-card" style="--ac:'+ac+'"><div class="mfw-ic"><i data-lucide="code"></i></div>'
        +'<div class="mfw-num">درووستکەر و گەشەپێدەری سیستەمەکە</div>'
        +'<div class="mfw-name mfw-team ltr">ZaidFars</div>'
        +'<div class="mfw-txt" style="margin-top:4px"><div class="mfw-chips" style="margin-top:6px"><span class="mfw-chip"><i data-lucide="calendar"></i>ساڵی درووستکردن 2025</span></div>'
        +'<div class="mfw-sec">بۆ پەیوەندی و پشتگیری تەکنیکی</div>'
        +'<div class="mfw-telw"><a class="mfw-tel" href="tel:07511575756"><i data-lucide="phone"></i>07511575756</a></div>'
        +'<div class="mfw-about"><h4><i data-lucide="layers"></i>دەربارەی سیستەمەکە</h4><p>ئەم سیستەمە چەندین بەشی جیاوازی لەخۆ گرتووە، و زۆربەیان کورتکراونەتەوە و لە یەک سیستەمی یەکگرتوودا کۆکراونەتەوە، تا هەموو کارەکان لە یەک شوێندا و بە ڕێکوپێکی بەڕێوە بچن.</p></div></div></div>';
    }else if(step<=RULES.length+2){
      var r=RULES[step-3];ac=r.ac;
      var body=r.t.map(function(x){return /^\d{6,}$/.test(x)?'<div class="mfw-telw"><a class="mfw-tel" href="tel:'+x+'"><i data-lucide="phone"></i>'+x+'</a></div>':'<p class="mfw-ln">'+esc(x)+'</p>';}).join('');
      h='<div class="mfw-card" style="--ac:'+r.ac+'"><div class="mfw-ic"><i data-lucide="'+r.ic+'"></i></div><div class="mfw-num">'+r.n+'</div><div class="mfw-txt">'+body+'</div></div>';
      if(step===RULES.length+2)nextTxt='تێگەیشتم';
    }else{
      ac='#ec4899';nextTxt='دەستپێبکە';nextIc='check';
      h='<div class="mfw-card" style="--ac:#ec4899"><div class="mfw-ic"><i data-lucide="heart-handshake"></i></div><div class="mfw-wel" style="font-size:34px">سوپاس و پێزانین</div><div class="mfw-txt" style="margin-top:12px">سوپاس و پێزانینمان بۆ ئێوەی بەڕێز، میوانە ئازیزەکان</div></div>';
    }
    var oldS=st.querySelector('.mfw-slide:not(.out)');
    Array.prototype.forEach.call(st.querySelectorAll('.mfw-slide.out'),function(n){n.remove();});
    var newS=document.createElement('div');newS.className='mfw-slide pre'+(dir==='b'?' back':'');newS.style.setProperty('--ac',ac);newS.innerHTML=h;
    if(oldS){oldS.classList.add('out','pre');if(dir==='b')oldS.classList.add('back');}
    st.appendChild(newS);
    $('mfw').style.setProperty('--ac',ac);
    $('mfw-next').innerHTML='<span>'+nextTxt+'</span><i data-lucide="'+nextIc+'"></i>';
    $('mfw-prev').classList.toggle('on',step>0);
    icons();
    if(step===0||step===total-1)confetti();
    requestAnimationFrame(function(){requestAnimationFrame(function(){
      newS.classList.remove('pre');
      if(oldS){oldS.classList.remove('pre');setTimeout(function(){if(oldS.parentNode)oldS.remove();},460);}
    });});
  }
  window.mfWelcomeGo=function(d){
    if(d>0&&step===total-1){close();return;}
    step=Math.max(0,Math.min(total-1,step+d));dir=d<0?'b':'f';render();
  };
  function close(){var o=$('mfw');o.classList.remove('on');$('mfw-stage').innerHTML='';}
  window.mfWelcomeShow=function(e){emp=e||null;step=0;dir='f';$('mfw').classList.add('on');render();};
})();
