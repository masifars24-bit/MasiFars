(function(){
  var MONTHS=['کانوونی دووەم','شوبات','ئازار','نیسان','ئایار','حوزەیران','تەمووز','ئاب','ئەیلوول','تشرینی یەکەم','تشرینی دووەم','کانوونی یەکەم'];
  var DAYS=['یەکشەممە','دووشەممە','سێشەممە','چوارشەممە','پێنجشەممە','هەینی','شەممە'];
  var DS=['یەک','دوو','سێ','چوار','پێنج','هەینی','شەم'];
  var openSt={}, reg={};
  var KINDS={
    receipts:{accent:'#a21caf',unit:'وەسڵ',amount:function(r){return r.grandTotal||0;},card:function(r){return renderReceiptCard(r);},
      warn:function(r){return r.paymentMethod==='debt'?(r.remaining||0):0;}},
    expenses:{accent:'#8b5cf6',unit:'تۆمار',amount:function(e){return e.price||0;},card:function(e){return renderExpenseEntryCard(e);},warn:null}
  };
  function p2(n){return n<10?'0'+n:''+n;}
  function fm(n){return Math.round(n||0).toLocaleString('en-US');}
  function dateOf(it){var s=it&&it.date;if(!/^\d{4}-\d{2}-\d{2}$/.test(s||'')){var t=new Date((it&&it.timestamp)||Date.now());s=t.getFullYear()+'-'+p2(t.getMonth()+1)+'-'+p2(t.getDate());}return s;}
  function parse(s){var a=s.split('-');return {y:+a[0],m:+a[1],d:+a[2]};}
  function dow(y,m,d){return new Date(y,m-1,d).getDay();}
  function dim(y,m){return new Date(y,m,0).getDate();}
  function todayStr(){var t=new Date();return t.getFullYear()+'-'+p2(t.getMonth()+1)+'-'+p2(t.getDate());}
  function weekKeyOf(s){var o=parse(s),d1=dow(o.y,o.m,1);return o.y+'-'+p2(o.m)+'-'+(Math.floor((o.d-1+d1)/7)+1);}
  function group(items,fn){var m={},o=[];items.forEach(function(it){var k=fn(it);if(!m[k]){m[k]=[];o.push(k);}m[k].push(it);});return o.map(function(k){return {k:k,items:m[k]};});}
  function sum(cfg,items){var t=0,w=0;items.forEach(function(it){t+=cfg.amount(it);if(cfg.warn)w+=cfg.warn(it);});return {total:t,warn:w,count:items.length};}
  function weekNo(k){return parseInt(k.split('-')[2],10);}
  function cmpDesc(a,b){return a<b?1:(a>b?-1:0);}

  function box(cx,o){
    var key=cx.prefix+o.key, opn=!!openSt[key];
    reg[key]=o.kids;
    var h='<div class="pe-box pe-L'+o.lvl+(opn?' open':'')+'" data-pek="'+key+'">';
    h+='<div class="pe-head" onclick="mfPeToggle(this)" role="button" aria-expanded="'+opn+'">';
    h+='<div class="pe-badge">'+(o.top?'<small>'+o.top+'</small>':'')+'<b>'+o.main+'</b>'+(o.bot?'<small>'+o.bot+'</small>':'')+'</div>';
    h+='<div class="pe-info"><div class="pe-title"><span>'+o.title+'</span>'+(o.now?'<span class="pe-now">'+o.now+'</span>':'')+'</div><div class="pe-sub"><span>'+o.sub+'</span></div>'+(o.sm.warn>0?'<div class="pe-chips pe-chips-l"><span class="pe-chip warn">ماوە '+fm(o.sm.warn)+'</span></div>':'')+'</div>';
    h+='<div class="pe-stats"><div class="pe-amt"><span>'+fm(o.sm.total)+'</span><small>د.ع</small></div><div class="pe-chips"><span class="pe-chip">'+o.sm.count+' '+cx.cfg.unit+'</span></div></div>';
    h+='<span class="pe-chev"><i data-lucide="chevron-down"></i></span></div>';
    h+='<div class="pe-bar"><i style="--sh:'+Math.max(4,Math.round(o.share*100))+'%"></i></div>';
    h+='<div class="pe-body"><div class="pe-inner">'+(opn?'<div class="pe-kids">'+o.kids()+'</div>':'')+'</div></div></div>';
    return h;
  }
  function share(vals,v){var mx=Math.max.apply(null,vals.concat([1]));return v/mx;}

  function dayBoxes(cx,items,lvl){
    var gs=group(items,dateOf).sort(function(a,b){return cmpDesc(a.k,b.k);});
    var sms=gs.map(function(g){return sum(cx.cfg,g.items);}),tots=sms.map(function(x){return x.total;}),td=todayStr();
    return gs.map(function(g,i){
      var o=parse(g.k),dw=dow(o.y,o.m,o.d);
      return box(cx,{key:'d:'+g.k,lvl:lvl,main:o.d,bot:DS[dw],top:'',title:DAYS[dw],sub:p2(o.d)+'-'+p2(o.m)+'-'+o.y,now:g.k===td?'ئەمڕۆ':'',sm:sms[i],share:share(tots,sms[i].total),
        kids:function(){return g.items.map(cx.cfg.card).join('');}});
    }).join('');
  }
  function weekBoxes(cx,items,lvl){
    var gs=group(items,function(it){return weekKeyOf(dateOf(it));}).sort(function(a,b){return cmpDesc(a.k,b.k);});
    var sms=gs.map(function(g){return sum(cx.cfg,g.items);}),tots=sms.map(function(x){return x.total;}),td=todayStr();
    return gs.map(function(g,i){
      var a=g.k.split('-'),y=+a[0],m=+a[1],idx=+a[2],d1=dow(y,m,1),mx=dim(y,m);
      var st=Math.max(1,(idx-1)*7-d1+1),en=Math.min(mx,(idx-1)*7-d1+7);
      var days={};g.items.forEach(function(it){days[dateOf(it)]=1;});var nd=Object.keys(days).length;
      var cur=weekKeyOf(td)===g.k;
      return box(cx,{key:'w:'+g.k,lvl:lvl,top:'هەفتە',main:idx,title:'هەفتەی '+idx,sub:p2(st)+'/'+p2(m)+' — '+p2(en)+'/'+p2(m)+' · '+nd+' ڕۆژ',now:cur?'ئەم هەفتەیە':'',sm:sms[i],share:share(tots,sms[i].total),
        kids:function(){return dayBoxes(cx,g.items,lvl+1);}});
    }).join('');
  }
  function monthBoxes(cx,items,lvl){
    var gs=group(items,function(it){return dateOf(it).substring(0,7);}).sort(function(a,b){return cmpDesc(a.k,b.k);});
    var sms=gs.map(function(g){return sum(cx.cfg,g.items);}),tots=sms.map(function(x){return x.total;}),td=todayStr().substring(0,7);
    return gs.map(function(g,i){
      var a=g.k.split('-'),y=+a[0],m=+a[1];
      var wk={};g.items.forEach(function(it){wk[weekKeyOf(dateOf(it))]=1;});var nw=Object.keys(wk).length;
      return box(cx,{key:'m:'+g.k,lvl:lvl,top:y,main:m,title:MONTHS[m-1],sub:y+' · '+nw+' هەفتە',now:g.k===td?'ئەم مانگە':'',sm:sms[i],share:share(tots,sms[i].total),
        kids:function(){return weekBoxes(cx,g.items,lvl+1);}});
    }).join('');
  }

  window.mfPeriodHtml=function(kind,tab,items){
    var cfg=KINDS[kind],scope=(kind==='receipts'&&typeof activeReceiptType!=='undefined')?activeReceiptType:'';
    var cx={cfg:cfg,prefix:kind+':'+scope+':'};
    try{
      Object.keys(reg).forEach(function(k){if(k.indexOf(kind+':')===0)delete reg[k];});
      var inner=tab==='week'?dayBoxes(cx,items,0):(tab==='month'?weekBoxes(cx,items,0):monthBoxes(cx,items,0));
      return '<div class="pe-list" style="--pc:'+cfg.accent+'">'+inner+'</div>';
    }catch(err){console.error('Massi Fars: period view failed',err);return items.map(cfg.card).join('');}
  };
  window.mfPeToggle=function(head){
    var b=head.parentNode,key=b.getAttribute('data-pek'),inner=b.querySelector(':scope > .pe-body > .pe-inner');
    var on=!b.classList.contains('open');
    if(on){
      var fn=reg[key];inner.innerHTML='<div class="pe-kids">'+(fn?fn():'')+'</div>';
      b.classList.add('open');openSt[key]=true;head.setAttribute('aria-expanded','true');
      if(window.safeCreateIcons)safeCreateIcons();
    }else{
      b.classList.remove('open');delete openSt[key];head.setAttribute('aria-expanded','false');
      setTimeout(function(){if(!b.classList.contains('open'))inner.innerHTML='';},360);
    }
  };
})();
