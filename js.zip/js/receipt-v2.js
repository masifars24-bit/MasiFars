window.mfRc2 = (function(){
  var MAP={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
  function E(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return MAP[c];});}
  function ic(n){return '<i data-lucide="'+n+'"></i>';}
  var LAST=null;var PAY={cash:{l:'نەقد',i:'banknote'},card:{l:'کارت',i:'credit-card'},debt:{l:'قەرز',i:'hand-coins'}};

  function tile(kind,icon,first,second,labelFirst){
    return '<div class="rc2-tile '+kind+'"><div class="rc2-tile-t">'+(labelFirst?'<span class="l">'+first+'</span><b class="v">'+second+'</b>':'<b class="v">'+first+'</b><span class="l">'+second+'</span>')+'</div>'+ic(icon)+'</div>';
  }
  function chip(k,on){var p=PAY[k];return '<span class="rc2-chip '+k+(on?' on':'')+'">'+ic(p.i)+'<span>'+p.l+'</span></span>';}

  function totals(o){LAST={g:o.grand,l:o.grandLabel||'کۆی گشتی'};
    var h='<div class="rc2-trows">';
    (o.rows||[]).forEach(function(r){h+='<div class="rc2-trow"><span class="l">'+E(r.l)+'</span><span class="v">'+(r.s?'<i class="s">'+r.s+'</i>':'')+r.v+'</span></div>';});
    h+='</div><div class="rc2-grand"><span class="gl"><span class="gi">'+ic('coins')+'</span>'+E(o.grandLabel||'کۆی گشتی')+'</span><span class="gv">'+o.grand+'</span></div>';
    if(o.pay&&PAY[o.pay])h+='<div class="rc2-payrow"><span class="l">شێوازی پارەدان</span>'+chip(o.pay,true)+'</div>';
    return h;
  }
  function infoRow(icon,label,value,extra){
    return '<div class="rc2-info"><span class="ii">'+ic(icon)+'</span><div class="it"><span>'+E(label)+'</span><b>'+E(value)+'</b></div>'+(extra||'')+'</div>';
  }

  function sealSvg(){var p=[],n=24;for(var i=0;i<n*2;i++){var a=Math.PI*i/n,r=i%2?40:47;p.push((50+r*Math.cos(a)).toFixed(1)+','+(50+r*Math.sin(a)).toFixed(1));}
    return '<svg class="rc2-seal" viewBox="0 0 100 100" width="64" height="64"><defs><linearGradient id="rc2g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fde68a"/><stop offset="1" stop-color="#f59e0b"/></linearGradient></defs><polygon points="'+p.join(' ')+'" fill="url(#rc2g)" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><circle cx="50" cy="50" r="31" fill="none" stroke="#b45309" stroke-opacity=".55" stroke-width="1.6" stroke-dasharray="2 3"/><path d="M36 51l10 10 19-21" fill="none" stroke="#7c2d12" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/></svg>';}
  var C128='212222,222122,222221,121223,121322,131222,122213,122312,132212,221213,221312,231212,112232,122132,122231,113222,123122,123221,223211,221132,221231,213212,223112,312131,311222,321122,321221,312212,322112,322211,212123,212321,232121,111323,131123,131321,112313,132113,132311,211313,231113,231311,112133,112331,132131,113123,113321,133121,313121,211331,231131,213113,213311,213131,311123,311321,331121,312113,312311,332111,314111,221411,431111,111224,111422,121124,121421,141122,141221,112214,112412,122114,122411,142112,142211,241211,221114,413111,241112,134111,111242,121142,121241,114212,124112,124211,411212,421112,421211,212141,214121,412121,111143,111341,131141,114113,114311,411113,411311,113141,114131,311141,411131,211412,211214,211232,2331112'.split(',');
  function barcode(code){var s=String(code||'MF').replace(/[^\x20-\x7e]/g,'?'),vals=[104],sum=104,i;
    for(i=0;i<s.length;i++){var v=s.charCodeAt(i)-32;vals.push(v);sum+=v*(i+1);}
    vals.push(sum%103);vals.push(106);
    var x=10,r='';vals.forEach(function(v){var q=C128[v];for(var k=0;k<q.length;k++){var w=+q.charAt(k);if(k%2===0)r+='<rect x="'+x+'" y="0" width="'+w+'" height="34"/>';x+=w;}});
    x+=10;
    return '<svg class="rc2-bc" viewBox="0 0 '+x+' 34" preserveAspectRatio="none" shape-rendering="crispEdges" width="300" height="34"><g fill="#1b1f3b">'+r+'</g></svg>';}
  var ORN='<svg width="150" height="12" viewBox="0 0 150 12"><path d="M0 6h58M92 6h58" stroke="#9aa0d8" stroke-opacity=".8" stroke-width="1.5" stroke-linecap="round" fill="none"/><path d="M75 1l5 5-5 5-5-5z" fill="#f59e0b"/><circle cx="64" cy="6" r="1.6" fill="#9aa0d8"/><circle cx="86" cy="6" r="1.6" fill="#9aa0d8"/></svg>';
  function build(d){
    var t=d.tiles||{};
    var hero=(LAST&&d.totalsHtml&&String(d.totalsHtml).indexOf(LAST.g)>-1)?LAST:null; LAST=null;
    var h='<div class="rc2'+(hero?' rc2-has-hero':'')+'"><div class="rc2-banner">';
    h+=(d.auto?'<span class="rc2-auto">'+ic('zap')+' خۆکار</span>':'')+(d.toggleHtml||'');
    var TL=(typeof receiptBrand!=='undefined'&&receiptBrand&&receiptBrand.teamLogo)||'';
    h+='<div class="rc2-bigcircle">'+d.logoHtml+'</div>';
    h+='<div class="rc2-bhead">'+(TL?'<div class="rc2-logo rc2-teamlogo"><img src="'+E(TL)+'" alt="لۆگۆی تیم"></div>':'')+'<div class="rc2-btxt"><div class="rc2-brand">'+E(d.brand)+'</div><div class="rc2-type">'+E(d.type)+'</div><span class="rc2-pill">'+E(d.pill)+'</span></div></div>';
    if(hero)h+='<div class="rc2-hero"><span class="hl">'+E(hero.l)+'</span><span class="gv">'+hero.g+'</span></div>';
    h+='</div><div class="rc2-card">'+sealSvg()+'<div class="rc2-tiles">'
      +tile('green','calendar-check-2',E(t.numLabel||'ژمارەی وەسڵ'),E(t.num),true)
      +tile('purple','calendar-days',E(t.date),E('بەروار'),false)
      +tile('blue','clock-3',E(t.time||'--:--'),'کات',false)+'</div>';
    if(d.payChips&&d.payChips.show){var s=d.payChips.selected;h+='<div class="rc2-chips">'+chip('card',s==='card')+chip('cash',s==='cash')+(s==='debt'?chip('debt',true):'')+'</div>';}
    else if(d.payChips&&d.payChips.statusHtml){h+='<div class="rc2-chips">'+d.payChips.statusHtml+'</div>';}
    if(d.extraChipsHtml)h+=d.extraChipsHtml;
    if(d.party&&d.party.name){h+='<div class="rc2-party"><span class="av">'+ic('user-round')+'</span><div class="pt"><div class="pn"><span>'+E(d.party.label)+':</span> <b>'+E(d.party.name)+'</b></div>'+(d.party.phone?'<div class="pp">'+ic('phone')+'<span>'+E(d.party.phone)+'</span></div>':'')+'</div><span class="chev">'+ic('chevron-left')+'</span></div>';}
    if(d.extraHtml)h+=d.extraHtml;
    h+='<div class="rc2-items"><div class="rc2-ihead"><span>کاڵا</span><span>جۆری/بڕ</span><span>نرخ</span></div>';
    (d.items||[]).forEach(function(it){
      h+='<div class="rc2-irow"><span class="th">'+ic(guessIcon(it.name)||it.icon||'package')+'</span><div class="in"><div class="nm">'+E(it.name)+'</div>'+(it.noteHtml||'')
        +((it.chips&&it.chips.length)?'<div class="cp">'+it.chips.map(function(c){return '<span class="rc2-qty">'+E(c)+'</span>';}).join('')+'</div>':'')+(it.extraHtml||'')+'</div>'
        +(it.price!=null&&it.price!==''?'<span class="ld"></span><div class="pr"><b>'+E(it.price)+'</b><small>د.ع</small></div>':'')+'</div>';
    });
    h+='</div>';
    if(d.totalsHtml)h+='<div class="rc2-totals"'+(d.totalsId?' id="'+d.totalsId+'"':'')+'>'+d.totalsHtml+'</div>';
    if(d.notesHtml)h+=d.notesHtml;
    if(d.metaHtml)h+='<div class="rc2-meta">'+d.metaHtml+'</div>';
    h+='<div class="rc2-perf"></div><div class="rc2-thanks"><div class="th-h"><b>'+E(d.thanks||'سوپاس بۆ سەردانەکەتان')+'</b></div><div class="rc2-orn">'+ORN+'</div>';
    if(d.verify){h+='<div class="th-b"><div class="th-box"><div class="qr" id="'+d.verify.qrId+'"></div><div class="vt"><div class="vl">'+ic('shield-check')+'<span>کۆدی تایبەتی پشتڕاستکردنەوە</span></div><div class="vc">'+E(d.verify.code||'-')+'</div><div class="vh">سکانی کۆدەکە بکە بۆ دڵنیابوون لە ڕاستەقینەبوونی وەسڵ</div></div></div>'+'<div class="rc2-bcw">'+barcode(d.verify.code)+'</div></div>';}
    h+='</div></div></div>';
    return h;
  }
  function normName(s){
    return String(s==null?'':s).toLowerCase()
      .replace(/[\u064B-\u065F\u0670\u200c\u200d]/g,'')
      .replace(/[يىێ]/g,'ی').replace(/[كک]/g,'ک').replace(/[ھهەہ]/g,'ە')
      .replace(/[ۆ]/g,'و').replace(/[ڕ]/g,'ر').replace(/[ڵ]/g,'ل').replace(/[ڤ]/g,'ف')
      .replace(/[پ]/g,'ب').replace(/[چ]/g,'ج').replace(/[گ]/g,'ک').replace(/[ژ]/g,'ز');
  }
  function iconExists(n){
    try{
      var L=window.lucide;
      if(!L||!L.icons) return true;
      var p=n.split('-').map(function(x){return x.charAt(0).toUpperCase()+x.slice(1);}).join('');
      return !!(L.icons[p]||L.icons[n]);
    }catch(e){return true;}
  }
  var ICON_RULES=[
    [['truck'],['گەیاندن','گەیاندن','دیلیڤەری','delivery','توصیل','تەوسیل']],
    [['cup-soda'],['بیبسی','پیپسی','پەپسی','pepsi','کۆلا','cola','سێڤن','7up','سبرایت','sprite','میرندا','miranda','فانتا','fanta','دابل','مشروب','خواردنەوە','خواردنەوەی گازی','سەودا','soda','energy','ئینەرجی','کەنەرجی']],
    [['droplet','droplets'],['ئاو','ماء','water','ئاوی']],
    [['milk'],['دۆ','دوغ','ماست','شیر','لەبەن','لبن','ayran','عەیران','ئەیران']],
    [['coffee'],['چا','قاوە','قاوە','نسکافێ','نسکافە','coffee','tea','کابوچینۆ']],
    [['citrus'],['عەسیر','جووس','جوس','juice','لیمۆ','لیمو','شەربەت','پرتەقاڵ','پرتەقال','لیمونادە']],
    [['beer','wine'],['بیرە','beer']],
    [['salad','leaf'],['سالاد','سەلاتە','سەلاتە','سەوزە','سەوزی','کاهو','خس','تەماتە','خیار','فتوش','تبولە','تەبولە','salad']],
    [['soup','cooking-pot'],['حمص','حومس','حمس','هومس','بتحین','بتحینە','طحینە','طحینی','تەحینە','متبل','بابا','شۆربا','شۆرباو','شوربة','soup','حومص','فەتە','فتە','تەشریب']],
    [['cooking-pot','soup','wheat'],['برنج','برنجی','ڕز','رز','رزق','ریزق','بریانی','تەبسی','تەپسی','قەوزی','مەقلوبە','rice','بۆلاو','بولاو','پلاو']],
    [['wheat','croissant'],['نان','خبز','صەمۆن','سەمۆن','کولیرە','خوبز','لەفە','لفە','تەنوور','bread','تەنور','نانی']],
    [['drumstick'],['مریشک','دەجاج','جاج','فراخ','فرخ','چکن','chicken','بروستد','broast','زنگەر','زنکەر','باسترما','دەجاجە']],
    [['beef'],['گۆشت','لەحم','کەباب','کباب','کوفتە','کوفتە','شیش','تکە','تیکە','شاورما','دۆنەر','دونەر','بەرخ','بەران','کەلەک','meat','steak','ستەیک','لەحمە','ڕان','ران']],
    [['sandwich'],['ساندویج','ساندویچ','هەمبەرگەر','همبرگر','برگر','burger','sandwich','سەندویچ','هۆت دۆگ','هوتدوغ']],
    [['pizza'],['بیتزا','پیتزا','pizza']],
    [['french-fries','carrot'],['چیپس','چیبس','بەتاتە','پەتاتە','پەتەتە','بطاطا','فرایز','fries','potato','بەتاتا']],
    [['egg'],['هێلکە','هیلکە','بیض','egg','ئۆمڵێت','omelet']],
    [['cake-slice','cookie'],['کێک','کیک','کەیک','cake','شیرینی','حەلاوە','کلێچە','کلیجە','بسکوێت','بسکویت','بەقڵاوە','بەقلاوە','کنافە','کونافە','cookie','دۆناتس','دونات']],
    [['ice-cream-cone','ice-cream'],['بەستەنی','بستەنی','ئایس کریم','ice cream','ایس کریم','جیلاتۆ','ice','سەلج']],
    [['apple','citrus'],['میوە','سێو','سیو','مۆز','موز','هەنار','ترێ','ترێ','تری','فواکە','fruit','کیوی','شفتالی','شەفتالی','قەیسی','خۆخ','خوخ']],
    [['shrimp','fish'],['میگۆ','میگو','روبیان','shrimp','گەمبەری','کریڤەت']],
    [['fish'],['ماسی','سەلەمون','سلمون','salmon','کارپ','کارب','carp','دەریایی','دەرياىی','سمک','سەمەک','شبوط','شەبووت','شەبوت','بیاح','بەیاح','بیاح','هامور','هەمور','سەردین','tuna','تونە','fish','کەپور','تراوت','trout','کولبەک','قەڵغان','بنی','باس','باس']]
  ];
  var RULES_N=null;
  function buildRules(){
    RULES_N=ICON_RULES.map(function(r){return {ics:r[0],keys:r[1].map(normName).filter(function(k){return k.length>=2;})};});
  }
  function guessIcon(name){
    var n=normName(name);
    if(!n) return '';
    if(!RULES_N) buildRules();
    var words=n.split(/[\s\-–—·،,:؛/×x*()+\d]+/).filter(Boolean);
    for(var i=0;i<RULES_N.length;i++){
      var r=RULES_N[i];
      for(var j=0;j<r.keys.length;j++){
        var k=r.keys[j];
        var hit=(k.length<=3)?(words.indexOf(k)!==-1||words.some(function(w){return w.indexOf(k)===0&&w.length<=k.length+2;})):(n.indexOf(k)!==-1);
        if(hit){
          for(var c=0;c<r.ics.length;c++){ if(iconExists(r.ics[c])) return r.ics[c]; }
          return r.ics[r.ics.length-1];
        }
      }
    }
    return '';
  }
  return {build:build,totals:totals,infoRow:infoRow,chip:chip,esc:E,ic:ic,guessIcon:guessIcon};
})();
