(function(){
  var KEY='mf_card_order', DEFAULT=[], mode='swap', cur=null, root=null;
  function grid(){return document.querySelector('.dashboard-grid');}
  function cards(){var g=grid();return g?Array.prototype.filter.call(g.children,function(c){return c.classList&&c.classList.contains('menu-card');}):[];}
  function keyOf(c){return c.getAttribute('data-card-key')||'';}
  function titleOf(c){var t=c.querySelector('.card-title');return t?t.textContent.trim():keyOf(c);}
  function colorOf(c){var v=c.style.getPropertyValue('--wave-color').trim();return v||'var(--c-1,#4f46e5)';}
  function vis(){return cards().filter(function(c){return !c.classList.contains('mf-box-hidden');});}
  function renumber(){vis().forEach(function(c,i){var b=c.querySelector('.card-rank-badge');if(b)b.textContent=String(i+1);});}
  window.mfRenumberCards=renumber;
  function save(){try{localStorage.setItem(KEY,JSON.stringify(cards().map(keyOf)));}catch(e){}}
  function order(keys){
    var g=grid(); if(!g) return;
    var all=cards(), map={};
    all.forEach(function(c){map[keyOf(c)]=c;});
    var used={};
    keys.forEach(function(k){if(map[k]&&!used[k]){used[k]=1;g.appendChild(map[k]);}});
    all.forEach(function(c){if(!used[keyOf(c)])g.appendChild(c);});
    renumber();
  }
  function place(card,target){
    var g=grid(), list=vis(), from=list.indexOf(card), to=target-1;
    if(from<0||to<0||to>=list.length||from===to) return;
    if(mode==='swap'){
      var other=list[to], ph=document.createComment('');
      g.insertBefore(ph,card); g.insertBefore(card,other); g.insertBefore(other,ph); g.removeChild(ph);
    }else{
      var ref=(to>from)?list[to].nextSibling:list[to];
      g.insertBefore(card,ref);
    }
    renumber(); save();
    card.classList.add('mf-card-moved');
    setTimeout(function(){card.classList.remove('mf-card-moved');},1000);
    try{card.scrollIntoView({behavior:'smooth',block:'center'});}catch(e){}
  }
  function ensureSheet(){
    if(root) return root;
    root=document.createElement('div'); root.id='mf-cro-backdrop';
    root.innerHTML='<div class="mf-cro" role="dialog" aria-modal="true"></div>';
    root.addEventListener('click',function(e){if(e.target===root)close();});
    document.body.appendChild(root); return root;
  }
  function draw(){
    var list=vis(), idx=list.indexOf(cur), box=root.querySelector('.mf-cro');
    box.style.setProperty('--cro-c',colorOf(cur));
    var h='<div class="mf-cro-grab"></div><div class="mf-cro-head"><div class="mf-cro-num">'+(idx+1)+'</div><div class="mf-cro-t"><b>'+esc(titleOf(cur))+'</b><span>شوێنی ئێستا: ژمارە '+(idx+1)+' لە '+list.length+'</span></div><button type="button" class="mf-cro-x" data-a="close" aria-label="داخستن">✕</button></div>';
    h+='<div class="mf-cro-seg"><button type="button" data-a="m-swap" class="'+(mode==='swap'?'on':'')+'">ئالوگۆڕ</button><button type="button" data-a="m-move" class="'+(mode==='move'?'on':'')+'">گواستنەوە</button></div>';
    h+='<div class="mf-cro-hint">'+(mode==='swap'?'ژمارەیەک هەڵبژێرە، ئەم کارتە شوێنی لەگەڵ ئەو کارتە ئالوگۆڕ دەکات.':'ژمارەیەک هەڵبژێرە، ئەم کارتە دەگوازرێتەوە بۆ ئەو شوێنە و کارتەکانی تر ڕێزبەند دەبنەوە.')+'</div><div class="mf-cro-grid">';
    list.forEach(function(c,i){
      h+='<button type="button" class="mf-cro-cell'+(i===idx?' cur':'')+'" data-a="go" data-n="'+(i+1)+'" style="--cell-c:'+colorOf(c)+'"'+(i===idx?' disabled':'')+'><b>'+(i+1)+'</b><span>'+esc(titleOf(c))+'</span></button>';
    });
    h+='</div><div class="mf-cro-foot"><button type="button" class="mf-cro-reset" data-a="reset">گەڕاندنەوەی ڕێزبەندی بنەڕەتی</button></div>';
    box.innerHTML=h;
  }
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function open(card){
    cur=card; ensureSheet(); draw(); root.classList.add('open'); document.body.style.overflow='hidden';
  }
  function close(){ if(root) root.classList.remove('open'); document.body.style.overflow=''; cur=null; }
  document.addEventListener('click',function(e){
    var t=e.target; if(!t||!t.closest) return;
    var badge=t.closest('.dashboard-grid .card-rank-badge');
    if(badge){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();open(badge.closest('.menu-card'));return;}
    var btn=t.closest('#mf-cro-backdrop [data-a]'); if(!btn) return;
    var a=btn.getAttribute('data-a');
    if(a==='close') close();
    else if(a==='m-swap'){mode='swap';draw();}
    else if(a==='m-move'){mode='move';draw();}
    else if(a==='go'){var c=cur; close(); place(c,parseInt(btn.getAttribute('data-n'),10));}
    else if(a==='reset'){close();order(DEFAULT);save();try{localStorage.removeItem(KEY);}catch(e){}}
  },true);
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&root&&root.classList.contains('open'))close();});
  function init(){
    DEFAULT=cards().map(keyOf);
    var saved=null; try{saved=JSON.parse(localStorage.getItem(KEY)||'null');}catch(e){}
    if(Array.isArray(saved)&&saved.length) order(saved); else renumber();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
