(function(){
  var orig=FileReader.prototype.readAsDataURL, MAX=1000, MIN=150000, Q=0.75;
  // encodes a loaded <img>: max 1000px, opaque images -> JPEG, images with transparency -> WebP/PNG
  function encode(im,mime){
    var w=im.naturalWidth||im.width,h=im.naturalHeight||im.height,k=Math.min(1,MAX/Math.max(w,h));
    var c=document.createElement('canvas'); c.width=Math.max(1,Math.round(w*k)); c.height=Math.max(1,Math.round(h*k));
    var x=c.getContext('2d'); x.drawImage(im,0,0,c.width,c.height);
    var alpha=false;
    if(mime!=='image/jpeg'){
      try{var d=x.getImageData(0,0,c.width,c.height).data;for(var i=3;i<d.length;i+=4){if(d[i]<250){alpha=true;break;}}}catch(e){alpha=true;}
    }
    var out;
    if(alpha){out=c.toDataURL('image/webp',0.8);if(out.indexOf('data:image/webp')!==0)out=c.toDataURL('image/png');}
    else out=c.toDataURL('image/jpeg',Q);
    return {data:out,resized:k<1};
  }
  window.mfEncodeImage=encode;
  function shrink(file){
    return new Promise(function(res,rej){
      var u=URL.createObjectURL(file), im=new Image();
      im.onload=function(){
        try{
          var r=encode(im,file.type);
          URL.revokeObjectURL(u);
          // already small enough: keep the original untouched
          if(!r.resized && r.data.length>=file.size*1.37*0.95) res(null); else res(r.data);
        }catch(e){rej(e);}
      };
      im.onerror=function(){URL.revokeObjectURL(u);rej(new Error('img'));};
      im.src=u;
    });
  }
  FileReader.prototype.readAsDataURL=function(file){
    var self=this;
    if(!file||!/^image\/(jpeg|png|webp)$/.test(file.type)||file.size<MIN) return orig.call(this,file);
    shrink(file).then(function(d){
      if(!d){ orig.call(self,file); return; }
      Object.defineProperty(self,'result',{value:d,configurable:true});
      Object.defineProperty(self,'readyState',{value:2,configurable:true});
      self.dispatchEvent(new ProgressEvent('load'));
      self.dispatchEvent(new ProgressEvent('loadend'));
    }).catch(function(){ orig.call(self,file); });
  };
})();
