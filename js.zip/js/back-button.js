/* V66: دوگمەی گەڕانەوەی مۆبایل — چاککراو
   - هەمیشە پاسەوانێکی مێژوو (guard) ماوەتەوە، هەرگیز بەبێ پاسەوان نامێنێتەوە
   - تەنها لەسەر کرتە/touchend/keydown (ڕاستەقینە) پاسەوان دەخرێتە ناو مێژوو
   - لە هۆم: یەکەم داگرتن تەنها ئاگادارکردنەوە دەنیشێت، بۆ دەرچوون دەبێت دووبارە دابگیرێت (٠.٤ - ٢.٥ چرکە)
   - دوو داگرتنی زۆر خێرا (<٠.٤ چرکە) هەرگیز دەرناچێت */
(function () {
    var OVERLAYS = '.custom-popup-overlay.active, .ob-sheet-overlay.active, .mf-deal-sheet-overlay.active, .mf-delete-confirm-overlay.active, .mf-tools-sheet.active, .adhan-alert-overlay.active';
    var GUARD = { mf: 'guard' }, BASE = { mf: 'base' };
    var exitUntil = 0, lastHome = 0, leaving = false, toastEl = null, toastTimer = null;
    var EXIT_WINDOW = 2500, MIN_GAP = 400;

    function visible(el) { if (!el || !el.getClientRects().length) return false; var cs = getComputedStyle(el); return cs.display !== 'none' && cs.visibility !== 'hidden'; }
    function shown(id) { return visible(document.getElementById(id)); }
    function call(fn) { try { if (typeof window[fn] === 'function') { window[fn](); return true; } } catch (e) { console.error(e); } return false; }

    function topOverlay() {
        var list = Array.prototype.slice.call(document.querySelectorAll(OVERLAYS)).filter(visible);
        var best = null, bestZ = -1;
        list.forEach(function (el) { var z = parseInt(getComputedStyle(el).zIndex, 10) || 0; if (z >= bestZ) { best = el; bestZ = z; } });
        return best;
    }
    function closeOverlay(el) {
        try {
            if (el.id === 'popup-notebook' && typeof requestCloseNotebook === 'function') { requestCloseNotebook(); return; }
            if (el.id === 'popup-modern-prompt') {
                var c = document.getElementById('prompt-cancel-action');
                (visible(c) ? c : document.getElementById('prompt-confirm-action')).click(); return;
            }
            if (el.id === 'mf-delete-confirm') { var dc = document.getElementById('mf-delete-confirm-cancel'); if (dc) { dc.click(); return; } }
            var b = el.querySelector('.order-builder-close, .popup-close, .mf-sheet-close');
            if (visible(b)) { b.click(); if (el.classList.contains('active') && el.id !== 'popup-modern-prompt') { /* بۆ ئەو پۆپئەپانەی دوگمەکەیان پرسیار دەکات */ } return; }
        } catch (e) { console.error(e); }
        el.classList.remove('active');
    }

    /* ڕیزبەندی کارتە کراوەکان (بۆ گەڕانەوەی هەنگاو بە هەنگاو) */
    var navStack = [], replaying = false, clearT = null, origOpenCard = null;
    function activeEl(sel) { return document.querySelector(sel); }
    function seedStack() {
        try {
            var v = document.getElementById('view-category');
            if (v && v.classList.contains('active')) {
                var ls = JSON.parse(localStorage.getItem('mf_last_section') || 'null');
                if (ls && ls.title) navStack = [{ a: [ls.title, ls.icon, ls.color] }];
            }
        } catch (e) {}
    }
    function wrapNav() {
        var oc = window.openCardDashboard, hn = window.handleNavigation;
        if (typeof oc === 'function' && !oc.__mf) {
            origOpenCard = oc;
            var w = function (title, icon, color) {
                if (clearT) { clearTimeout(clearT); clearT = null; }       /* closeCategoryDashboard(); openCardDashboard(...) = گەڕان لە بەشێکەوە بۆ بەشێکی تر */
                var r = oc.apply(this, arguments);
                if (!replaying) {
                    var v = document.getElementById('view-category');
                    if (v && v.classList.contains('active')) {          /* ئەگەر قفڵکراو بوو و نەکرایەوە، تۆمار مەکە */
                        var e = { a: [title, icon, color] }, top = navStack[navStack.length - 1];
                        if (top && top.a[0] === title) navStack[navStack.length - 1] = e; else navStack.push(e);
                        if (navStack.length > 25) navStack.shift();
                    }
                }
                return r;
            };
            w.__mf = true; window.openCardDashboard = w;
        }
        if (typeof hn === 'function' && !hn.__mf) {
            var h = function (page) {
                if (page === 'home' && !replaying) { if (clearT) clearTimeout(clearT); clearT = setTimeout(function () { navStack = []; clearT = null; }, 0); }
                return hn.apply(this, arguments);
            };
            h.__mf = true; window.handleNavigation = h;
        }
    }
    function replayPrev() {
        navStack.pop();
        var prev = navStack[navStack.length - 1];
        if (!prev || !origOpenCard) return false;
        replaying = true;
        try { origOpenCard.apply(null, prev.a); } catch (e) { console.error(e); } finally { replaying = false; }
        return true;
    }

    /* دەگەڕێنێتەوە true ئەگەر شتێک داخرا — هەر داگرتنێک تەنها یەک ئاست دەگەڕێتەوە */
    function goBack() {
        var ov = topOverlay();
        if (ov) { closeOverlay(ov); return true; }
        if (activeEl('#oc-sheet-overlay.active') && call('closeOrderCardSheet')) return true;
        if (activeEl('#view-courier-profile-full.active') && call('closeCourierProfileView')) return true;
        var sheet = document.querySelector('.overlay-sheet.active');
        if (sheet) {                                   /* شاشەی خوارەوە (feed/size): تەنها خۆی دادەخرێت، نەک بچێتە هۆم */
            call('closeOverlaySheet');
            var hv = document.getElementById('view-home'), nh = document.getElementById('nav-home');
            if (hv && hv.classList.contains('active') && nh) nh.classList.add('active');
            return true;
        }
        if (shown('receipts-workspace-dashboard')) return call('closeReceiptsWorkspace');
        if (shown('purchase-workspace-dashboard')) return call('closePurchaseWorkspace');
        if (shown('sale-workspace-dashboard')) return call('closeSaleWorkspace');
        if (shown('tables-workspace-dashboard')) return call('closeTablesWorkspace');
        if (shown('customer-sub-dashboard')) {
            var tab = document.getElementById('sub-tab-orders');
            if (tab && !tab.classList.contains('active') && typeof switchSubTab === 'function') { switchSubTab('orders'); return true; }
        }
        var dashes = document.querySelectorAll('div[id$="-dashboard"]');
        for (var i = 0; i < dashes.length; i++) {
            if (visible(dashes[i])) {
                if (navStack.length > 1 && replayPrev()) return true;   /* بگەڕێوە بۆ کارتی پێشوو */
                navStack = [];
                return call('closeCategoryDashboard');
            }
        }
        var home = document.getElementById('view-home');
        if (home && !home.classList.contains('active') && typeof handleNavigation === 'function') { handleNavigation('home'); return true; }
        return false;
    }

    function toast(msg) {
        if (!toastEl) {
            toastEl = document.createElement('div');
            toastEl.style.cssText = 'position:fixed;left:50%;bottom:calc(92px + env(safe-area-inset-bottom,0px));transform:translate(-50%,20px);z-index:2147483000;padding:11px 20px;border-radius:99px;background:rgba(15,15,25,.92);color:#fff;font:800 13px var(--main-font,sans-serif);box-shadow:0 14px 30px -10px rgba(0,0,0,.6);opacity:0;pointer-events:none;transition:opacity .25s,transform .25s;white-space:nowrap;';
            document.body.appendChild(toastEl);
        }
        toastEl.textContent = msg;
        toastEl.style.opacity = '1'; toastEl.style.transform = 'translate(-50%,0)';
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { toastEl.style.opacity = '0'; toastEl.style.transform = 'translate(-50%,20px)'; }, 2400);
    }

    function hasGuard() { try { return !!(history.state && history.state.mf === 'guard'); } catch (e) { return false; } }
    function pushGuard() { if (leaving || hasGuard()) return; try { history.pushState(GUARD, ''); } catch (e) {} }

    /* لە سەرەتا: ڕووپەڕی ئێستا دەکەین بە base */
    try { if (!history.state || !history.state.mf) history.replaceState(BASE, ''); } catch (e) {}

    window.addEventListener('popstate', function () {
        if (leaving) return;
        if (hasGuard()) return;                       /* forward بۆ پاسەوان — هیچ مەکە */
        var handled = false;
        try { handled = goBack(); } catch (err) { console.error(err); }
        if (handled) { pushGuard(); return; }         /* شتێک داخرا: یەکسەر پاسەوان بگەڕێنەوە */

        var now = Date.now();
        if (now - lastHome < MIN_GAP) { pushGuard(); return; }          /* دوو داگرتنی خێرا: دەرمەچۆ */
        if (now < exitUntil) {                                           /* دووەم داگرتن لەناو کاتەکە: دەرچوون */
            leaving = true;
            try { history.back(); } catch (e) {}
            return;
        }
        lastHome = now;
        exitUntil = now + EXIT_WINDOW;
        toast('دووبارە دایبگرە بۆ دەرچوون لە ئەپەکە');
        pushGuard();
    });

    /* پاسەوان تەنها لەسەر ڕووداوی ڕاستەقینەی بەکارهێنەر (کە activation دەدات) */
    ['click', 'touchend', 'pointerup', 'keydown'].forEach(function (ev) {
        document.addEventListener(ev, pushGuard, { capture: true, passive: true });
    });
    window.addEventListener('pageshow', function () { leaving = false; });
    document.addEventListener('visibilitychange', function () { if (!document.hidden) { leaving = false; } });
    wrapNav(); seedStack();
    pushGuard();                                   /* پاسەوان لە سەرەتاوە، تەنانەت پێش یەکەم کرتە */
    window.mfBackNavigate = goBack;
})();
