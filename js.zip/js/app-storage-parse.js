(function(){
  function mfSafeGet(key, fallback){
    try { var v = localStorage.getItem(key); return v != null && v !== '' ? JSON.parse(v) : fallback; }
    catch(e){ return fallback; }
  }
  function setPreview(id, html){
    var el = document.getElementById(id);
    if (el) { el.innerHTML = html; if (window.safeCreateIcons) window.safeCreateIcons(); }
  }
  function run(){
    try {
      var receipts = mfSafeGet('mf_receipts', {});
      var cust = (receipts.customer || []).length;
      setPreview('cp-customers', '<i data-lucide="receipt"></i><span><span class="cp-num">' + cust + '</span> پسووڵەی کڕیار</span>');

      var pn = (receipts.purchase || []).length;
      setPreview('cp-purchase', '<i data-lucide="shopping-cart"></i><span><span class="cp-num">' + pn + '</span> کڕین تۆمارکراو</span>');

      var sn = (receipts.sales || []).length;
      setPreview('cp-sales', '<i data-lucide="banknote"></i><span><span class="cp-num">' + sn + '</span> فرۆشتن تۆمارکراو</span>');

      var totalReceipts = Object.keys(receipts).reduce(function(s,k){ return s + ((receipts[k]||[]).length); }, 0);
      setPreview('cp-receipts', '<i data-lucide="receipt"></i><span><span class="cp-num">' + totalReceipts + '</span> وەسڵی گشتی</span>');
    } catch(e){}

    try {
      var tables = mfSafeGet('mf_tables_data', {});
      var total = 0, occ = 0;
      ['men_room','family_room','men_garden','family_garden'].forEach(function(k){
        (tables[k] || []).forEach(function(t){ total++; if (t && t.name) occ++; });
      });
      setPreview('cp-tables', '<i data-lucide="armchair"></i><span><span class="cp-num">' + occ + '/' + total + '</span> مێزی بەکارهاتوو</span>');
    } catch(e){}

    try {
      var supplies = mfSafeGet('mf_supplies_data', null);
      var waiting = 0;
      if (supplies && Array.isArray(supplies.sections)) {
        supplies.sections.forEach(function(sec){ (sec.items || []).forEach(function(it){ if (it && it.status === 'waiting') waiting++; }); });
      }
      setPreview('cp-supplies', '<i data-lucide="package"></i><span><span class="cp-num">' + waiting + '</span> پێداویستی چاوەڕوان</span>');
    } catch(e){}

    try {
      var exp = mfSafeGet('mf_daily_expenses', []);
      setPreview('cp-expenses', '<i data-lucide="trending-down"></i><span><span class="cp-num">' + ((exp && exp.length) || 0) + '</span> خەرجی تۆمارکراو</span>');
    } catch(e){}

    try {
      var debts = mfSafeGet('mf_debt_profiles', {});
      setPreview('cp-debts', '<i data-lucide="credit-card"></i><span><span class="cp-num">' + Object.keys(debts).length + '</span> قەرزار تۆمارکراو</span>');
    } catch(e){}

    try {
      var mydebts = mfSafeGet('mf_my_debt_profiles', {});
      setPreview('cp-mydebts', '<i data-lucide="wallet"></i><span><span class="cp-num">' + Object.keys(mydebts).length + '</span> قەرزدەر تۆمارکراو</span>');
    } catch(e){}

    try {
      var emps = mfSafeGet('mf_employees', {});
      setPreview('cp-employees', '<i data-lucide="briefcase"></i><span><span class="cp-num">' + Object.keys(emps).length + '</span> کارمەند تۆمارکراو</span>');
    } catch(e){}

    try {
      var days = ['یەکشەممە','دووشەممە','سێشەممە','چوارشەممە','پێنجشەممە','هەینی','شەممە'];
      var now = new Date();
      var label = days[now.getDay()] + '، ' + now.getDate() + '/' + (now.getMonth() + 1);
      setPreview('cp-days', '<i data-lucide="calendar"></i><span>' + label + '</span>');
    } catch(e){}

    try {
      var colors = mfSafeGet('mf_custom_colors', []);
      var n = Array.isArray(colors) ? colors.length : 0;
      var swHtml = '';
      (Array.isArray(colors) ? colors.slice(0, 4) : []).forEach(function(c){
        var hex = (typeof c === 'string') ? c : (c && (c.value || c.color || c.hex)) || '#999';
        swHtml += '<span class="cp-swatch" style="background:' + hex + '"></span>';
      });
      setPreview('cp-colorlab', '<i data-lucide="palette"></i><span><span class="cp-num">' + n + '</span> ڕەنگی تایبەت</span>');
      var sw = document.getElementById('cp-colorlab-swatches');
      if (sw) sw.innerHTML = swHtml;
    } catch(e){}
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
  setInterval(run, 20000);
  (function(){
    function attachPressFeedback(){
      document.querySelectorAll('.menu-card').forEach(function(card){
        if (card.dataset.mfPressBound) return;
        card.dataset.mfPressBound = '1';
        var pressOn = function(){ card.classList.add('mf-pressed'); };
        var pressOff = function(){ card.classList.remove('mf-pressed'); };
        card.addEventListener('touchstart', pressOn, { passive: true });
        card.addEventListener('touchend', pressOff, { passive: true });
        card.addEventListener('touchcancel', pressOff, { passive: true });
        card.addEventListener('mousedown', pressOn);
        card.addEventListener('mouseup', pressOff);
        card.addEventListener('mouseleave', pressOff);
      });
    }
    attachPressFeedback();
    var mo = new MutationObserver(attachPressFeedback);
    mo.observe(document.body, { childList: true, subtree: true });
  })();
})();
