(function(){
  var cur=null;
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function $(id){return document.getElementById(id);}
  function num(v){return parseInt(String(v==null?'':v).replace(/[^0-9]/g,''))||0;}
  function liveMoney(s,cur){s=String(s==null?'':s).replace(/[\u0660-\u0669]/g,function(d){return String(d.charCodeAt(0)-0x0660);}).replace(/[\u06F0-\u06F9]/g,function(d){return String(d.charCodeAt(0)-0x06F0);}).replace(/\u066B/g,'.').replace(/[^0-9.]/g,'');
    if(cur!=='USD')s=s.replace(/\./g,'');
    var dot=s.indexOf('.'),ip=dot<0?s:s.slice(0,dot),dp=dot<0?'':s.slice(dot+1).replace(/\./g,'');
    ip=ip.replace(/^0+(?=\d)/,'').replace(/\B(?=(\d{3})+(?!\d))/g,',');
    if(cur==='USD'&&dot>=0)return (ip||'0')+'.'+dp.slice(0,2);
    return ip;}
  function fmt(n){return (n||0).toLocaleString('en-US');}
  function ic(){if(window.safeCreateIcons)safeCreateIcons();}
  function F(id,label,val,o){o=o||{};var t=o.type||'text';
    if(t==='select')return '<div class="rce-f'+(o.full?' full':'')+'"><label>'+label+'</label><select id="'+id+'">'+o.opts.map(function(x){return '<option value="'+esc(x[0])+'"'+(String(x[0])===String(val)?' selected':'')+'>'+esc(x[1])+'</option>';}).join('')+'</select></div>';
    if(t==='textarea')return '<div class="rce-f full"><label>'+label+'</label><textarea id="'+id+'">'+esc(val)+'</textarea></div>';
    return '<div class="rce-f'+(o.full?' full':'')+'"><label>'+label+'</label><input id="'+id+'" type="'+(t==='money'?'text':t)+'"'+(t==='money'?' inputmode="numeric" class="num" value="'+fmt(val)+'" oninput="mfRceMoney(this)"':' value="'+esc(val)+'"')+(o.list?' list="'+o.list+'"':'')+(o.cls?' class="'+o.cls+'"':'')+(o.oninput?' oninput="'+o.oninput+'"':'')+'></div>';}
  window.mfRceMoney=function(i){if(i.id==='rce-amount'){i.value=liveMoney(i.value,($('rce-cur')||{}).value);return;}var n=num(i.value);i.value=n?fmt(n):'';if(i.id==='rce-price')mfRceAuto();};
  function build(){
    if($('popup-rec-edit'))return;
    var d=document.createElement('div');d.id='popup-rec-edit';d.className='custom-popup-overlay';d.style.zIndex='3800';
    d.innerHTML='<div class="order-builder-window order-status-sheet"><div class="order-builder-header"><h3 id="rce-title">دەستکاری تۆمار</h3><button class="order-builder-close" onclick="mfRecClose()"><i data-lucide="x"></i></button></div><div class="order-builder-body" id="rce-body"></div></div>';
    document.body.appendChild(d);
  }
  function dt(e){return {d:e.date||new Date().toISOString().split('T')[0],t:String(e.time||'00:00:00').substring(0,5)};}
  function applyDT(e,date,time){
    e.date=date; e.time=(time||'00:00')+':'+((e.time&&String(e.time).length>=8&&String(e.time).substring(0,5)===time)?String(e.time).substring(6,8):'00');
    try{e.day=kurdishDayName(new Date(date+'T00:00:00'));}catch(x){}
    var ts=new Date(date+'T'+e.time).getTime(); if(isFinite(ts))e.timestamp=ts;
  }
  function dtFields(e,idp){var x=dt(e);return F(idp+'date','بەروار',x.d,{type:'date'})+F(idp+'time','کات',x.t,{type:'time'});}

  /* ---------- purchase / sale entries ---------- */
  function trade(kind){
    var P=kind==='purchase';
    return {P:P,cfg:function(){return P?PURCHASE_CATEGORIES[currentPurchaseCategory]:SALE_CATEGORIES[currentSaleCategory];},
      entry:function(){return P?getActivePurchaseEntry():getActiveSaleEntry();},
      types:function(){return (P?purchaseCustomTypes:saleCustomTypes)[P?currentPurchaseCategory:currentSaleCategory]||[];},
      save:function(){P?savePurchaseProfiles():saveSaleProfiles();},
      after:function(){if(P){renderPurchaseEntryDetailBody();renderPurchaseProfileDetailBody();renderPurchaseProfiles();}else{renderSaleEntryDetailBody();renderSaleProfileDetailBody();renderSaleProfiles();}},
      who:P?[['buyerName','ناوی کڕیار'],['buyerPhone','ژمارەی کڕیار']]:[['sellerName','ناوی فرۆشیار'],['sellerPhone','ژمارەی فرۆشیار']],
      pre:P?'pur':'sl'};
  }
  function boxRow(b,i){
    return '<div class="rce-row box"><div class="rce-rowhead"><span>سندووق <b class="rce-n">'+(i+1)+'</b></span><button type="button" class="rce-x" onclick="mfRceDel(this)"><i data-lucide="trash-2"></i></button></div><div class="rce-grid">'+
      '<div class="rce-f full"><label>جۆری ژماردن</label><select data-k="unitType"><option value="kilo"'+(b.unitType!=='count'?' selected':'')+'>کیلۆ / گرام</option><option value="count"'+(b.unitType==='count'?' selected':'')+'>ژمارە / دانە</option></select></div>'+
      '<div class="rce-f"><label>دانە</label><input data-k="fishCount" class="num" inputmode="numeric" value="'+(b.fishCount||0)+'"></div>'+
      '<div class="rce-f"><label>کیلۆ</label><input data-k="kilo" class="num" inputmode="numeric" value="'+(b.kilo||0)+'" oninput="mfRceAuto()"></div>'+
      '<div class="rce-f"><label>گرام</label><input data-k="gram" class="num" inputmode="numeric" value="'+(b.gram||0)+'" oninput="mfRceAuto()"></div>'+
      '<input type="hidden" data-k="discount" value="'+(b.discount?1:0)+'"></div></div>';
  }
  function payRow(p){
    var x=dt(p);
    return '<div class="rce-row pay" data-id="'+esc(p.id||'')+'"><div class="rce-rowhead"><span>پارەدان</span><button type="button" class="rce-x" onclick="mfRceDel(this)"><i data-lucide="trash-2"></i></button></div><div class="rce-grid">'+
      '<div class="rce-f full"><label>بڕ (د.ع)</label><input data-k="amount" class="num" inputmode="numeric" value="'+fmt(p.amount)+'" oninput="mfRceMoney(this)"></div>'+
      '<div class="rce-f"><label>دەرچوو لە</label><input data-k="payer" value="'+esc(p.payer||'')+'"></div>'+
      '<div class="rce-f"><label>وەرگیرا لەلایەن</label><input data-k="receiver" value="'+esc(p.receiver||'')+'"></div>'+
      '<div class="rce-f full"><label>شاهید</label><input data-k="witness" value="'+esc(p.witness||'')+'"></div>'+
      '<div class="rce-f"><label>بەروار</label><input data-k="date" type="date" value="'+esc(x.d)+'"></div>'+
      '<div class="rce-f"><label>کات</label><input data-k="time" type="time" value="'+esc(x.t)+'"></div></div></div>';
  }
  window.mfRceDel=function(btn){var r=btn.closest('.rce-row');if(r)r.remove();var n=0;document.querySelectorAll('#rce-boxes .rce-n').forEach(function(e){e.textContent=++n;});mfRceAuto();};
  window.mfRceAddBox=function(){var h=boxRow({unitType:'kilo',discount:cur&&cur.disc},document.querySelectorAll('#rce-boxes .box').length);$('rce-boxes').insertAdjacentHTML('beforeend',h);ic();};
  window.mfRceAddPay=function(){$('rce-pays').insertAdjacentHTML('beforeend',payRow({amount:0,date:new Date().toISOString().split('T')[0],time:new Date().toTimeString().substring(0,5)}));ic();};
  function readBoxes(){
    var cfg=cur.t.cfg(),pct=(cfg&&cfg.legalDiscountPct)||3,out=[];
    document.querySelectorAll('#rce-boxes .box').forEach(function(r){
      function g(k){var e=r.querySelector('[data-k="'+k+'"]');return e?e.value:'';}
      var bf=num(g('fishCount')),bk=num(g('kilo')),bg=num(g('gram')),disc=g('discount')==='1';
      var raw=bk*1000+bg,fin=(cfg&&cfg.legalDiscount&&disc)?Math.round(raw*(100-pct)/100):raw;
      out.push({fishCount:bf,kilo:bk,gram:bg,unitType:g('unitType')==='count'?'count':'kilo',discount:disc,finalKilo:Math.floor(fin/1000),finalGram:fin%1000,_fin:fin,_raw:raw});
    });return out;
  }
  function calcTotal(){
    var price=num($('rce-price').value),bs=readBoxes(),basis=cur.e.priceBasis||'kilo';
    if(basis==='count')return Math.round(price*bs.reduce(function(a,b){return a+b.fishCount;},0));
    return Math.round(price*bs.reduce(function(a,b){return a+b._fin;},0)/1000);
  }
  window.mfRceAuto=function(){if(!cur||!cur.t||!$('rce-auto')||!$('rce-auto').checked)return;$('rce-total').value=fmt(calcTotal());};
  window.mfRceCalc=function(){$('rce-total').value=fmt(calcTotal());};
  function openTrade(kind){
    var t=trade(kind),e=t.entry();if(!e)return;
    build();cur={kind:kind,t:t,e:e,disc:!!(e.totals&&e.totals.legalDiscountApplied)};
    var wasAuto=false;
    try{var bs0=(e.boxes||[]).map(function(b){var cfg=t.cfg(),raw=(b.kilo||0)*1000+(b.gram||0);return (cfg&&cfg.legalDiscount&&b.discount)?Math.round(raw*(100-(cfg.legalDiscountPct||3))/100):raw;});
      var c0=(e.priceBasis==='count')?Math.round((e.price||0)*(e.boxes||[]).reduce(function(a,b){return a+(parseInt(b.fishCount)||0);},0)):Math.round((e.price||0)*bs0.reduce(function(a,b){return a+b;},0)/1000);
      wasAuto=(c0===(e.totalPayment||0));}catch(x){}
    var types=t.types().slice();if(e.type&&types.indexOf(e.type)<0)types.unshift(e.type);
    var h='<datalist id="rce-types">'+types.map(function(x){return '<option value="'+esc(x)+'">';}).join('')+'</datalist>';
    h+='<div class="rce-sec" style="margin-top:0"><h4><i data-lucide="info"></i> زانیاری سەرەکی</h4><div class="rce-grid">'+
       F('rce-type','جۆر',e.type||'',{list:'rce-types',full:true})+
       F('rce-price','نرخی یەکە ('+(e.priceBasis==='count'?'بۆ هەر دانەیەک':'بۆ هەر کیلۆیەک')+')',e.price||0,{type:'money'})+
       t.who.map(function(w,i){return F('rce-w'+i,w[1],e[w[0]]||'',{});}).join('')+
       dtFields(e,'rce-')+'</div></div>';
    h+='<div class="rce-sec"><h4><i data-lucide="package"></i> سندووقەکان</h4><div id="rce-boxes">'+(e.boxes||[]).map(boxRow).join('')+'</div><button type="button" class="rce-add" onclick="mfRceAddBox()"><i data-lucide="plus"></i> زیادکردنی سندووق</button></div>';
    h+='<div class="rce-sec"><h4><i data-lucide="banknote"></i> کۆی گشتی</h4><div class="rce-total">'+F('rce-total','کۆی گشتی (د.ع)',e.totalPayment||0,{type:'money'})+'<button type="button" class="rce-calc" onclick="mfRceCalc()"><i data-lucide="calculator"></i> ژماردن</button></div><label class="rce-chk"><input type="checkbox" id="rce-auto"'+(wasAuto?' checked':'')+' onchange="mfRceAuto()"> کۆی گشتی خۆکارانە لە نرخ و سندووقەکان بژمێرە</label></div>';
    h+='<div class="rce-sec"><h4><i data-lucide="wallet"></i> پارەدانەکان</h4><div id="rce-pays">'+(e.payments||[]).map(payRow).join('')+'</div><button type="button" class="rce-add" onclick="mfRceAddPay()"><i data-lucide="plus"></i> زیادکردنی پارەدان</button></div>';
    h+='<button class="ob-create-btn" style="margin-top:18px;background:var(--c-29);" onclick="mfRecSave()"><i data-lucide="save"></i> پاشەکەوتکردنی گۆڕانکاری</button>';
    $('rce-title').textContent=kind==='purchase'?'دەستکاری تەواوی کڕین':'دەستکاری تەواوی فرۆشتن';
    $('rce-body').innerHTML=h;$('popup-rec-edit').classList.add('active');ic();
  }
  function saveTrade(){
    var e=cur.e,t=cur.t,price=num($('rce-price').value),bs=readBoxes(),type=$('rce-type').value.trim();
    if(!type){showInfoPrompt('تێبینی','جۆر نابێت بەتاڵ بێت.');return false;}
    bs=bs.filter(function(b){return b.fishCount>0||b.kilo>0||b.gram>0;});
    if(!bs.length){showInfoPrompt('تێبینی','لانی کەم زانیاری یەک سندووق بنووسە.');return false;}
    if($('rce-auto').checked)$('rce-total').value=fmt(calcTotal());
    var total=num($('rce-total').value);
    if(total<=0){showInfoPrompt('تێبینی','کۆی گشتی دەبێت لە سفر زیاتر بێت.');return false;}
    var date=$('rce-date').value,time=$('rce-time').value;if(!date){showInfoPrompt('تێبینی','بەروار هەڵبژێرە.');return false;}
    var pays=[],bad=false;
    document.querySelectorAll('#rce-pays .pay').forEach(function(r){
      function g(k){var x=r.querySelector('[data-k="'+k+'"]');return x?x.value.trim():'';}
      var a=num(g('amount'));if(a<=0){bad=true;return;}
      var old=(e.payments||[]).find(function(p){return p.id===r.getAttribute('data-id');})||{};
      var np=Object.assign({},old,{id:old.id||((t.P?'ppay_':'spay_')+Date.now()+'_'+Math.floor(Math.random()*100000)),amount:a,payer:g('payer'),receiver:g('receiver'),witness:g('witness')});
      applyDT(np,g('date')||date,g('time')||'00:00');pays.push(np);
    });
    if(bad){showInfoPrompt('تێبینی','بڕی هەموو پارەدانەکان دەبێت لە سفر زیاتر بێت (یان پارەدانەکە بسڕەوە).');return false;}
    var fish=0,fin=0,raw=0,disc=false;
    var boxes=bs.map(function(b){fish+=b.fishCount;fin+=b._fin;raw+=b._raw;if(b.discount)disc=true;return {fishCount:b.fishCount,kilo:b.kilo,gram:b.gram,unitType:b.unitType,discount:b.discount,finalKilo:b.finalKilo,finalGram:b.finalGram};});
    e.type=type;e.price=price;e.boxes=boxes;e.totalPayment=total;e.payments=pays;
    e.totals=Object.assign({},e.totals,{boxCount:boxes.length,fishCount:fish,kilo:Math.floor(fin/1000),gram:fin%1000,rawKilo:Math.floor(raw/1000),rawGram:raw%1000,legalDiscountApplied:disc});
    t.who.forEach(function(w,i){e[w[0]]=$('rce-w'+i).value.trim();});
    applyDT(e,date,time);
    t.save();t.after();return true;
  }

  /* ---------- debt ledger / my-debt ledger ---------- */
  function openLedger(kind,id){
    var my=kind==='mydebt',p=my?myDebtProfiles[activeMyDebtId]:debtProfiles[activeDebtDetailId];if(!p)return;
    var e=(p.ledger||[]).find(function(x){return x.id===id;});if(!e)return;
    build();cur={kind:kind,p:p,e:e};
    var plus=my?'debt':'borrow',minus=my?'payment':'repay';
    var h='<div class="rce-sec" style="margin-top:0"><div class="rce-grid">'+
      F('rce-type','جۆری تۆمار',e.type===minus?minus:plus,{type:'select',opts:[[plus,'زیادکردنی قەرز'],[minus,'گەڕاندنەوەی قەرز']],full:true})+
      F('rce-amount','بڕ',e.amount||0,{type:'money'})+
      F('rce-cur','دراو',e.currency||p.currency||'IQD',{type:'select',opts:[['IQD','دینار (IQD)'],['USD','دۆلار (USD)']]})+
      F('rce-recv','ناوی وەرگر',e.receiver||'',{})+F('rce-lend','ناوی ئەو کەسەی قەرزەکەی داوەتەوە',e.lender||'',{})+
      F('rce-wit','ناوی شاهید',e.witness||'',{full:true})+
      F('rce-note','تێبینی',e.note||'',{type:'textarea'})+
      dtFields(e,'rce-')+'</div></div>';
    if(e.auto)h+='<div class="rce-warn">ئەم تۆمارە خۆکارە (لە داواکاریەوە دروست بووە). گۆڕینی بڕەکە تەنیا لێرە کاریگەر دەبێت.</div>';
    h+='<button class="ob-create-btn" style="margin-top:18px;background:var(--c-29);" onclick="mfRecSave()"><i data-lucide="save"></i> پاشەکەوتکردنی گۆڕانکاری</button>';
    $('rce-title').textContent='دەستکاری تۆمار';$('rce-body').innerHTML=h;$('popup-rec-edit').classList.add('active');ic();
    (function(){var cs=$('rce-cur'),am=$('rce-amount');if(!cs||!am)return;setDebtAmountDecimal(am,cs.value==='USD');
      cs.addEventListener('change',function(){setDebtAmountDecimal(am,cs.value==='USD');am.value=liveMoney(am.value,cs.value);});})();
  }
  function saveLedger(){
    var e=cur.e,p=cur.p,a=parseDebtAmount($('rce-amount').value,$('rce-cur').value);
    if(a<=0){showInfoPrompt('تێبینی','بڕێکی دروست بنووسە.');return false;}
    var date=$('rce-date').value;if(!date){showInfoPrompt('تێبینی','بەروار هەڵبژێرە.');return false;}
    var prevCur=e.currency||p.currency||'IQD',newCur=$('rce-cur').value;
    e.type=$('rce-type').value;e.amount=a;e.currency=newCur;if(!(Number(e.rate)>0)||prevCur!==newCur){var rr=debtRateStamp();if(rr)e.rate=rr;}e.receiver=$('rce-recv').value.trim();e.lender=$('rce-lend').value.trim();e.witness=$('rce-wit').value.trim();e.note=$('rce-note').value.trim()||e.note;
    applyDT(e,date,$('rce-time').value);
    if(cur.kind==='mydebt'){saveMyDebtProfiles();renderMyDebtDetail();renderMyDebtProfiles();var d=$('popup-my-debt-ledger-detail');if(d&&d.classList.contains('active'))openMyDebtLedgerDetail(e.id);}
    else{saveDebtProfiles();renderDebtProfileDetailBody();renderDebtProfilesAll();var d2=$('popup-debt-ledger-detail');if(d2&&d2.classList.contains('active'))openDebtLedgerDetail(e.id);}
    return true;
  }

  /* ---------- expenses ---------- */
  function openExpense(id){
    var e=dailyExpenses.find(function(x){return x.id===id;});if(!e)return;
    build();cur={kind:'expense',e:e};
    var h='<div class="rce-sec" style="margin-top:0"><div class="rce-grid">'+
      F('rce-name','ناوی کەسی خەرجکەر',e.name||'',{full:true})+F('rce-item','جۆری کاڵا / خەرجی',e.item||'',{full:true})+
      F('rce-price','نرخ (د.ع)',e.price||0,{type:'money',full:true})+dtFields(e,'rce-')+'</div>'+
      '<label class="rce-chk"><input type="checkbox" id="rce-skip"'+(e.skipDay?' checked':'')+'> لە کۆی ڕۆژ دەرەوە بێت</label></div>';
    if(e.source&&e.source!=='manual')h+='<div class="rce-warn">ئەم خەرجیە خۆکارە ('+esc(e.source)+')، گۆڕینی لێرە کاریگەری لەسەر تۆماری سەرچاوەکەی نابێت.</div>';
    h+='<button class="ob-create-btn" style="margin-top:18px;background:var(--c-29);" onclick="mfRecSave()"><i data-lucide="save"></i> پاشەکەوتکردنی گۆڕانکاری</button>';
    $('rce-title').textContent='دەستکاری خەرجی';$('rce-body').innerHTML=h;$('popup-rec-edit').classList.add('active');ic();
  }
  function saveExpense(){
    var e=cur.e,pr=num($('rce-price').value);
    if(pr<=0){showInfoPrompt('تێبینی','نرخێکی دروست بنووسە.');return false;}
    var date=$('rce-date').value;if(!date){showInfoPrompt('تێبینی','بەروار هەڵبژێرە.');return false;}
    e.name=$('rce-name').value.trim();e.item=$('rce-item').value.trim()||'خەرجی';e.price=pr;e.skipDay=$('rce-skip').checked?true:undefined;if(!e.skipDay)delete e.skipDay;
    applyDT(e,date,$('rce-time').value);
    saveDailyExpenses();renderExpensesHub();return true;
  }

  window.mfRecEdit=function(kind,id){
    if(typeof notebookMutationBlocked==='function'&&notebookMutationBlocked())return;
    if(kind==='purchase'||kind==='sale')openTrade(kind);
    else if(kind==='debt'||kind==='mydebt')openLedger(kind,id);
    else if(kind==='expense')openExpense(id);
  };
  window.mfRecClose=function(){var d=$('popup-rec-edit');if(d)d.classList.remove('active');cur=null;};
  window.mfRecSave=function(){
    if(!cur)return;var ok=false;
    try{ok=(cur.kind==='purchase'||cur.kind==='sale')?saveTrade():(cur.kind==='expense'?saveExpense():saveLedger());}
    catch(err){console.error(err);showInfoPrompt('هەڵە','پاشەکەوتکردن سەرکەوتوو نەبوو: '+err.message);return;}
    if(ok)mfRecClose();
  };
})();
