(function () {
  var css = document.createElement('style');
  css.textContent = '@keyframes mfLiveFlash{0%{box-shadow:0 0 0 0 rgba(109,61,240,.55)}100%{box-shadow:0 0 0 14px rgba(109,61,240,0)}}.oc.mf-live-flash{animation:mfLiveFlash .9s ease-out 1}';
  document.head.appendChild(css);

  function tryDo(fn) { try { fn(); } catch (e) { console.warn('mfLiveApply:', e); } }

  // Update only the order cards that really changed (no full list rebuild => no flicker, scroll and open cards stay)
  function patchOrders(oldList) {
    var grid = document.getElementById('orders-cards-list');
    var emptyState = document.getElementById('orders-empty-state');
    var countLabel = document.getElementById('orders-count-label');
    if (!grid || !emptyState || !countLabel) return;
    var si = document.getElementById('orders-search-input');
    var q = si ? si.value.trim().toLowerCase() : '';
    var filtered = q ? ordersList.filter(function (o) { return ((o.draft && o.draft.customerName) || '').toLowerCase().indexOf(q) > -1 || ((o.draft && o.draft.customerPhone) || '').indexOf(q) > -1; }) : ordersList;
    if (!ordersList.length || !filtered.length || !grid.querySelector('.oc')) { renderOrdersList(); return; }

    var oldSig = {};
    (oldList || []).forEach(function (o) { oldSig[o.id] = JSON.stringify(o); });
    var sorted = filtered.slice().sort(function (a, b) { return (a.id || 0) - (b.id || 0); });
    var want = {}; sorted.forEach(function (o) { want[o.id] = 1; });

    Array.prototype.slice.call(grid.children).forEach(function (el) {
      var m = /^order-card-(.+)$/.exec(el.id || '');
      if (!m || !want[m[1]]) el.remove();
    });

    var prev = null, flashed = [];
    sorted.forEach(function (o) {
      var el = document.getElementById('order-card-' + o.id);
      if (!el || oldSig[o.id] !== JSON.stringify(o)) {
        var t = document.createElement('template');
        t.innerHTML = renderOrderCard(o).trim();
        var fresh = t.content.firstElementChild;
        if (el) el.replaceWith(fresh);
        el = fresh; flashed.push(el);
      }
      var expected = prev ? prev.nextElementSibling : grid.firstElementChild;
      if (el !== expected) grid.insertBefore(el, expected);
      prev = el;
    });

    emptyState.style.display = 'none';
    countLabel.textContent = q ? (filtered.length + ' لە ' + ordersList.length + ' داواکاری') : (ordersList.length + ' داواکاری');
    tryDo(function () { safeCreateIcons(); });
    flashed.forEach(function (el) {
      el.classList.add('mf-live-flash');
      el.addEventListener('animationend', function () { el.classList.remove('mf-live-flash'); }, { once: true });
    });
  }

  window.mfLiveApply = function (key) {
    var raw = localStorage.getItem(key), v = null;
    try { v = raw ? JSON.parse(raw) : null; } catch (e) { return false; }

    if (key === 'mf_login_requests') return true;
    if (key === 'mf_order_next_id_by_page') { orderNextIdByPage = v || {}; return true; }

    if (key === 'mf_orders_by_page') {
      var oldList = ordersList;
      ordersByPage = v || {};
      var k = currentOrdersPageKey(); if (!ordersByPage[k]) ordersByPage[k] = [];
      ordersList = ordersByPage[k];
      if (document.getElementById('orders-cards-list')) {
        try { patchOrders(oldList); } catch (e) { console.warn('patchOrders failed, full render', e); tryDo(renderOrdersList); }
        tryDo(renderDebtProfilesAll);
        tryDo(refreshDailySummaryIfVisible);
      }
      return true;
    }

    if (key === 'mf_tables_data') {
      tablesData = v || {};
      tryDo(function () { if (document.getElementById('tables-grid-container') && currentTablesSection) renderTablesGrid(); });
      tryDo(updateCustomerNotifyBell);
      tryDo(function () { if (document.getElementById('tables-notify-list')) renderTablesNotifyList(); });
      return true;
    }

    if (key === 'mf_debt_profiles') { debtProfiles = v || {}; tryDo(renderDebtProfilesAll); tryDo(refreshDailySummaryIfVisible); return true; }
    if (key === 'mf_my_debt_profiles') { myDebtProfiles = v || {}; tryDo(renderMyDebtProfiles); return true; }
    if (key === 'mf_daily_expenses') {
      dailyExpenses = Array.isArray(v) ? v : [];
      tryDo(renderTodayExpensePreview);
      tryDo(function () { var p = document.getElementById('sub-panel-expenses'); if (p && p.offsetParent !== null) renderExpensesHub(); });
      tryDo(refreshDailySummaryIfVisible);
      return true;
    }
    if (key === 'mf_receipts') {
      receiptsStore = v || { customer: [], sales: [], purchase: [], expenses: [], kitchen: [], debt: [], general: [], supply: [], mydebt: [] };
      tryDo(renderReceiptsWorkspace);
      return true;
    }
    if (key === 'mf_receipt_next_number') { if (v) receiptNextNumber = v; return true; }
    if (key === 'mf_receipt_code_seq') { receiptCodeSeq = parseInt(raw || '0', 10) || 0; return true; }
    if (key === 'mf_purchase_profiles') { purchaseProfiles = v || {}; tryDo(renderPurchaseProfiles); return true; }
    if (key === 'mf_sale_profiles') { saleProfiles = v || {}; tryDo(renderSaleProfiles); return true; }
    if (key === 'mf_employees') { employees = v || {}; tryDo(function () { if (document.getElementById('emp-mgmt-search')) renderEmployeeManagementList(); }); return true; }
    if (key === 'mf_supplies_data') { suppliesData = v || defaultSuppliesData(); tryDo(renderSupplyManageList); return true; }
    if (key === 'mf_couriers_data') { couriersData = Array.isArray(v) ? v : []; tryDo(renderCouriersList); return true; }
    return false;
  };
})();
