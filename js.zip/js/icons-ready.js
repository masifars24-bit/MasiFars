document.addEventListener('DOMContentLoaded',function(){ try{ if(typeof safeCreateIcons==='function') safeCreateIcons(); else if(window.lucide) lucide.createIcons(); }catch(e){} });
