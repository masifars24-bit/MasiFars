(function(){
  var KEY='mf_login_requests',TTL=10*60*1000,cur=null,waitT=null,watchId=null;
  function $(i){return document.getElementById(i);}
  function read(){try{var a=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(a)?a:[];}catch(e){return [];}}
  function write(a){try{localStorage.setItem(KEY,JSON.stringify(a));}catch(e){}try{if(window.__mfSync&&navigator.onLine)window.__mfSync.cycle();}catch(e){}}
  function ini(n){n=String(n||'').trim();return n?Array.from(n)[0].toUpperCase():'?';}
  function gate(){return $('app-login-gate');}
  function stopWait(){if(waitT){clearInterval(waitT);waitT=null;}}
  function removeReq(id){var a=read(),b=a.filter(function(r){return r&&r.id!==id;});if(b.length!==a.length)write(b);}

  /* ---------- employee device: waiting screen ---------- */
  var WK='mf_sync_loginwait';
  function saveWait(o){try{if(o)localStorage.setItem(WK,JSON.stringify(o));else localStorage.removeItem(WK);}catch(e){}}
  function show(cls,ic,title,sub){
    var g=gate();if(!g)return;g.classList.remove('mf-form','mf-rej','mf-ok');g.classList.add('mf-wait');if(cls)g.classList.add(cls);
    $('mfg-wait-ini').textContent=ic;$('mfg-wait-title').textContent=title;$('mfg-wait-sub').textContent=sub||'';
  }
  function begin(info,id,t0,onApproved){
    stopWait();cur={id:id};
    show('',ini(info.name||info.username),'چاوەڕوانی','داواکارییەکەت نێردرا بۆ ئادمین');
    $('mfg-wait-name').textContent=(info.username?'@'+info.username:'');
    var n=0,miss=0;
    waitT=setInterval(function(){
      n++;if(n%3===0){try{if(window.__mfSync&&navigator.onLine)window.__mfSync.cycle();}catch(e){}}
      var r=read().filter(function(x){return x&&x.id===id;})[0];
      if(r&&r.status==='approved'){stopWait();approved(id,onApproved);return;}
      if(r&&r.status==='rejected'){stopWait();reject(id);return;}
      if(!r){ if(++miss>=6){miss=0;var a=read();a.push({id:id,empId:info.empId,username:info.username,name:info.name,status:'pending',at:t0});write(a);} }
      else miss=0;
      if(Date.now()-t0>TTL){stopWait();removeReq(id);saveWait(null);cur=null;window.mfGateHome();}
    },1000);
  }
  window.mfLoginApprovalStart=function(emp,onApproved){
    var id='lr'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),t0=Date.now();
    var info={empId:emp.id,username:emp.username||'',name:String(emp.name||emp.username||'').trim()};
    var list=read().filter(function(r){return r&&r.empId!==emp.id&&Date.now()-r.at<TTL;});
    list.push({id:id,empId:info.empId,username:info.username,name:info.name,status:'pending',at:t0});
    write(list);
    saveWait({id:id,t0:t0,info:info});
    try{if(window.safeCreateIcons)safeCreateIcons();}catch(e){}
    begin(info,id,t0,onApproved);
  };
  function approved(id,onApproved){
    show('mf-ok','\u2713','پەسەند کرا','');
    removeReq(id);saveWait(null);cur=null;
    setTimeout(function(){var g=gate();if(g)g.classList.remove('mf-wait','mf-ok');onApproved();},1500);
  }
  function reject(id){
    show('mf-rej','\u00d7','ڕەتکرایەوە','');
    try{if(window.__mfSync&&window.__mfSync.cloud)window.__mfSync.cloud.logout();}catch(e){}
    try{['mf_admin_session','mf_employee_session','mf_login_type'].forEach(function(k){localStorage.removeItem(k);});}catch(e){}
    removeReq(id);saveWait(null);cur=null;
    setTimeout(function(){window.mfGateHome();},2600);
  }
  /* resume the waiting screen if the page reloaded while waiting */
  window.addEventListener('load',function(){setTimeout(function(){
    try{var w=JSON.parse(localStorage.getItem(WK)||'null'),g=gate();
      if(!w||!g||g.classList.contains('hidden')){saveWait(null);return;}
      if(Date.now()-w.t0>TTL){saveWait(null);return;}
      begin(w.info,w.id,w.t0,function(){var emp=(typeof mfFindEmp==='function'&&mfFindEmp(w.info.username))||null;if(!emp){window.mfGateHome();return;}window.__mfApproved=true;try{mfEmployeeLoginSuccess(emp);}finally{window.__mfApproved=false;}});
    }catch(e){}
  },900);});
  window.mfLoginWaitCancel=function(){stopWait();saveWait(null);if(cur){removeReq(cur.id);cur=null;}try{if(window.__mfSync&&window.__mfSync.cloud)window.__mfSync.cloud.logout();}catch(e){}window.mfGateHome();};

  /* ---------- admin device: notification ---------- */
  function bell(){try{var C=window.AudioContext||window.webkitAudioContext,c=new C(),t=c.currentTime;[[1046,1.4,.22],[2093,.7,.06],[3136,.4,.03]].forEach(function(p){var o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=p[0];g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(p[2],t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+p[1]);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+p[1]+.05);});setTimeout(function(){try{c.close();}catch(e){}},2000);}catch(e){}try{if(navigator.vibrate)navigator.vibrate([180,90,180]);}catch(e){}}
  function pending(){var now=Date.now();return read().filter(function(r){return r&&r.status==='pending'&&now-r.at<TTL;}).sort(function(a,b){return a.at-b.at;});}
  window.mfLoginDecide=function(status){
    if(!watchId)return;var id=watchId,a=read();
    a.forEach(function(r){if(r&&r.id===id){r.status=status;r.decidedAt=Date.now();}});
    write(a);watchId=null;$('mfa-ov').classList.remove('on');tick();
  };
  var lastShown='';
  function tick(){
    var ov=$('mfa-ov');if(!ov)return;
    var g=gate(),isAdmin=false;
    try{isAdmin=localStorage.getItem('mf_admin_session')==='1';}catch(e){}
    if(!isAdmin||(g&&!g.classList.contains('hidden'))){ov.classList.remove('on');watchId=null;return;}
    var now=Date.now(),all=read(),keep=all.filter(function(r){return r&&((r.status==='pending'&&now-r.at<TTL)||(r.status!=='pending'&&now-(r.decidedAt||r.at)<120000));});
    if(keep.length!==all.length)write(keep);
    var p=pending();
    if(!p.length){ov.classList.remove('on');watchId=null;return;}
    var r=p[0];
    $('mfa-ini').textContent=ini(r.name||r.username);
    $('mfa-name').textContent=r.name||r.username||'';
    $('mfa-user').textContent=r.username?'@'+r.username:'';
    var c=$('mfa-cnt');c.style.display=p.length>1?'flex':'none';c.textContent=p.length;
    if(watchId!==r.id){watchId=r.id;if(lastShown!==r.id){lastShown=r.id;bell();
      try{if(document.hidden&&window.Notification&&Notification.permission==='granted')new Notification(r.name||r.username||'',{body:'ئەو ئەکاونتە هەوڵی هاتنە ژوورەوە دەدات بۆ ناو سیستەم'});}catch(e){}}}
    ov.classList.add('on');
  }
  setInterval(tick,1500);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)tick();});
})();
