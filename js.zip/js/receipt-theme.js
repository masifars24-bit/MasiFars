(function(){
  var root=document.documentElement, lastKey='';
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function parseColor(v){
    try{
      var el=document.createElement('span'); el.style.color=''; el.style.color=v;
      if(!el.style.color) return null;
      el.style.display='none'; document.body.appendChild(el);
      var m=getComputedStyle(el).color.match(/[\d.]+/g); document.body.removeChild(el);
      return m?[+m[0],+m[1],+m[2]]:null;
    }catch(e){return null;}
  }
  function rgb2hsl(r,g,b){
    r/=255;g/=255;b/=255;var mx=Math.max(r,g,b),mn=Math.min(r,g,b),h=0,s=0,l=(mx+mn)/2,d=mx-mn;
    if(d){s=l>.5?d/(2-mx-mn):d/(mx+mn);
      h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}
    return [h,s*100,l*100];
  }
  function hsl(h,s,l){
    h=((h%360)+360)%360;s=clamp(s,0,100)/100;l=clamp(l,0,100)/100;
    var a=s*Math.min(l,1-l);
    function f(n){var k=(n+h/30)%12,c=l-a*Math.max(-1,Math.min(k-3,9-k,1));return Math.round(c*255).toString(16).padStart(2,'0');}
    return '#'+f(0)+f(8)+f(4);
  }
  function build(){
    var cs=getComputedStyle(root);
    var c1=cs.getPropertyValue('--c-1').trim(), c2=cs.getPropertyValue('--receipt-accent-2').trim()||cs.getPropertyValue('--c-2').trim();
    var key=c1+'|'+c2; if(key===lastKey) return; lastKey=key;
    var p1=parseColor(c1)||[79,70,229], p2=parseColor(c2)||p1;
    var a=rgb2hsl(p1[0],p1[1],p1[2]), b=rgb2hsl(p2[0],p2[1],p2[2]);
    var h=a[0], s=clamp(a[1],10,85), cap=function(v){return clamp(v,0,100);};
    var h1=h, h2=b[0], dh=((h2-h1+540)%360)-180, h3=h1+dh/2, ts=clamp(a[1],10,80);
    var v={};
    v['page']=hsl(h,cap(s+15),96.5); v['ink']=hsl(h,s,24); v['lab']=hsl(h,s*.9,30); v['sub']=hsl(h,Math.max(s*.4,10),46);
    v['line']=hsl(h,cap(s+10),91.5); v['soft']=hsl(h,cap(s+15),97.5); v['chip']=hsl(h,cap(s+15),93); v['chipt']=hsl(h,s,34);
    v['acc']=hsl(h,s,36); v['th1']=hsl(h,cap(s+15),96); v['th2']=hsl(h,cap(s+15),92); v['thb']=hsl(h,cap(s+10),88);
    v['dash']=hsl(h,s*.8,78); v['cchip']=hsl(h,cap(s+10),90); v['cchipt']=hsl(h,s,34);
    [h1,h2,h3].forEach(function(ht,i){var n='t'+(i+1);
      v[n+'-bg']=hsl(ht,ts,94); v[n+'-bd']=hsl(ht,ts*.85,87); v[n+'-ink']=hsl(ht,ts,28); v[n+'-ic']=hsl(ht,ts,40);});
    v['d-page']=hsl(h,s*.6,9); v['d-card']=hsl(h,s*.5,14); v['d-ink']=hsl(h,60,95); v['d-lab']=hsl(h,55,86); v['d-sub']=hsl(h,25,68);
    v['d-line']=hsl(h,s*.5,23); v['d-soft']=hsl(h,s*.5,18); v['d-chip']=hsl(h,s*.6,26); v['d-chipt']=hsl(h,85,84);
    v['d-acc']=hsl(h,90,78); v['d-th1']=hsl(h,s*.5,22); v['d-th2']=hsl(h,s*.5,22); v['d-thb']=hsl(h,s*.5,30);
    v['d-dash']=hsl(h,s*.4,38); v['d-cchip']=hsl(h,s*.7,30); v['d-cchipt']=hsl(h,90,86);
    [h1,h2,h3].forEach(function(ht,i){var n='d-t'+(i+1);
      v[n+'-bg']=hsl(ht,ts*.6,19); v[n+'-bd']=hsl(ht,ts*.55,30); v[n+'-ink']=hsl(ht,85,78); v[n+'-ic']=hsl(ht,80,72);});
    for(var k in v) root.style.setProperty('--rt-'+k,v[k]);
  }
  function init(){
    build();
    try{new MutationObserver(build).observe(root,{attributes:true,attributeFilter:['style']});}catch(e){}
  }
  if(document.body) init(); else document.addEventListener('DOMContentLoaded',init);
})();
