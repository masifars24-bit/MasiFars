(function(){
  'use strict';
  var QUOTA = 5 * 1024 * 1024; // characters; browsers allow roughly this much, so every number here is an estimate
  var NAMES = { mf_slider_images: 'وێنەی سلاید', mf_employees: 'کارمەندان', mf_admin_account: 'هەژماری ئادمین', mf_notebook_data: 'داتای دەفتەر', mf_notebook_pages: 'پەڕەکانی دەفتەر', mf_purchase_profiles: 'پڕۆفایلی کڕین', mf_daily_expenses: 'خەرجی ڕۆژانە' };
  function ls(){ try { return window.localStorage; } catch (e) { return null; } }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function fmt(n){ return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function isQuota(e){ return !!e && (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED' || e.code === 22 || e.code === 1014 || /quota/i.test(String(e.message || ''))); }

  function usage(){
    var s = ls(), total = 0, items = [];
    if (!s) return { total: 0, items: items };
    for (var i = 0; i < s.length; i++) {
      var k = s.key(i); if (k == null) continue;
      var v = ''; try { v = s.getItem(k) || ''; } catch (e) {}
      var n = k.length + v.length; total += n; items.push({ k: k, n: n });
    }
    items.sort(function(a, b){ return b.n - a.n; });
    return { total: total, items: items };
  }

  // ---- 2. safe write: a full storage is announced clearly, never swallowed silently ----
  var lastQ = 0;
  function notifyFull(){
    var now = Date.now(); if (now - lastQ < 8000) return; lastQ = now;
    var msg = 'ئەم گۆڕانکارییە پاشەکەوت نەکرا، چونکە شوێنی پاشەکەوتکردنی ئامێرەکە پڕ بووە.\nبۆ چارەسەر: پانێڵی «گونجاندن لەگەڵ سێرڤەر» بکەرەوە، لە بەشی «شوێنی پاشەکەوتکردن» وێنەکان بچووک بکەرەوە، یان باکئەپ بگرە و داتای کۆن پاک بکەرەوە.';
    try { window.mfDialog.alert(msg, { title: 'شوێنی پاشەکەوتکردن پڕە', type: 'err' }); } catch (e) { try { alert(msg); } catch (_) {} }
  }
  var proto = Storage.prototype, prevSet = proto.setItem;
  proto.setItem = function(k, v){
    try { return prevSet.call(this, k, v); }
    catch (e) {
      if (isQuota(e)) { try { if (this === window.localStorage) notifyFull(); } catch (_) {} }
      throw e; // callers keep their own error handling; nothing is hidden
    }
  };

  // ---- 3a. early warning toast at 85% ----
  function toast(msg){
    var t = document.getElementById('mfsg-toast');
    if (!t) { t = document.createElement('div'); t.id = 'mfsg-toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('show'); clearTimeout(t._h);
    t._h = setTimeout(function(){ t.classList.remove('show'); }, 9000);
    t.onclick = function(){ t.classList.remove('show'); };
  }
  var warned = false;
  function check(){
    if (warned) return;
    var p = usage().total / QUOTA;
    if (p >= 0.85) { warned = true; toast('شوێنی پاشەکەوتکردن نزیکە لە پڕبوون (' + Math.round(p * 100) + '%). لە پانێڵی گونجاندن لەگەڵ سێرڤەر، وێنەکان بچووک بکەرەوە.'); }
  }
  setTimeout(check, 4000); setInterval(check, 5 * 60 * 1000);

  // ---- 4. persistent storage ----
  function persistSupported(){ return !!(navigator.storage && navigator.storage.persist && navigator.storage.persisted); }
  function askPersist(){
    if (!persistSupported()) return Promise.resolve(null);
    return navigator.storage.persisted().then(function(p){ return p ? true : navigator.storage.persist(); }).catch(function(){ return false; });
  }
  var asked = false;
  function onFirstTouch(){ if (asked) return; asked = true; document.removeEventListener('pointerdown', onFirstTouch, true); askPersist(); }
  document.addEventListener('pointerdown', onFirstTouch, true);

  // ---- 1b. shrink images that are already stored ----
  var MINLEN = 150000;
  function loadImg(src){ return new Promise(function(res, rej){ var im = new Image(); im.onload = function(){ res(im); }; im.onerror = function(){ rej(new Error('img')); }; im.src = src; }); }
  function shrinkOne(src){
    var m = /^data:(image\/(?:jpeg|png|webp));base64,/.exec(src);
    if (!m || src.length < MINLEN || typeof window.mfEncodeImage !== 'function') return Promise.resolve(null);
    return loadImg(src).then(function(im){
      var r = window.mfEncodeImage(im, m[1]);
      return (r && r.data && r.data.length < src.length * 0.8) ? r.data : null;
    }).catch(function(){ return null; });
  }
  function collect(node, parent, key, out){
    if (typeof node === 'string') { if (node.length >= MINLEN && node.indexOf('data:image/') === 0) out.push({ p: parent, k: key }); return; }
    if (node && typeof node === 'object') Object.keys(node).forEach(function(k){ collect(node[k], node, k, out); });
  }
  window.mfShrinkStoredImages = function(onProgress){
    var s = ls(), jobs = [], total = 0, i;
    if (!s) return Promise.resolve({ saved: 0, changed: 0, total: 0 });
    var keys = [];
    for (i = 0; i < s.length; i++) {
      var k = s.key(i);
      if (k && k.indexOf('mf_') === 0 && k.indexOf('mf_sync_') !== 0 && k.indexOf('mf_login_fails_') !== 0 && k.indexOf('_corrupt_backup_') < 0) keys.push(k);
    }
    keys.forEach(function(k){
      var raw = s.getItem(k); if (!raw || raw.length < MINLEN) return;
      if (raw.indexOf('data:image/') === 0) { var h = { v: raw }; jobs.push({ key: k, raw: raw, root: h, holders: [{ p: h, k: 'v' }], plain: true }); total++; return; }
      var obj; try { obj = JSON.parse(raw); } catch (e) { return; }
      var holders = []; collect(obj, null, null, holders);
      if (holders.length) { jobs.push({ key: k, raw: raw, root: obj, holders: holders, plain: false }); total += holders.length; }
    });
    var done = 0, saved = 0, changed = 0;
    function runJob(idx){
      if (idx >= jobs.length) return Promise.resolve();
      var j = jobs[idx], any = false;
      function runHolder(n){
        if (n >= j.holders.length) return Promise.resolve();
        var h = j.holders[n];
        return shrinkOne(h.p[h.k]).then(function(d){
          if (d) { h.p[h.k] = d; any = true; }
          done++; if (typeof onProgress === 'function') { try { onProgress(done, total); } catch (e) {} }
        }).then(function(){ return runHolder(n + 1); });
      }
      return runHolder(0).then(function(){
        if (any) {
          var nr = j.plain ? j.root.v : JSON.stringify(j.root);
          if (nr.length < j.raw.length) { try { s.setItem(j.key, nr); saved += (j.raw.length - nr.length); changed++; } catch (e) {} }
        }
        return runJob(idx + 1);
      });
    }
    return runJob(0).then(function(){ return { saved: saved, changed: changed, total: total }; });
  };

  // ---- 3b. the storage card shown inside the sync panel ----
  function draw(root){
    var u = usage(), p = Math.min(1, u.total / QUOTA), pct = Math.round(p * 100);
    var lv = pct >= 90 ? '#ef4444' : (pct >= 70 ? '#f59e0b' : '#10b981');
    var msg = pct >= 90 ? 'زۆر نزیکە لە پڕبوون، پێویستە کەمی بکەیتەوە' : (pct >= 70 ? 'نزیک دەبێتەوە لە پڕبوون' : 'شوێن بەشە');
    var rows = u.items.slice(0, 3).map(function(it){
      var nm = NAMES[it.k] ? esc(NAMES[it.k]) : '<bdi dir="ltr">' + esc(it.k) + '</bdi>';
      return '<div class="mfsg-row"><span>' + nm + '</span><b>' + fmt(it.n) + '</b></div>';
    }).join('');
    root.style.setProperty('--lv', lv);
    root.innerHTML =
      '<div class="mfsg-top"><b>' + fmt(u.total) + '</b><span>لە نزیکەی ' + fmt(QUOTA) + '</span><em>' + pct + '%</em></div>' +
      '<div class="mfsg-bar"><i style="width:' + pct + '%"></i></div>' +
      '<div class="mfsg-msg">' + msg + '</div>' +
      (rows ? '<div class="mfsg-rows">' + rows + '</div>' : '') +
      '<button type="button" class="mfsg-btn" style="--bc:#4f46e5" data-a="shrink">بچووککردنەوەی وێنە گەورەکان</button>' +
      '<div class="mfsg-pst" data-r="pst"></div>';
    paintPersist(root);
  }
  function paintPersist(root){
    var box = root.querySelector('[data-r="pst"]'); if (!box) return;
    if (!persistSupported()) { box.innerHTML = '<b>پاراستنی هەمیشەیی:</b> لەم شێوازی کردنەوەیە پشتگیری ناکرێت (پێویستە ئەپەکە لە لینکێکی HTTPS بکرێتەوە).'; return; }
    navigator.storage.persisted().then(function(ok){
      if (ok) { box.innerHTML = '<b>پاراستنی هەمیشەیی:</b> چالاکە، وێبگەڕ داتاکە خۆکار ناسڕێتەوە.'; return; }
      box.innerHTML = '<b>پاراستنی هەمیشەیی:</b> چالاک نییە، واتە وێبگەڕ لەوانەیە لە کاتی کەمبوونی شوێن داتاکە بسڕێتەوە.<button type="button" class="mfsg-btn" style="--bc:#0ea5e9" data-a="persist">داواکردنی پاراستن</button>';
    }).catch(function(){ box.textContent = ''; });
  }
  function doShrink(root, btn){
    window.mfDialog.confirm('وێنە گەورەکانی ناو ئەپەکە بچووک دەکرێنەوە. کوالیتییەکەیان کەمێک دادەبەزێت، بەڵام بە چاو زۆر جیاواز نابێت.\nباشترە پێشتر باکئەپێک هەڵبگریت.',
      { title: 'بچووککردنەوەی وێنەکان', type: 'warn', ok: 'دەستپێبکە', cancel: 'پاشگەزبوونەوە' }).then(function(yes){
      if (!yes) return;
      btn.disabled = true; btn.textContent = 'چاوەڕێ بکە...';
      window.mfShrinkStoredImages(function(d, t){ btn.textContent = 'چاوەڕێ بکە (' + d + '/' + t + ')'; }).then(function(r){
        var msg = r.total === 0 ? 'هیچ وێنەیەکی گەورە نەدۆزرایەوە.' : (r.changed === 0 ? 'وێنەکان پێشتر بچووکن و شتێک نەگۆڕدرا.' : fmt(r.saved) + ' شوێن ئازاد کرا.');
        window.mfDialog.alert(msg, { title: 'تەواو بوو', type: 'info' });
        draw(root);
      }).catch(function(){ window.mfDialog.alert('کێشەیەک ڕوویدا و پرۆسەکە تەواو نەبوو.', { title: 'هەڵە', type: 'err' }); draw(root); });
    });
  }
  window.mfStorageCard = function(){
    var root = document.createElement('div'); root.className = 'mfsg-card';
    root.addEventListener('click', function(e){
      var b = e.target && e.target.closest ? e.target.closest('[data-a]') : null; if (!b) return;
      var a = b.getAttribute('data-a');
      if (a === 'shrink') doShrink(root, b);
      else if (a === 'persist') { b.disabled = true; askPersist().then(function(ok){ paintPersist(root); if (!ok) window.mfDialog.alert('وێبگەڕ ڕێگەی نەدا. ئەگەر ئەپەکە لە Home Screen دابنێیت یان وەک ئەپ دایبمەزرێنیت، زۆرجار ڕێگە دەدرێت.', { title: 'نەکرا', type: 'info' }); }); }
    });
    draw(root); return root;
  };
})();
