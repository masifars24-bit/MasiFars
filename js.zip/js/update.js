    (function () {
      var BUILD = (document.querySelector('meta[name="mf-build"]') || {}).content || '';
      var META_BUILD = BUILD;   /* وەشانی ئەو فایلەی ئێستا کار دەکات */
      var reg = null, applying = false, reloaded = false, lastUp = 0, snoozeUntil = 0, pendingAuto = true, startT = Date.now(), ov = null, opening = false;

      /* ───────── شێوازی ئاگادارکردنەوە (هاوتای ستایلی ئەپەکە) ───────── */
      var css = document.createElement('style'); css.id = 'mfu-css';
      css.textContent = "#mfu-ov{position:fixed;inset:0;z-index:2147483200;display:flex;align-items:flex-end;justify-content:center;padding:12px;padding-bottom:calc(12px + env(safe-area-inset-bottom,0px));background:rgba(6,8,26,.62);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);opacity:0;transition:opacity .3s;direction:rtl;font-family:var(--main-font,\"Vazirmatn\",sans-serif)}#mfu-ov.on{opacity:1}#mfu-card{position:relative;width:100%;max-width:440px;max-height:90vh;display:flex;flex-direction:column;border-radius:32px;background:var(--surface,#fff);color:var(--text-main,#18181b);box-shadow:0 30px 80px rgba(0,0,0,.5),0 0 0 1px rgba(255,255,255,.08);overflow:hidden;transform:translateY(60px) scale(.97);transition:transform .5s cubic-bezier(.2,.9,.25,1.12)}#mfu-ov.on #mfu-card{transform:none}.mfu-hero{position:relative;flex:0 0 auto;padding:24px 22px 20px;text-align:center;color:#fff;overflow:hidden;background:linear-gradient(135deg,var(--c-1,#4f46e5),var(--c-2,#06b6d4))}.mfu-hero::before,.mfu-hero::after{content:\"\";position:absolute;border-radius:50%;filter:blur(34px);animation:mfuBlob 9s ease-in-out infinite}.mfu-hero::before{width:210px;height:210px;background:#fff;top:-95px;right:-50px;opacity:.3}.mfu-hero::after{width:190px;height:190px;background:#22d3ee;bottom:-95px;left:-40px;opacity:.5;animation-delay:-4s}@keyframes mfuBlob{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(26px,18px) scale(1.18)}}.mfu-sp{position:absolute;border-radius:50%;background:#fff;opacity:0;animation:mfuTw 3s ease-in-out infinite}@keyframes mfuTw{0%,100%{opacity:0;transform:scale(.4)}50%{opacity:.95;transform:scale(1)}}.mfu-logo{position:relative;z-index:1;width:80px;height:80px;margin:4px auto 24px}.mfu-logo::before,.mfu-logo::after{content:\"\";position:absolute;inset:-8px;border-radius:34px;border:2px solid rgba(255,255,255,.6);animation:mfuRing 2.4s ease-out infinite}.mfu-logo::after{animation-delay:1.2s}@keyframes mfuRing{0%{transform:scale(.88);opacity:.9}100%{transform:scale(1.4);opacity:0}}.mfu-logo-in{position:relative;z-index:1;width:80px;height:80px;border-radius:26px;background:#fff;display:grid;place-items:center;overflow:hidden;box-shadow:0 16px 36px rgba(0,0,0,.32);animation:mfuFloat 3.2s ease-in-out infinite}.mfu-logo-in img{width:100%;height:100%;object-fit:cover}.mfu-logo-in svg{width:42px;height:42px;color:var(--c-1,#4f46e5)}@keyframes mfuFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}.mfu-hero>*{position:relative;z-index:1}.mfu-badge{display:inline-block;margin-bottom:8px;padding:4px 14px;border-radius:99px;background:rgba(255,255,255,.22);border:1px solid rgba(255,255,255,.38);font:900 11.5px/1.5 var(--main-font,sans-serif);letter-spacing:.5px}.mfu-h{font:900 22px/1.35 var(--main-font,sans-serif);margin:0;text-shadow:0 2px 14px rgba(0,0,0,.25)}.mfu-bigv{direction:ltr;display:block;font:900 36px/1.15 var(--main-font,sans-serif);letter-spacing:1px;margin:4px 0 10px;text-shadow:0 4px 24px rgba(0,0,0,.3)}.mfu-from{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:99px;background:rgba(0,0,0,.2);font:700 12px var(--main-font,sans-serif)}.mfu-from b{direction:ltr;font-weight:900}.mfu-body{padding:14px 18px 4px;overflow:auto;-webkit-overflow-scrolling:touch;flex:1 1 auto;min-height:0}.mfu-sub{text-align:center;font:800 14px/1.6 var(--main-font,sans-serif);color:var(--text-main,#18181b);margin:0 0 6px}.mfu-rh{display:flex;align-items:center;gap:8px;margin:12px 0 4px;font:700 12.5px var(--main-font,sans-serif);color:var(--text-sub,#71717a)}.mfu-rh b{direction:ltr;color:var(--c-1,#4f46e5);font-weight:900}.mfu-g{margin:10px 0;border-radius:20px;padding:12px 14px 8px;background:linear-gradient(160deg,color-mix(in srgb,var(--gc) 13%,transparent),color-mix(in srgb,var(--gc) 5%,transparent));border:1px solid color-mix(in srgb,var(--gc) 28%,transparent);opacity:0;transform:translateY(16px);animation:mfuIn .55s cubic-bezier(.2,.8,.25,1) forwards;animation-delay:calc(var(--i,0) * .09s + .3s)}@keyframes mfuIn{to{opacity:1;transform:none}}.mfu-added{--gc:#16a34a}.mfu-fixed{--gc:#f59e0b}.mfu-changed{--gc:#3b82f6}.mfu-gh{display:flex;align-items:center;gap:10px;font:900 14px var(--main-font,sans-serif);color:var(--gc);margin-bottom:6px}.mfu-gi{width:30px;height:30px;border-radius:11px;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--gc),color-mix(in srgb,var(--gc) 65%,#fff));box-shadow:0 6px 14px color-mix(in srgb,var(--gc) 40%,transparent)}.mfu-gi svg{width:16px;height:16px}.mfu-gh em{margin-inline-start:auto;font:800 11.5px var(--main-font,sans-serif);font-style:normal;padding:3px 10px;border-radius:99px;background:color-mix(in srgb,var(--gc) 18%,transparent)}.mfu-g ul{list-style:none;margin:0;padding:0}.mfu-g li{position:relative;padding:7px 22px 7px 0;font:600 13.5px/1.75 var(--main-font,sans-serif);color:var(--text-main,#18181b)}.mfu-g li::before{content:\"\";position:absolute;right:3px;top:17px;width:8px;height:8px;border-radius:50%;background:var(--gc);box-shadow:0 0 0 4px color-mix(in srgb,var(--gc) 20%,transparent)}.mfu-empty{padding:18px 8px;text-align:center;font:600 13.5px/1.8 var(--main-font,sans-serif);color:var(--text-sub,#71717a)}.mfu-foot{padding:10px 18px 16px;flex:0 0 auto}.mfu-safe{display:flex;align-items:center;gap:9px;margin-bottom:12px;padding:9px 12px;border-radius:14px;background:color-mix(in srgb,#16a34a 10%,transparent);color:var(--text-sub,#71717a);font:600 12px/1.6 var(--main-font,sans-serif)}.mfu-safe svg{width:18px;height:18px;flex:none;color:#16a34a}.mfu-b1{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;gap:10px;width:100%;border:0;border-radius:20px;padding:16px;color:#fff;cursor:pointer;font:900 16px var(--main-font,sans-serif);background:linear-gradient(135deg,var(--c-1,#4f46e5),var(--c-2,#06b6d4));box-shadow:0 14px 30px color-mix(in srgb,var(--c-1,#4f46e5) 45%,transparent);-webkit-tap-highlight-color:transparent}.mfu-b1 svg{width:21px;height:21px}.mfu-b1::after{content:\"\";position:absolute;top:0;bottom:0;width:70px;left:-90px;background:linear-gradient(100deg,transparent,rgba(255,255,255,.5),transparent);transform:skewX(-20deg);animation:mfuSh 2.8s ease-in-out infinite}@keyframes mfuSh{0%{left:-90px}60%,100%{left:120%}}.mfu-b1:active{transform:scale(.98)}.mfu-b2{display:block;width:100%;border:0;background:none;padding:12px;margin-top:2px;color:var(--text-sub,#71717a);cursor:pointer;font:800 14px var(--main-font,sans-serif)}.mfu-pv{position:relative;padding:34px 22px 26px;text-align:center;overflow:hidden}.mfu-pv::before{content:\"\";position:absolute;inset:0;background:radial-gradient(90% 55% at 50% 0%,color-mix(in srgb,var(--c-1,#4f46e5) 24%,transparent),transparent 72%);pointer-events:none}.mfu-pv>*{position:relative}.mfu-ringw{position:relative;width:172px;height:172px;margin:0 auto 16px}.mfu-ringw svg.mfu-rs{width:100%;height:100%;transform:rotate(-90deg)}.mfu-trk{fill:none;stroke:color-mix(in srgb,var(--text-sub,#71717a) 20%,transparent);stroke-width:10}.mfu-arc{fill:none;stroke:url(#mfuGrad);stroke-width:10;stroke-linecap:round;stroke-dasharray:439.8;stroke-dashoffset:439.8;filter:drop-shadow(0 0 8px color-mix(in srgb,var(--c-1,#4f46e5) 60%,transparent))}.mfu-pct{position:absolute;inset:0;display:flex;align-items:baseline;justify-content:center;padding-top:62px;box-sizing:border-box;font:900 40px var(--main-font,sans-serif);direction:ltr}.mfu-pct small{font-size:18px;opacity:.65;margin-inline-start:2px}.mfu-chk{position:absolute;inset:0;display:none;place-items:center;color:#16a34a}.mfu-chk svg{width:76px;height:76px}.mfu-chk path{stroke-dasharray:30;stroke-dashoffset:30;animation:mfuDraw .6s .1s ease-out forwards}@keyframes mfuDraw{to{stroke-dashoffset:0}}.mfu-pt{font:900 19px/1.5 var(--main-font,sans-serif)}.mfu-ps{margin-top:2px;font:600 12.5px/1.7 var(--main-font,sans-serif);color:var(--text-sub,#71717a)}.mfu-st{list-style:none;margin:18px 0 0;padding:0;text-align:right}.mfu-st li{display:flex;align-items:center;gap:12px;padding:9px 12px;border-radius:14px;font:700 13.5px var(--main-font,sans-serif);color:var(--text-sub,#71717a);transition:background .3s,color .3s}.mfu-st li i{flex:none;width:24px;height:24px;border-radius:50%;display:grid;place-items:center;background:color-mix(in srgb,var(--text-sub,#71717a) 18%,transparent);box-sizing:border-box}.mfu-st li i svg{width:13px;height:13px;display:none}.mfu-st li.act{color:var(--text-main,#18181b);background:color-mix(in srgb,var(--c-1,#4f46e5) 10%,transparent)}.mfu-st li.act i{background:none;border:2.5px solid var(--c-1,#4f46e5);border-top-color:transparent;animation:mfuSpin .8s linear infinite}.mfu-st li.ok{color:var(--text-main,#18181b)}.mfu-st li.ok i{background:#16a34a;color:#fff}.mfu-st li.ok i svg{display:block}@keyframes mfuSpin{to{transform:rotate(360deg)}}.mfu-pv.done .mfu-arc{stroke:#16a34a;filter:drop-shadow(0 0 10px rgba(22,163,74,.6))}.mfu-pv.done .mfu-pct{display:none}.mfu-pv.done .mfu-chk{display:grid}.mfu-cf{position:absolute;top:120px;left:50%;width:8px;height:13px;border-radius:2px;opacity:0;animation:mfuCf 1.5s ease-out forwards}@keyframes mfuCf{0%{opacity:1;transform:translate(0,0) rotate(0)}100%{opacity:0;transform:translate(var(--dx),var(--dy)) rotate(var(--r))}}body.mfu-has-update #mf-refresh-btn{position:relative}body.mfu-has-update #mf-refresh-btn::after{content:\"\";position:absolute;top:3px;right:3px;width:11px;height:11px;border-radius:50%;background:#ef4444;border:2px solid var(--surface,#fff);animation:mfuP 1.6s ease-in-out infinite}@keyframes mfuP{0%,100%{transform:scale(1)}50%{transform:scale(1.3)}}";
      (document.head || document.documentElement).appendChild(css);

      var SV = function (p) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' + p + '</svg>'; };
      var ICON = {
        dl: SV('<path d="M4.393 15.269A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.436 8.284"/><path d="M12 13v8"/><path d="m8 17 4 4 4-4"/>'),
        plus: SV('<path d="M12 5v14"/><path d="M5 12h14"/>'),
        ok: SV('<path d="M20 6 9 17l-5-5"/>'),
        rot: SV('<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>'),
        shield: SV('<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>')
      };
      function h(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }

      function closeModal() { if (ov && ov.parentNode) ov.parentNode.removeChild(ov); ov = null; }
      function later() {
        if (applying) return;
        snoozeUntil = Date.now() + 3 * 3600 * 1000;
        if (ov) { var o = ov; o.classList.remove('on'); setTimeout(function () { if (o.parentNode) o.parentNode.removeChild(o); if (ov === o) ov = null; }, 260); }
      }

      var STEPS = ['پشکنینی وەشانی نوێ', 'دابەزاندنی فایلەکان', 'ئامادەکردنی ئەپەکە', 'دامەزراندن'];
      function mkOverlay() {
        ov = h('div'); ov.id = 'mfu-ov'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-modal', 'true'); ov.dir = 'rtl';
        var card = h('div'); card.id = 'mfu-card'; ov.appendChild(card);
        ov.addEventListener('click', function (e) { if (e.target === ov) later(); });
        document.body.appendChild(ov);
        requestAnimationFrame(function () { requestAnimationFrame(function () { if (ov) ov.classList.add('on'); }); });
        return card;
      }

      function buildModal(releases) {
        closeModal();
        var card = mkOverlay();
        var top = releases[0] || {};

        var hero = h('div', 'mfu-hero');
        for (var k = 0; k < 8; k++) {
          var sp = h('i', 'mfu-sp'), sz = (3 + Math.random() * 4).toFixed(1);
          sp.style.cssText = 'top:' + (6 + Math.random() * 84).toFixed(0) + '%;left:' + (5 + Math.random() * 90).toFixed(0) + '%;width:' + sz + 'px;height:' + sz + 'px;animation-delay:' + (Math.random() * 3).toFixed(2) + 's';
          hero.appendChild(sp);
        }
        var lg = h('div', 'mfu-logo'), li = h('div', 'mfu-logo-in');
        var img = new Image(); img.alt = ''; img.onerror = function () { li.innerHTML = ICON.dl; };
        img.src = 'icon-192.png'; li.appendChild(img); lg.appendChild(li); hero.appendChild(lg);
        hero.appendChild(h('div', 'mfu-badge', '✦ نوێ ✦'));
        hero.appendChild(h('div', 'mfu-h', 'وەشانی نوێ ئامادەیە'));
        if (top.ver) hero.appendChild(h('span', 'mfu-bigv', top.ver));
        if (BUILD) { var fr = h('div', 'mfu-from'); fr.appendChild(h('span', null, 'وەشانی ئێستات')); fr.appendChild(h('b', null, BUILD)); hero.appendChild(fr); }
        card.appendChild(hero);

        var body = h('div', 'mfu-body'), any = false, multi = releases.length > 1, gi = 0;
        releases.forEach(function (r) {
          if (multi) { var rh = h('div', 'mfu-rh'); rh.appendChild(h('b', null, r.ver || '')); if (r.title) rh.appendChild(h('span', null, r.title)); body.appendChild(rh); }
          else if (r.title) body.appendChild(h('div', 'mfu-sub', r.title));
          [['added', 'زیادکراوە', 'plus'], ['fixed', 'چاککراوە', 'ok'], ['changed', 'گۆڕدراوە', 'rot']].forEach(function (g) {
            var items = r[g[0]]; if (!items || !items.length) return; any = true;
            var sec = h('div', 'mfu-g mfu-' + g[0]), gh = h('div', 'mfu-gh'), ic = h('span', 'mfu-gi');
            sec.style.setProperty('--i', String(gi++));
            ic.innerHTML = ICON[g[2]]; gh.appendChild(ic); gh.appendChild(h('span', null, g[1])); gh.appendChild(h('em', null, String(items.length)));
            sec.appendChild(gh);
            var ul = h('ul'); items.forEach(function (t) { ul.appendChild(h('li', null, String(t))); }); sec.appendChild(ul); body.appendChild(sec);
          });
        });
        if (!any) body.appendChild(h('div', 'mfu-empty', 'وردەکاری گۆڕانکارییەکان ئێستا بەردەست نییە، بەڵام وەشانی نوێ ئامادەیە.'));
        card.appendChild(body);

        var foot = h('div', 'mfu-foot');
        var safe = h('div', 'mfu-safe'); var si = h('span'); si.innerHTML = ICON.shield; safe.appendChild(si.firstChild);
        safe.appendChild(h('span', null, 'داتا و ڕێکخستنەکانت پارێزراون. ئەگەر «دواتر» بکەیت، بەم وەشانەی ئێستا بەردەوام دەبیت.'));
        foot.appendChild(safe);
        var b1 = h('button', 'mfu-b1'); b1.type = 'button';
        var bi = h('span'); bi.innerHTML = ICON.dl; b1.appendChild(bi.firstChild); b1.appendChild(h('span', null, 'نوێکردنەوە ئێستا'));
        b1.onclick = function () { window.mfApplyUpdate(); };
        var b2 = h('button', 'mfu-b2', 'دواتر'); b2.type = 'button'; b2.onclick = later;
        foot.appendChild(b1); foot.appendChild(b2); card.appendChild(foot);
      }

      /* شاشەی دابەزاندن و دامەزراندن */
      function progressView() {
        var card;
        if (ov) { card = ov.querySelector('#mfu-card'); card.innerHTML = ''; } else card = mkOverlay();
        var pv = h('div', 'mfu-pv');
        var rw = h('div', 'mfu-ringw');
        rw.innerHTML = '<svg class="mfu-rs" viewBox="0 0 170 170"><defs><linearGradient id="mfuGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--c-1,#4f46e5)"/><stop offset="1" style="stop-color:var(--c-2,#06b6d4)"/></linearGradient></defs><circle class="mfu-trk" cx="85" cy="85" r="70"/><circle class="mfu-arc" cx="85" cy="85" r="70"/></svg>';
        var pc = h('div', 'mfu-pct'); var pn = h('span', null, '0'); var psm = h('small', null, '%'); pc.appendChild(pn); pc.appendChild(psm); rw.appendChild(pc);
        var ck = h('div', 'mfu-chk'); ck.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>'; rw.appendChild(ck);
        pv.appendChild(rw);
        var tt = h('div', 'mfu-pt', STEPS[0] + '...'), ss = h('div', 'mfu-ps', 'تکایە ئەپەکە دامەخە');
        pv.appendChild(tt); pv.appendChild(ss);
        var ul = h('ul', 'mfu-st'), lis = [];
        STEPS.forEach(function (t) { var l = h('li'), i = h('i'); i.innerHTML = ICON.ok; l.appendChild(i); l.appendChild(h('span', null, t)); ul.appendChild(l); lis.push(l); });
        pv.appendChild(ul); card.appendChild(pv);
        var arc = rw.querySelector('.mfu-arc'), st = { pct: 0, target: 0 }, timer = null;
        function render() { arc.style.strokeDashoffset = String(439.8 * (1 - st.pct / 100)); pn.textContent = String(Math.round(st.pct)); }
        timer = setInterval(function () {
          var d = st.target - st.pct;
          if (d > 0.05) { st.pct = Math.min(st.target, st.pct + Math.max(d * 0.08, 0.3)); render(); }
        }, 60);
        return {
          stage: function (i, t) {
            lis.forEach(function (l, k) { l.className = k < i ? 'ok' : (k === i ? 'act' : ''); });
            tt.textContent = STEPS[i] + '...'; st.target = Math.max(st.target, t);
          },
          done: function () {
            clearInterval(timer); st.pct = 100; render();
            lis.forEach(function (l) { l.className = 'ok'; });
            pv.classList.add('done'); tt.textContent = 'وەشانی نوێ دامەزرا'; ss.textContent = 'ئێستا ئەپەکە دەکرێتەوە...';
            var cols = ['#16a34a', '#f59e0b', '#3b82f6', '#ec4899', '#8b5cf6', '#06b6d4'];
            for (var n = 0; n < 22; n++) {
              var c = h('i', 'mfu-cf'), a = (Math.PI * 2 * n) / 22 + Math.random() * 0.3, dist = 90 + Math.random() * 90;
              c.style.cssText = 'background:' + cols[n % cols.length] + ';--dx:' + Math.round(Math.cos(a) * dist) + 'px;--dy:' + Math.round(Math.sin(a) * dist - 20) + 'px;--r:' + Math.round(Math.random() * 540) + 'deg;animation-delay:' + (Math.random() * 0.15).toFixed(2) + 's';
              pv.appendChild(c);
            }
          }
        };
      }
      window.mfShowProgressPreview = function () {
        var u = progressView(); u.stage(0, 8);
        setTimeout(function () { u.stage(1, 52); }, 900); setTimeout(function () { u.stage(2, 80); }, 2300);
        setTimeout(function () { u.stage(3, 95); }, 3400); setTimeout(function () { u.done(); }, 4600);
      };

      function pick(list) {
        var out = [];
        for (var i = 0; i < list.length && out.length < 3; i++) { if (list[i].ver === BUILD) break; out.push(list[i]); }
        return out;
      }
      /* ئەپدێتی پانێلی سیستەم (Supabase): ver / title / notes. هەر دێڕ = یەک نوێکاری. پێشگر: + زیادکراوە · ! چاککراوە · ~ گۆڕدراوە (بێ پێشگر = گۆڕدراوە) */
      function vnum(v) { return String(v || '').replace(/[^0-9.]/g, '').split('.').map(function (x) { return parseInt(x, 10) || 0; }); }
      function isNewer(a, b) {
        if (!b) return true;
        var x = vnum(a), y = vnum(b), n = Math.max(x.length, y.length);
        for (var k = 0; k < n; k++) { var p = x[k] || 0, q = y[k] || 0; if (p !== q) return p > q; }
        return false;
      }
      function appliedKey() { try { var m = document.cookie.match(/(?:^|; )mfu_applied=([^;]*)/); return m ? decodeURIComponent(m[1]) : ''; } catch (e) { return ''; } }
      function panelU() {
        try {
          var S = window.__mfSysState && window.__mfSysState(), u = S && S.upd;
          if (!u || !u.ver || !((u.notes && u.notes.length) || u.title)) return null;
          if (!isNewer(u.ver, BUILD)) return null;                       /* هەمان وەشان یان کۆنتر = نیشان نادرێت */
          return u;
        } catch (e) {}
        return null;
      }
      function panelRelease(u) {
        var r = { ver: u.ver, title: u.title || '', added: [], fixed: [], changed: [] };
        (u.notes || []).forEach(function (n) {
          n = String(n || '').trim(); if (!n) return;
          var c = n.charAt(0);
          if (c === '+') r.added.push(n.slice(1).trim());
          else if (c === '!') r.fixed.push(n.slice(1).trim());
          else if (c === '~') r.changed.push(n.slice(1).trim());
          else r.changed.push(n);
        });
        return r;
      }
      function loadLog() {
        var pu = panelU(); if (pu) return Promise.resolve([panelRelease(pu)]);
        return new Promise(function (res) {
          var done = false, t = setTimeout(function () { if (!done) { done = true; res([]); } }, 4500);
          function fin(v) { if (done) return; done = true; clearTimeout(t); res(v); }
          try {
            fetch('changelog.json?mfv=' + Date.now(), { cache: 'no-store' })
              .then(function (r) { return r.ok ? r.json() : null; })
              .then(function (j) { fin(j && j.releases ? pick(j.releases) : []); })
              .catch(function () { fin([]); });
          } catch (e) { fin([]); }
        });
      }
      function openModal() {
        if (ov || opening) return; opening = true; pendingAuto = false;
        loadLog().then(function (rels) { opening = false; if (!ov) buildModal(rels); });
      }
      window.mfShowUpdatePreview = function (data) { buildModal(pick((data && data.releases) || [])); };

      function paintVersion() { document.querySelectorAll('[data-mf-version]').forEach(function (e) { if (e.textContent !== BUILD) e.textContent = BUILD; }); }
      window.MF_VERSION = BUILD;
      /* وەشان: یەک سەرچاوەی ڕاستی. هەمیشە نوێترین لە نێوان (meta ی فایلی ئێستا) و (لەیبڵی service worker) */
      function setBuild(v) { if (!v || v === BUILD) return; BUILD = v; window.MF_VERSION = v; paintVersion(); }
      function bestOf(a, b) { if (!a) return b || ''; if (!b) return a; return isNewer(b, a) ? b : a; }
      window.mfCurrentVersion = function () { return BUILD; };
      window.mfIsNewer = function (a, b) { return isNewer(a, b); };
      window.mfNextVersion = function () {
        var m = /^(\D*)(\d+(?:\.\d+)*)$/.exec(String(BUILD || '').trim());
        if (!m) return BUILD || '';
        var p = m[2].split('.'); p[p.length - 1] = String((parseInt(p[p.length - 1], 10) || 0) + 1);
        return m[1] + p.join('.');
      };
      /* ئەو شوێنانەی دواتر دروست دەکرێن (کارتەکان، پانێلەکان) ژمارەی وەشان وەردەگرن */
      var pvT = null;
      function schedulePaint() { if (pvT) return; pvT = setTimeout(function () { pvT = null; paintVersion(); }, 150); }
      function watchVersionNodes() {
        try {
          new MutationObserver(function (ms) {
            for (var i = 0; i < ms.length; i++) {
              var a = ms[i].addedNodes;
              for (var j = 0; j < a.length; j++) {
                var n = a[j];
                if (n.nodeType === 1 && ((n.hasAttribute && n.hasAttribute('data-mf-version')) || (n.querySelector && n.querySelector('[data-mf-version]')))) { schedulePaint(); return; }
              }
            }
          }).observe(document.documentElement, { childList: true, subtree: true });
        } catch (e) {}
      }
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { paintVersion(); watchVersionNodes(); }); else { paintVersion(); watchVersionNodes(); }

      if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;

      var pending = null, served = null, lastCk = 0;
      function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
      function hardClear() {
        var jobs = [];
        try { jobs.push(navigator.serviceWorker.getRegistrations().then(function (rs) { return Promise.all(rs.map(function (r) { return r.unregister(); })); })); } catch (e) {}
        try { if (window.caches) jobs.push(caches.keys().then(function (ks) { return Promise.all(ks.map(function (k) { return caches.delete(k); })); })); } catch (e) {}
        return Promise.all(jobs.map(function (j) { return j.catch(function () {}); }));
      }
      /* پەیوەندی لەگەڵ service worker */
      function ask(msg, ms) {
        return new Promise(function (res) {
          var w = (reg && (reg.active || reg.waiting)) || navigator.serviceWorker.controller;
          if (!w) return res(null);
          var ch = new MessageChannel(), done = false;
          var t = setTimeout(function () { if (!done) { done = true; res(null); } }, ms || 8000);
          ch.port1.onmessage = function (e) { if (done) return; done = true; clearTimeout(t); res(e.data); };
          try { w.postMessage(msg, [ch.port2]); } catch (e) { done = true; clearTimeout(t); res(null); }
        });
      }
      function applyStatus(r) {
        if (!r) return;
        if (r.ptr) {
          served = r.ptr;
          if (served.label) setBuild(bestOf(META_BUILD, served.label));   /* ئەپەکە دەزانێت ئێستا لە چ وەشانێکە */
        }
        pending = r.pending || null;
        if (pending) maybeAutoOpen(); else if (document.body) document.body.classList.remove('mfu-has-update');
      }
      var retryN = 0;
      function retryStatus() {
        if (retryN >= 4) return; retryN++;
        setTimeout(function () { refresh(false).then(function () { if (pending) retryN = 0; else retryStatus(); }); }, 15000);
      }
      function refresh(check, force, ms) {
        if (!reg) return Promise.resolve();
        var n = Date.now();
        if (check && !force && n - lastCk < 45000) return Promise.resolve();
        if (check) lastCk = n;
        return ask({ type: check ? 'CHECK' : 'STATUS' }, check ? (ms || 60000) : 5000).then(function (r) {
          applyStatus(r);
          if (check) { if (r) retryN = 0; else retryStatus(); }
        });
      }

      function maybeAutoOpen() {
        if (!pending || !document.body) return;
        document.body.classList.add('mfu-has-update');
        if (ov || opening || Date.now() < snoozeUntil || document.hidden) return;
        if (document.body.classList.contains('app-locked')) return;
        openModal();
      }

      /* بەکارهێنەر ڕازی بوو: وەشانی نوێ دابەزێنراوە، ئێستا چالاک دەکرێت و ئەپەکە نوێ دەبێتەوە */
      window.mfApplyUpdate = function () {
        if (applying) return; applying = true;
        var ui = progressView(), label = '';
        try { var pu = panelU(); if (pu) label = pu.ver || ''; } catch (e) {}
        ui.stage(0, 8);
        setTimeout(function () { if (!reloaded) { reloaded = true; location.reload(); } }, 30000);
        sleep(700).then(function () {
          ui.stage(1, 50);
          if (pending) return sleep(800);
          return refresh(true, true, 15000);
        }).then(function () {
          ui.stage(2, 78);
          if (pending) {
            return ask({ type: 'ACTIVATE', id: pending.id, label: label }, 10000).then(function (r) {
              ui.stage(3, 95);
              if (!r || !r.ok) throw new Error('activate');
              return sleep(700);
            });
          }
          return (reg ? sleep(700) : hardClear()).then(function () { ui.stage(3, 95); return sleep(500); });
        }).then(function () { ui.done(); return sleep(1300); })
          .then(function () { reloaded = true; location.reload(); })
          .catch(function () { hardClear().then(function () { reloaded = true; location.reload(); }); });
      };

      /* دووگمەی نوێکردنەوەی سەرەوە: ئەگەر وەشانی نوێ دابەزێنرابوو، پەنجەرەکە نیشان بدە */
      document.addEventListener('click', function (e) {
        var b = e.target && e.target.closest && e.target.closest('#mf-refresh-btn');
        if (b && pending) { e.preventDefault(); e.stopImmediatePropagation(); snoozeUntil = 0; openModal(); }
      }, true);

      addEventListener('load', function () {
        navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' }).then(function (r) {
          reg = r;
          return navigator.serviceWorker.ready;
        }).then(function () {
          refresh(false).then(function () { return refresh(true, true); });
          document.addEventListener('visibilitychange', function () { if (!document.hidden) { refresh(true); pendingAuto = true; maybeAutoOpen(); } });
          addEventListener('online', function () { refresh(true, true); });
          setInterval(function () { refresh(true); }, 5 * 60 * 1000);
          setInterval(function () { if (pendingAuto && !ov) maybeAutoOpen(); }, 4000);
        }).catch(function () {});
      });
    })();
