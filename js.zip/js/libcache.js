(function(){
  var LIBS={
    lucide:{urls:['https://unpkg.com/lucide@0.468.0','https://cdn.jsdelivr.net/npm/lucide@0.468.0'],ok:function(){return !!window.lucide;},done:function(){try{if(typeof safeCreateIcons==='function')safeCreateIcons();else if(window.lucide)lucide.createIcons();}catch(e){}}},
    qr:{urls:['https://unpkg.com/qrcode-generator@1.4.4/qrcode.js','https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.js'],ok:function(){return typeof window.qrcode!=='undefined';},done:function(){}}
  };
  function db(){return new Promise(function(res,rej){try{var r=indexedDB.open('mf_libs',1);r.onupgradeneeded=function(){r.result.createObjectStore('l');};r.onsuccess=function(){res(r.result);};r.onerror=function(){rej(r.error);};}catch(e){rej(e);}});}
  function idbGet(k){return db().then(function(d){return new Promise(function(res,rej){var q=d.transaction('l').objectStore('l').get(k);q.onsuccess=function(){res(q.result);};q.onerror=function(){rej(q.error);};});});}
  function idbPut(k,v){return db().then(function(d){return new Promise(function(res,rej){var t=d.transaction('l','readwrite');t.objectStore('l').put(v,k);t.oncomplete=res;t.onerror=function(){rej(t.error);};});});}
  function load(id){
    var L=LIBS[id]; if(!L||L.ok()) return;
    idbGet(id).then(function(src){
      if(!src||L.ok()) return;
      var s=document.createElement('script'); s.text=src; document.head.appendChild(s); L.done();
    }).catch(function(){});
  }
  function cache(id){
    var L=LIBS[id]; if(!L.ok()||!navigator.onLine) return;
    idbGet(id).then(function(old){ if(old) return; return L.urls.reduce(function(p,u){return p.catch(function(){return fetch(u).then(function(r){if(!r.ok)throw 0;return r.text();});});},Promise.reject()).then(function(t){if(t&&t.length>2000)return idbPut(id,t);});}).catch(function(){});
  }
  window.__mfLib={load:load};
  addEventListener('load',function(){ setTimeout(function(){ Object.keys(LIBS).forEach(function(id){ if(LIBS[id].ok()) cache(id); else load(id); }); },1500); });
})();
