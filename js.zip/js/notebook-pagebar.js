function nbRenderPageBar() {
    if (typeof notebookState === 'undefined') return;
    var cur = notebookState.currentPage, total = nbTotalPages(), saved = nbIsPageSaved(cur);
    var win = document.querySelector('#popup-notebook .notebook-window');
    if (win) { win.classList.toggle('nb-is-saved', saved); win.classList.toggle('nb-is-unsaved', !saved); }
    var badge = document.getElementById('nbc-page');
    if (badge) {
        badge.className = 'nbc-page ' + (saved ? 'saved' : 'unsaved');
        badge.title = saved ? 'پەڕەی ' + cur + ' سەیڤکراوە و قفڵکراوە' : 'پەڕەی ' + cur + ' هێشتا سەیڤ نەکراوە';
        badge.innerHTML = '<i data-lucide="' + (saved ? 'lock-keyhole' : 'pencil-line') + '"></i><b id="nbc-num">' + cur + '</b><small>/ ' + total + '</small>';
    }
    var prev = document.getElementById('nbp-prev'), next = document.getElementById('nbp-next');
    if (prev) prev.classList.toggle('off', cur <= 1 || !nbIsPageSaved(cur - 1));
    if (next) next.classList.toggle('off', !saved);
    if (window.safeCreateIcons) safeCreateIcons();
}
try { nbRenderPageBar(); } catch (e) {}
