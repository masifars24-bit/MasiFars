(function () {
  'use strict';
  if (window.__mfSync || window.__MF_VIEWER) return;
  var CFG = { url: 'https://wtzffmorfclxivopvsit.supabase.co', key: 'sb_publishable_YDz--eVlnrTgZJ6hKJwLig_bzY1-Fjg', table: 'sync_records' };
  var LS = window.localStorage;
  var _set = Storage.prototype.setItem, _rem = Storage.prototype.removeItem, _get = Storage.prototype.getItem;

  // ---- keys that stay on this device only ----
  var LOCAL_EXACT = {
    mf_theme: 1, mf_size: 1, mf_font: 1, mf_color: 1, mf_custom_width: 1, mf_custom_fonts: 1, mf_custom_colors: 1,
    mf_login_type: 1, mf_employee_session: 1, mf_admin_session: 1, mf_last_section: 1, mf_dock_hidden: 1,
    mf_bot_pos: 1, mf_chat_geom: 1, mf_notebook_current_page: 1, mf_adhan_notified_log: 1, mf_gemini_config: 1,
    mf_tables_layout_mode: 1, mf_tables_edit_locked: 1
  };
  function syncable(k) {
    if (typeof k !== 'string' || k.indexOf('mf_') !== 0) return false;
    if (k.indexOf('mf_sync_') === 0 || k.indexOf('mf_login_fails_') === 0 || k.indexOf('mf_chat_') === 0) return false;
    if (k.indexOf('_corrupt_backup_') > -1) return false;
    return !LOCAL_EXACT[k];
  }

  // ---- persistent meta / queue / auth ----
  function rd(k, d) { try { var v = _get.call(LS, k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function wr(k, v) { try { _set.call(LS, k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  var meta = rd('mf_sync_meta', null) || {};
  if (!meta.device) { meta.device = 'd' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); wr('mf_sync_meta', meta); }
  var queue = rd('mf_sync_queue', {});          // "key\u0000path" -> {key,path,data,deleted}
  var auth = rd('mf_sync_auth', null);
  var APP = {};                                  // key -> {path: jsonString}  (last known local state)
  var inbox = {};                                // buffered remote records not yet applied
  var st = { busy: false, err: '', last: 0, online: navigator.onLine };
  var applying = false;

  function saveMeta() { wr('mf_sync_meta', meta); }
  function saveQueue() { wr('mf_sync_queue', queue); }
  function qn() { return Object.keys(queue).length; }

  // ---- record encoding ----
  function isIdObj(x) { return x && typeof x === 'object' && !Array.isArray(x) && (x.uid != null || x.id != null); }
  function rid(x) { return String(x.uid != null ? x.uid : x.id); }
  function isIdArr(a) {
    if (!Array.isArray(a) || !a.length) return false;
    var seen = {};
    for (var i = 0; i < a.length; i++) { if (!isIdObj(a[i])) return false; var r = rid(a[i]); if (seen[r]) return false; seen[r] = 1; }
    return true;
  }
  function enc(s) { return encodeURIComponent(s); }
  // returns {path: dataObject}
  function encode(key, raw, prev) {
    var out = {}, val, parsed = false;
    try { val = JSON.parse(raw); parsed = true; } catch (e) {}
    if (parsed && isIdArr(val)) {
      out['#'] = { kind: 'arr' };
      fillArr(out, '', val, prev);
      return out;
    }
    if (parsed && val && typeof val === 'object' && !Array.isArray(val)) {
      var tops = Object.keys(val), ok = tops.length > 0;
      for (var t = 0; t < tops.length && ok; t++) { var a = val[tops[t]]; if (!(Array.isArray(a) && (a.length === 0 || isIdArr(a)))) ok = false; }
      if (ok) {
        out['#'] = { kind: 'map', tops: tops };
        tops.forEach(function (top) { fillArr(out, enc(top) + '/', val[top], prev); });
        return out;
      }
    }
    out[''] = { raw: raw };
    return out;
  }
  function fillArr(out, pre, arr, prev) {
    var n = arr.length, idx = new Array(n), keep = new Array(n), last = -Infinity, i, p;
    for (i = 0; i < n; i++) {
      p = prev && prev[pre + enc(rid(arr[i]))];
      var pi = null; if (p) { try { pi = JSON.parse(p).i; } catch (e) {} }
      if (typeof pi === 'number' && pi > last) { idx[i] = pi; keep[i] = true; last = pi; } else keep[i] = false;
    }
    for (i = 0; i < n; i++) {
      if (keep[i]) continue;
      var lo = i > 0 ? idx[i - 1] : null, j = i + 1, hi = null;
      while (j < n && !keep[j]) j++;
      if (j < n) hi = idx[j];
      var gap = j - i;
      if (lo == null && hi == null) idx[i] = i;
      else if (hi == null) idx[i] = lo + 1;
      else if (lo == null) idx[i] = hi - gap;
      else idx[i] = lo + (hi - lo) * (1 / (gap + 1));
      // handle when this is first of a gap and later items share the span
    }
    for (i = 0; i < n; i++) out[pre + enc(rid(arr[i]))] = { v: arr[i], i: idx[i] };
  }
  // rebuild raw string from {path: data} (live records only)
  function decode(map) {
    var shape = map['#'];
    if (shape) {
      var groups = {};
      Object.keys(map).forEach(function (p) {
        if (p === '#' || p === '') return;
        var s = p.lastIndexOf('/'); var pre = s < 0 ? '' : p.slice(0, s + 1);
        (groups[pre] = groups[pre] || []).push(map[p]);
      });
      function sorted(g) { return (g || []).sort(function (a, b) { return a.i - b.i; }).map(function (x) { return x.v; }); }
      if (shape.kind === 'arr') return JSON.stringify(sorted(groups['']));
      var obj = {}, tops = (shape.tops || []).slice();
      Object.keys(groups).forEach(function (pre) { var t = decodeURIComponent(pre.slice(0, -1)); if (tops.indexOf(t) < 0) tops.push(t); });
      tops.forEach(function (t) { obj[t] = sorted(groups[enc(t) + '/']); });
      return JSON.stringify(obj);
    }
    if (map[''] && typeof map[''].raw === 'string') return map[''].raw;
    return null;
  }

  // ---- diff local writes into queue ----
  function qk(key, path) { return key + '\u0000' + path; }
  function stamp(rec) { return rec; }
  function diffKey(key, raw) {
    var prev = APP[key] || {}, next = {};
    if (raw != null) {
      var enc_ = encode(key, raw, prev);
      Object.keys(enc_).forEach(function (p) { next[p] = JSON.stringify(enc_[p]); });
    }
    var changed = false;
    Object.keys(next).forEach(function (p) {
      if (prev[p] !== next[p]) { queue[qk(key, p)] = { key: key, path: p, deleted: false }; changed = true; }
    });
    Object.keys(prev).forEach(function (p) {
      if (!(p in next)) { queue[qk(key, p)] = { key: key, path: p, deleted: true }; changed = true; }
    });
    APP[key] = next;
    if (changed) { saveQueue(); schedulePush(); }
    refreshUI();
  }
  function onWrite(key, raw) {
    if (applying || !meta.init || !syncable(key)) return;
    try { diffKey(key, raw); } catch (e) { console.error('sync diff', e); }
  }
  Storage.prototype.setItem = function (k, v) {
    var r = _set.call(this, k, v);
    if (this === LS) onWrite(k, String(v));
    return r;
  };
  Storage.prototype.removeItem = function (k) {
    var r = _rem.call(this, k);
    if (this === LS) onWrite(k, null);
    return r;
  };

  function buildAPP() {
    APP = {};
    for (var i = 0; i < LS.length; i++) {
      var k = LS.key(i); if (!syncable(k)) continue;
      var raw = _get.call(LS, k), e = encode(k, raw, null), m = {};
      Object.keys(e).forEach(function (p) { m[p] = JSON.stringify(e[p]); });
      APP[k] = m;
    }
  }

  if (meta.init) buildAPP();

  // ---- network ----
  function hdr(tok, extra) {
    var h = { apikey: CFG.key, 'Content-Type': 'application/json' };
    h.Authorization = 'Bearer ' + (tok || CFG.key);
    if (extra) for (var k in extra) h[k] = extra[k];
    return h;
  }
  function tmo(ms) { var c = new AbortController(); setTimeout(function () { c.abort(); }, ms); return c.signal; }
  function authCall(grant, body) {
    return fetch(CFG.url + '/auth/v1/token?grant_type=' + grant, { method: 'POST', headers: hdr(), body: JSON.stringify(body), signal: tmo(20000) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error_description || j.msg || j.error || ('HTTP ' + r.status)); return j; }); })
      .then(function (j) { auth = { access: j.access_token, refresh: j.refresh_token, exp: Date.now() + (j.expires_in || 3600) * 1000, email: (j.user && j.user.email) || (auth && auth.email) || '' }; wr('mf_sync_auth', auth); return auth; });
  }
  function token() {
    if (!auth) return Promise.reject(new Error('NOAUTH'));
    if (auth.exp - Date.now() > 60000) return Promise.resolve(auth.access);
    return authCall('refresh_token', { refresh_token: auth.refresh }).then(function (a) { return a.access; }, function (e) {
      if (!navigator.onLine || /Failed to fetch|abort|Network/i.test(e.message)) throw e;
      auth = null; _rem.call(LS, 'mf_sync_auth'); throw new Error('NOAUTH');
    });
  }
  function api(path, opt) {
    return token().then(function (tok) {
      opt = opt || {}; opt.headers = hdr(tok, opt.headers); opt.signal = tmo(45000);
      return fetch(CFG.url + '/rest/v1/' + path, opt).then(function (r) {
        if (r.status === 401) { auth.exp = 0; throw new Error('HTTP 401'); }
        if (!r.ok) return r.text().then(function (t) { throw new Error('HTTP ' + r.status + ' ' + t.slice(0, 120)); });
        return r.status === 204 ? null : r.json().catch(function () { return null; });
      });
    });
  }

  // ---- push ----
  function push() {
    var ks = Object.keys(queue);
    if (!ks.length) return Promise.resolve();
    var batch = [], size = 0, taken = [];
    var __n = ks.length;
    for (var i = 0; i < ks.length; i++) {
      var q = queue[ks[i]], d = null;
      if (!q.deleted) { var js = APP[q.key] && APP[q.key][q.path]; if (js === undefined) { delete queue[ks[i]]; continue; } d = JSON.parse(js); }
      var row = { key: q.key, path: q.path, data: d, deleted: !!q.deleted, device: meta.device };
      var s = JSON.stringify(row).length;
      if (batch.length && (size + s > 900000 || batch.length >= 100)) break;
      batch.push(row); taken.push(ks[i]); size += s;
    }
    if (!batch.length) { saveQueue(); return Object.keys(queue).length ? push() : Promise.resolve(); }
    return api(CFG.table + '?on_conflict=key,path', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify(batch) })
      .then(function () {
        taken.forEach(function (k) { delete queue[k]; });
        saveQueue();
        return push();
      });
  }

  // ---- pull ----
  function pullPage(cursor, offset, acc) {
    var q = CFG.table + '?select=key,path,data,deleted,device,updated_at&order=updated_at.asc,key.asc,path.asc&limit=200&offset=' + offset;
    if (cursor) q += '&updated_at=gte.' + encodeURIComponent(cursor);
    return api(q).then(function (rows) {
      rows = rows || [];
      acc.push.apply(acc, rows);
      if (rows.length === 200) return pullPage(cursor, offset + 200, acc);
      return acc;
    });
  }
  function pull() {
    return pullPage(meta.cursor || null, 0, []).then(function (rows) {
      var maxTs = meta.cursor || '';
      rows.forEach(function (r) { if (r.updated_at > maxTs) maxTs = r.updated_at; });
      return { rows: rows, cursor: maxTs };
    });
  }

  // ---- apply remote ----
  function recsOf(key) { // parsed records currently in APP
    var m = {}, a = APP[key] || {};
    Object.keys(a).forEach(function (p) { m[p] = JSON.parse(a[p]); });
    return m;
  }
  var softFailed = false;
  var CORE = { mf_orders_by_page: 1, mf_order_next_id_by_page: 1, mf_tables_data: 1, mf_login_requests: 1 };
  // keys applied live (no page reload); non-CORE ones wait while a sheet/popup is open
  var SOFT = { mf_orders_by_page: 1, mf_order_next_id_by_page: 1, mf_tables_data: 1,
    mf_debt_profiles: 1, mf_my_debt_profiles: 1, mf_receipts: 1, mf_receipt_next_number: 1, mf_receipt_code_seq: 1,
    mf_login_requests: 1, mf_daily_expenses: 1, mf_purchase_profiles: 1, mf_sale_profiles: 1, mf_employees: 1, mf_supplies_data: 1, mf_couriers_data: 1 };
  function overlayOpen() { return !!document.querySelector('.overlay-sheet.active,.custom-popup-overlay.active,.custom-popup-overlay.show,.crp-page.active,.crp-page.show'); }
  function applyInbox(only) {
    var byKey = {}, changed = [];
    Object.keys(inbox).forEach(function (id) { var r = inbox[id]; if (only && !only(r.key)) return; (byKey[r.key] = byKey[r.key] || []).push(r); delete inbox[id]; });
    var n = 0;
    applying = true;
    try {
      Object.keys(byKey).forEach(function (key) {
        if (!syncable(key)) return;
        var cur = recsOf(key), touched = false;
        byKey[key].forEach(function (r) {
          if (queue[qk(key, r.path)]) return;           // local pending change wins
          if (r.deleted) { if (r.path in cur) { delete cur[r.path]; touched = true; } }
          else { var js = JSON.stringify(r.data); if (JSON.stringify(cur[r.path]) !== js) { cur[r.path] = r.data; touched = true; } }
        });
        if (!touched) return;
        var raw = decode(cur);
        if (raw == null || (!Object.keys(cur).length)) _rem.call(LS, key); else _set.call(LS, key, raw);
        var m = {}; Object.keys(cur).forEach(function (p) { m[p] = JSON.stringify(cur[p]); }); APP[key] = m;
        n++; changed.push(key);
      });
    } finally { applying = false; }
    return only ? changed : n;
  }
  function bufferRows(rows, skipOwn) {
    rows.forEach(function (r) {
      if (!syncable(r.key)) return;
      if (skipOwn && r.device === meta.device) return;
      var cur = APP[r.key] && APP[r.key][r.path];
      if (r.deleted ? cur === undefined : cur === JSON.stringify(r.data)) return;
      inbox[r.key + '\u0000' + r.path] = r;
    });
  }

  // ---- first sync ----
  function firstSync() {
    meta.cursor = null;
    return pullPage(null, 0, []).then(function (rows) {
      var maxTs = ''; var serverKeys = {};
      rows.forEach(function (r) { if (r.updated_at > maxTs) maxTs = r.updated_at; if (!r.deleted && syncable(r.key)) serverKeys[r.key] = 1; });
      // keys the server has: server wins. Keys only local: upload.
      buildAPP();
      var allLocal = Object.keys(APP);
      allLocal.forEach(function (key) {
        if (serverKeys[key]) return;
        Object.keys(APP[key]).forEach(function (p) { queue[qk(key, p)] = { key: key, path: p, deleted: false }; });
      });
      // for server keys, drop local view so server state replaces it
      Object.keys(serverKeys).forEach(function (k) { APP[k] = {}; });
      var live = rows.filter(function (r) { return !r.deleted; });
      bufferRows(live, false);
      var replaced = applyInbox();
      meta.init = true; meta.cursor = maxTs || null; saveMeta(); saveQueue();
      return replaced;
    });
  }

  // ---- WIPE ALL DEVICES: marker row on server; every device wipes itself when it sees a new marker ----
  var WIPE_KEY = '__wipe__';
  function wipeLocalData() {
    var del = [];
    for (var i = 0; i < LS.length; i++) { var k = LS.key(i); if (syncable(k)) del.push(k); }
    del.forEach(function (k) { _rem.call(LS, k); });          // raw remove: nothing gets queued
    queue = {}; inbox = {}; APP = {}; saveQueue();
    meta.init = false; meta.cursor = null; saveMeta();         // next load = clean first sync
  }
  function checkWipe() {
    return api(CFG.table + '?select=data&key=eq.' + WIPE_KEY + '&path=eq.&limit=1').then(function (rows) {
      var row = rows && rows[0], id = (row && row.data && row.data.id) || null;
      if (meta.wipe === undefined) {
        // device that never recorded a marker: brand-new device just records it; an already-synced old device must wipe
        if (id && meta.init) return wipeThisDevice(id);
        meta.wipe = id; saveMeta(); return false;
      }
      if (id !== meta.wipe) return wipeThisDevice(id);
      return false;
    });
  }
  function wipeThisDevice(id) {
    wipeLocalData(); meta.wipe = id; saveMeta();
    return true;
  }
  function isAdminNow() { try { return _get.call(LS, 'mf_admin_session') === '1'; } catch (e) { return false; } }
  function wipeEverywhere() {
    if (!isAdminNow()) { window.mfDialog.alert('ئەم کارە تەنیا بۆ ئەدمینە', { title: 'ڕێگەپێنەدراو', type: 'err' }); return; }
    if (!auth) { if (panel) panel.classList.remove('open'); showGate(); return; }
    if (st.busy) { window.mfDialog.alert('چەند چرکەیەک چاوەڕێ بکە و دووبارە هەوڵ بدەرەوە', { title: 'گونجاندن لە کاردایە', type: 'info' }); return; }
    window.mfDialog.confirm('هەموو داتا و زانیارییەکان لە سێرڤەر و لە هەموو مۆبایلەکان دەسڕدرێنەوە.\nئەم کارە ناگەڕێتەوە. سەرەتا فایلێکی باکئەپ دابەزێنرێت.',
      { title: 'سڕینەوەی هەموو داتا لە هەموو شوێنێک', type: 'danger', icon: 'trash', ok: 'بەردەوام بە', cancel: 'پاشگەزبوونەوە' }).then(function (y1) {
      if (!y1) return;
      return window.mfDialog.confirm('دوا دڵنیابوونەوە: هەموو داتا بۆ هەمیشە دەسڕێتەوە و ئەپەکە دەبێتە ئەپێکی خاڵی.',
        { title: 'ئایا دڵنیایت؟', type: 'danger', icon: 'trash', ok: 'بەڵێ، هەمووی بسڕەوە', cancel: 'نەخێر' }).then(function (y2) {
        if (!y2) return;
        try { doBackup(); } catch (e) {}
        st.busy = true; refreshUI();
        var id = 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
        return api(CFG.table + '?key=not.in.(' + WIPE_KEY + ',__sysctl__)', { method: 'DELETE', headers: { Prefer: 'return=minimal' } })
          .then(function () { return true; }, function (e) {
            st.busy = false;
            return window.mfDialog.confirm('ئەپەکە ڕێگەی سڕینەوەی ڕاستەوخۆی نییە (' + (e.message || '') + ').\nلە Supabase > SQL Editor ئەمە جێبەجێ بکە:\ndelete from public.sync_records where key <> \'' + WIPE_KEY + '\';\nدوای ئەوەی ئەنجامت دا، «ئەنجامم دا» بکە.',
              { title: 'سڕینەوەی ڕاستەوخۆ نییە', type: 'warn', ok: 'ئەنجامم دا', cancel: 'پاشگەزبوونەوە' }).then(function (ok) { st.busy = true; return ok; });
          })
          .then(function (go) {
            if (!go) { st.busy = false; refreshUI(); return; }
            return api(CFG.table + '?on_conflict=key,path', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
              body: JSON.stringify([{ key: WIPE_KEY, path: '', data: { id: id, at: Date.now() }, deleted: false, device: meta.device }]) })
              .then(function () {
                wipeLocalData(); meta.wipe = id; saveMeta();
                st.busy = false;
                setTimeout(function () { location.reload(); }, 300);
              });
          }).catch(function (e) {
            st.busy = false; refreshUI();
            window.mfDialog.alert((e && e.message) || 'هەڵە', { title: 'سڕینەوە سەرکەوتوو نەبوو', type: 'err' });
          });
      });
    });
  }

  // ---- main cycle ----
  var timer = null, pushT = null, pollT = null;
  function schedulePush() { clearTimeout(pushT); pushT = setTimeout(function () { cycle(); }, 500); }
  function cycle() {
    if (st.busy || !auth || !navigator.onLine) { refreshUI(); return Promise.resolve(); }
    st.busy = true; st.err = ''; refreshUI();
    var p = checkWipe().then(function (wiped) {
      if (wiped) { setTimeout(function () { location.reload(); }, 300); throw new Error('RELOAD'); }
      return meta.init ? 0 : firstSync();
    });
    return p.then(function (replaced) {
      if (replaced) { setTimeout(function () { location.reload(); }, 300); throw new Error('RELOAD'); }
      return push();
    }).then(function () {
      return api(CFG.table + '?select=updated_at&order=updated_at.desc&limit=1').then(function (h) {
        var latest = h && h[0] && h[0].updated_at;
        if (!latest || latest === meta.cursor) return { rows: [], cursor: meta.cursor };
        return pull();
      });
    }).then(function (res) {
      bufferRows(res.rows, true);
      meta.cursor = res.cursor || meta.cursor; saveMeta();
      st.last = Date.now();
    }).catch(function (e) {
      if (e.message === 'RELOAD') return;
      st.err = e.message === 'NOAUTH' ? 'NOAUTH' : (e.message || 'error');
    }).then(function () {
      st.busy = false; refreshUI(); maybeReload();
    });
  }

  // ---- wipe server + re-upload this device's data (no device cleaning needed) ----
  function resetServer() {
    if (!auth) { if (panel) panel.classList.remove('open'); showGate(); return; }
    if (st.busy) { window.mfDialog.alert('چەند چرکەیەک چاوەڕێ بکە و دووبارە هەوڵ بدەرەوە', { title: 'گونجاندن لە کاردایە', type: 'info' }); return; }
    window.mfDialog.confirm('هەموو داتای سێرڤەر دەسڕدرێتەوە و داتای ئەم ئامێرە دەنێردرێتەوە.\nدڵنیابە هەموو ئامێرەکان پێشتر گونجێنراون و ئەمە ئەو ئامێرەیە کە نوێترین داتای تێدایە.',
      { title: 'پاککردنەوەی سێرڤەر', type: 'danger', icon: 'trash', ok: 'بەڵێ، بەردەوام بە', cancel: 'پاشگەزبوونەوە' }).then(function (yes) {
      if (!yes) return;
      st.busy = true; refreshUI();
      return api(CFG.table + '?key=not.in.(__wipe__,__sysctl__)', { method: 'DELETE', headers: { Prefer: 'return=minimal' } })
        .then(function () { return true; }, function (e) {
          st.busy = false;
          return window.mfDialog.confirm('ئەپەکە ڕێگەی سڕینەوەی ڕاستەوخۆی نییە (' + (e.message || '') + ').\nلە Supabase > SQL Editor ئەمە جێبەجێ بکە:\ntruncate table public.sync_records;\nدوای ئەوەی ئەنجامت دا، «ئەنجامم دا» بکە بۆ ناردنەوەی داتای ئەم ئامێرە.',
            { title: 'سڕینەوەی ڕاستەوخۆ نییە', type: 'warn', ok: 'ئەنجامم دا', cancel: 'پاشگەزبوونەوە' }).then(function (ok) { st.busy = true; return ok; });
        })
        .then(function (go) {
          if (!go) { st.busy = false; refreshUI(); return; }
          buildAPP();
          queue = {}; inbox = {};
          Object.keys(APP).forEach(function (k) { Object.keys(APP[k]).forEach(function (p) { queue[qk(k, p)] = { key: k, path: p, deleted: false }; }); });
          saveQueue(); meta.init = true; meta.cursor = null; saveMeta();
          st.busy = false; if (panel) panel.classList.remove('open'); refreshUI();
          return cycle();
        });
    });
  }

  // ---- idle reload ----
  var lastTouch = Date.now();
  ['pointerdown', 'keydown', 'touchstart', 'scroll', 'input'].forEach(function (ev) { addEventListener(ev, function () { lastTouch = Date.now(); }, { passive: true, capture: true }); });
  function isIdle() {
    if (Date.now() - lastTouch < 3000) return false;
    var a = document.activeElement; if (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) return false;
    if (document.querySelector('.overlay-sheet.active,.custom-popup-overlay.active,.custom-popup-overlay.show,.crp-page.active,.crp-page.show')) return false;
    return true;
  }
  function maybeReload() {
    if (!Object.keys(inbox).length) return;
    var soft = applyInbox(function (k) { return SOFT[k] && typeof window.mfLiveApply === 'function' && (CORE[k] || !overlayOpen()); });
    soft.forEach(function (k) { var ok = false; try { ok = window.mfLiveApply(k); } catch (e) {} if (!ok) softFailed = true; });
    refreshUI();
    if (softFailed) { if (isIdle()) location.reload(); return; }
    if (!Object.keys(inbox).length) return;
    if (!isIdle()) return;
    reloadNow();
  }
  function reloadNow() { var n = applyInbox(); if (n || softFailed) location.reload(); else refreshUI(); }

  // ---- UI ----
  var chip, panel;
  var CSS = '#mfs-chip{position:relative;width:46px;height:46px;flex:0 0 46px;margin-inline-start:10px;border-radius:15px;display:flex;align-items:center;justify-content:center;padding:0;cursor:pointer;color:var(--text-muted,#7a7f99);background:var(--bg-card,#fff);border:1px solid var(--border,rgba(0,0,0,.08));box-shadow:var(--solid-shadow,0 6px 16px rgba(20,20,60,.12));transition:transform .2s,box-shadow .2s;-webkit-tap-highlight-color:transparent}' +
    '.mf-top-launcher-wrap{position:static!important}.mf-top-menu{inset-inline-end:auto!important;left:auto!important;right:14px!important;top:calc(100% + 16px)!important;max-width:calc(100vw - 28px)}' +
    '#mfs-chip:active{transform:scale(.94)}#mfs-chip.fixed{position:fixed;left:10px;bottom:calc(86px + env(safe-area-inset-bottom));z-index:2147483000;margin:0}' +
    '#mfs-chip svg.cl{width:26px;height:26px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;transition:color .3s}' +
    '#mfs-chip.ok{color:#1fa35a}#mfs-chip.pend{color:#d99a00}#mfs-chip.busy{color:#3b82f6}#mfs-chip.err{color:#d93a3a}#mfs-chip.off{color:var(--text-muted,#8a8fa8)}' +
    '#mfs-chip .dot{position:absolute;top:5px;right:5px;width:11px;height:11px;border-radius:50%;background:currentColor;border:2px solid var(--bg-card,#fff);box-sizing:border-box}' +
    '#mfs-chip.off .dot{display:none}#mfs-chip.ok .dot{animation:mfsDot 2.6s ease-in-out infinite}@keyframes mfsDot{0%,100%{opacity:1}50%{opacity:.35}}' +
    '#mfs-chip .cnt{position:absolute;top:-5px;left:-5px;min-width:19px;height:19px;padding:0 5px;border-radius:10px;background:#d99a00;color:#fff;font:800 11px/19px system-ui;text-align:center;box-sizing:border-box;box-shadow:0 2px 6px rgba(0,0,0,.25)}#mfs-chip .cnt.up{background:#6d3df0}' +
    '#mfs-chip.busy::after{content:"";position:absolute;inset:-3px;border-radius:18px;border:2px solid transparent;border-top-color:#3b82f6;animation:mfsSpin .9s linear infinite}' +
    '#mfs-panel{position:fixed;inset:0;z-index:2147483001;background:rgba(8,6,24,.62);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);display:none;align-items:center;justify-content:center;padding:16px;direction:rtl;font-family:inherit}' +
    '#mfs-panel.open{display:flex!important}#mfs-box{width:100%;max-width:380px;max-height:calc(100dvh - 32px);overflow:auto;padding:0;border-radius:30px;background:var(--bg-card,#fff);color:var(--text-main,#222);border:1px solid color-mix(in srgb,#8b5cff 22%,var(--border,rgba(0,0,0,.1)));box-shadow:0 30px 80px rgba(20,5,60,.55);animation:mfsPop .35s cubic-bezier(.2,.9,.3,1) both}' +
    '#mfs-gate{position:fixed;inset:0;z-index:2147483002;display:none;align-items:center;justify-content:center;padding:20px;direction:rtl;overflow:hidden;font-family:inherit;color:#fff;background:linear-gradient(160deg,#1a0f3d 0%,#3b1a78 45%,#a32d7c 100%)}' +
'#mfs-gate.open{display:flex!important}body.app-locked>#mfs-gate.open{display:flex!important}' +
'#mfs-gate .blob{position:absolute;border-radius:50%;filter:blur(60px);opacity:.55;animation:mfsFloat 14s ease-in-out infinite}' +
'#mfs-gate .b1{width:300px;height:300px;background:#7c4dff;top:-80px;right:-80px}#mfs-gate .b2{width:280px;height:280px;background:#ff4fa3;bottom:-90px;left:-70px;animation-delay:-5s}#mfs-gate .b3{width:200px;height:200px;background:#35d0ff;top:45%;left:30%;opacity:.25;animation-delay:-9s}' +
'@keyframes mfsFloat{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(24px,-30px) scale(1.12)}}' +
'@keyframes mfsIn{from{opacity:0;transform:translateY(24px) scale(.97)}to{opacity:1;transform:none}}@keyframes mfsSpin{to{transform:rotate(360deg)}}@keyframes mfsPulse{0%,100%{box-shadow:0 0 0 0 rgba(255,255,255,.35)}50%{box-shadow:0 0 0 16px rgba(255,255,255,0)}}' +
'#mfs-card{position:relative;width:100%;max-width:380px;padding:30px 24px 22px;border-radius:28px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.28);backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);box-shadow:0 24px 70px rgba(10,0,40,.5);animation:mfsIn .6s cubic-bezier(.2,.9,.3,1) both;text-align:center}' +
'#mfs-logo{width:76px;height:76px;margin:-64px auto 14px;border-radius:24px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#8b5cff,#ff5fb0);box-shadow:0 12px 30px rgba(139,92,255,.55);animation:mfsPulse 3s infinite}' +
'#mfs-card h2{margin:0 0 6px;font-size:22px;font-weight:900;letter-spacing:.2px}#mfs-card .sub{margin:0 0 20px;font-size:13px;line-height:1.8;opacity:.82}' +
'.mfs-f{position:relative;margin:10px 0}.mfs-f svg{position:absolute;right:14px;top:50%;transform:translateY(-50%);opacity:.7;pointer-events:none}' +
'.mfs-f input{width:100%;box-sizing:border-box;padding:14px 44px 14px 44px;border-radius:16px;border:1.5px solid rgba(255,255,255,.25);background:rgba(255,255,255,.1);color:#fff;font-size:15px;outline:0;direction:ltr;text-align:left;transition:.2s}' +
'.mfs-f input::placeholder{color:rgba(255,255,255,.55);direction:rtl}.mfs-f input:focus{border-color:#fff;background:rgba(255,255,255,.18);box-shadow:0 0 0 4px rgba(255,255,255,.12)}' +
'.mfs-eye{position:absolute;left:8px;top:50%;transform:translateY(-50%);width:34px;height:34px;border:0;background:transparent;color:#fff;opacity:.75;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0}' +
'#mfs-go{width:100%;margin-top:16px;padding:15px;border:0;border-radius:16px;font-size:16px;font-weight:800;color:#2b0f63;background:linear-gradient(180deg,#fff,#efe6ff);cursor:pointer;box-shadow:0 10px 26px rgba(0,0,0,.28);display:flex;align-items:center;justify-content:center;gap:10px;transition:.15s}#mfs-go:active{transform:scale(.97)}#mfs-go[disabled]{opacity:.75}' +
'.mfs-sp{width:18px;height:18px;border-radius:50%;border:2.5px solid rgba(43,15,99,.25);border-top-color:#2b0f63;animation:mfsSpin .8s linear infinite}' +
'#mfs-err{min-height:20px;margin-top:12px;font-size:13px;color:#ffd3d3;font-weight:700}#mfs-skip{margin-top:10px;background:none;border:0;color:rgba(255,255,255,.7);font-size:13px;cursor:pointer;text-decoration:underline;padding:6px}' +
'#mfs-steps{display:none;margin-top:6px;text-align:right}#mfs-steps div{display:flex;align-items:center;gap:10px;padding:9px 4px;font-size:14px;opacity:.5}#mfs-steps div.on{opacity:1}#mfs-steps div.done{opacity:.95}.mfs-dot{width:22px;height:22px;border-radius:50%;border:2px solid rgba(255,255,255,.5);display:flex;align-items:center;justify-content:center;font-size:12px;flex:none}.on .mfs-dot{border-color:#fff;border-top-color:transparent;animation:mfsSpin .8s linear infinite}.done .mfs-dot{background:#3be58b;border-color:#3be58b;color:#05361d}' +
    'body.app-locked>#mfs-panel.open{display:flex!important}' +
    '@keyframes mfsPop{from{opacity:0;transform:translateY(18px) scale(.96)}to{opacity:1;transform:none}}' +
    '.mf-lite #mfs-panel{-webkit-backdrop-filter:none;backdrop-filter:none}.mf-lite #mfs-box{animation:none}' +
    '#mfs-box button{font-family:inherit;-webkit-tap-highlight-color:transparent}' +
    '.mfs-hd{position:relative;overflow:hidden;padding:22px 18px 20px;color:#fff;background:linear-gradient(135deg,#2a1466,#5b2bd1 55%,#c0388f)}' +
    '.mfs-hd::before,.mfs-hd::after{content:"";position:absolute;border-radius:50%;pointer-events:none}' +
    '.mfs-hd::before{width:170px;height:170px;top:-70px;right:-50px;background:radial-gradient(circle,rgba(255,255,255,.28),transparent 70%)}' +
    '.mfs-hd::after{width:140px;height:140px;bottom:-70px;left:-30px;background:radial-gradient(circle,rgba(53,208,255,.35),transparent 70%)}' +
    '.mfs-hd-row{position:relative;z-index:1;display:flex;align-items:center;gap:13px}' +
    '.mfs-hd-ico{width:54px;height:54px;flex:none;border-radius:18px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);box-shadow:0 8px 22px rgba(10,0,50,.35)}' +
    '.mfs-hd-txt{flex:1;min-width:0}.mfs-hd-txt h3{margin:0 0 8px;font-size:19px;font-weight:900;color:#fff;line-height:1.3}' +
    '.mfs-pill{display:inline-flex;align-items:center;gap:7px;padding:5px 12px;border-radius:999px;font-size:12.5px;font-weight:800;line-height:1.5;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.3);color:#fff}' +
    '.mfs-pill i{width:8px;height:8px;border-radius:50%;flex:none;background:var(--c);box-shadow:0 0 0 3px color-mix(in srgb,var(--c) 30%,transparent)}' +
    '.mfs-pill.ok{--c:#3be58b}.mfs-pill.pend{--c:#ffc83d}.mfs-pill.busy{--c:#5aa9ff}.mfs-pill.err{--c:#ff6b6b}.mfs-pill.off{--c:#b5b8cc}.mfs-pill.busy i{animation:mfsDot 1s ease-in-out infinite}' +
    '.mfs-bd{padding:16px 16px 18px;display:flex;flex-direction:column;gap:12px}' +
    '.mfs-acc{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:20px;background:color-mix(in srgb,#8b5cff 8%,var(--bg-card,#fff));border:1px solid color-mix(in srgb,#8b5cff 18%,var(--border,rgba(0,0,0,.08)))}' +
    '.mfs-acc-ico{width:42px;height:42px;flex:none;border-radius:14px;display:flex;align-items:center;justify-content:center;color:#fff;background:linear-gradient(135deg,#8b5cff,#ff5fb0);box-shadow:0 6px 16px rgba(139,92,255,.4)}' +
    '.mfs-acc-txt{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.mfs-acc-txt small{font-size:11.5px;font-weight:700;color:var(--text-sub,#7a7f99)}' +
    '.mfs-acc-txt b{font-size:14px;font-weight:800;direction:ltr;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mfs-acc>svg{color:#22c55e;flex:none}' +
    '.mfs-main{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;margin:0;padding:15px;border:0;border-radius:20px;font-size:16px;font-weight:900;color:#fff;cursor:pointer;background:linear-gradient(135deg,#6d3df0,#a855f7 60%,#d946ef);box-shadow:0 12px 26px rgba(109,61,240,.45),inset 0 1px 0 rgba(255,255,255,.3);transition:transform .15s}' +
    '.mfs-main:active{transform:scale(.97)}.mfs-main.warm{background:linear-gradient(135deg,#f97316,#ec4899);box-shadow:0 12px 26px rgba(236,72,153,.4),inset 0 1px 0 rgba(255,255,255,.3)}.mfs-main.spin svg{animation:mfsSpin 1s linear infinite}' +
    '.mfs-cnt{min-width:24px;height:24px;padding:0 7px;border-radius:12px;background:rgba(255,255,255,.28);font-size:13px;line-height:24px;text-align:center}' +
    '.mfs-lb{display:flex;align-items:center;gap:8px;margin:6px 2px 0;font-size:12px;font-weight:900;color:var(--text-sub,#7a7f99)}.mfs-lb::after{content:"";flex:1;height:1px;background:var(--border,rgba(128,128,128,.25))}' +
    '.mfs-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}' +
    '.mfs-tile{display:flex;flex-direction:column;align-items:flex-start;gap:10px;width:100%;margin:0;padding:14px 13px;border-radius:22px;text-align:right;cursor:pointer;color:var(--text-main,#222);background:color-mix(in srgb,var(--mc) 9%,var(--bg-card,#fff));border:1px solid color-mix(in srgb,var(--mc) 28%,transparent);box-shadow:0 8px 20px color-mix(in srgb,var(--mc) 14%,transparent);transition:transform .15s}' +
    '.mfs-tile:active{transform:scale(.97)}.mfs-tile.mfs-row{flex-direction:row;align-items:center;gap:13px}.mfs-chev{margin-inline-start:auto;opacity:.45;flex:none;display:flex}' +
    '.mfs-ti{width:46px;height:46px;flex:none;border-radius:16px;display:flex;align-items:center;justify-content:center;color:#fff;background:linear-gradient(135deg,var(--mc),color-mix(in srgb,var(--mc) 55%,#fff));box-shadow:0 8px 18px color-mix(in srgb,var(--mc) 45%,transparent)}' +
    '.mfs-tt{display:flex;flex-direction:column;gap:3px;min-width:0}.mfs-tt b{font-size:14.5px;font-weight:900;line-height:1.3}.mfs-tt span{font-size:11.5px;font-weight:700;line-height:1.5;color:var(--text-sub,#7a7f99)}' +
    '.mfs-last{display:flex;align-items:center;justify-content:center;gap:7px;font-size:12px;font-weight:700;color:var(--text-sub,#7a7f99)}' +
    '.mfs-close{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin:2px 0 0;padding:13px;border-radius:18px;border:1px solid var(--border,rgba(128,128,128,.3));background:transparent;color:var(--text-sub,#7a7f99);font-size:14.5px;font-weight:800;cursor:pointer}' +
    '#mfs-msg{color:#d93a3a;font-size:13px;min-height:16px}';
  function el(t, a, h) { var e = document.createElement(t); for (var k in a || {}) e.setAttribute(k, a[k]); if (h != null) e.innerHTML = h; return e; }
  function statusText() {
    if (!auth) return 'گونجاندن چالاک نییە';
    if (st.err && st.err !== 'NOAUTH') return (navigator.onLine ? 'هەڵە: ' + st.err : 'ئۆفلاین — دوای هاتنەوەی ئینتەرنێت دەگونجێت');
    if (!navigator.onLine) return 'ئۆفلاین — ' + qn() + ' گۆڕانکاری چاوەڕێیە';
    if (st.busy) return 'گونجاندن ...';
    if (qn()) return qn() + ' گۆڕانکاری چاوەڕێی ناردنە';
    return 'گونجێنرا ✓';
  }
  var CLOUD = 'M17.5 19a4.5 4.5 0 0 0 .5-8.97A6 6 0 0 0 6.34 8.6 4.8 4.8 0 0 0 7 19z';
  function cloudSvg(kind) {
    var inner = kind === 'ok' ? '<path d="m9.3 13.4 2.2 2.2 3.8-4.2"/>' : kind === 'off' ? '<path d="M4 4l16 16"/>' : kind === 'busy' ? '<path d="M12 16.5v-5m-2.4 2.4L12 11.5l2.4 2.4"/>' : kind === 'err' ? '<path d="M12 12v3m0 2.2v.01"/>' : '<path d="M12 11.5v5m-2.4-2.4 2.4 2.4 2.4-2.4"/>';
    return '<svg class="cl" viewBox="0 0 24 24"><path d="' + CLOUD + '"/>' + inner + '</svg>';
  }
  function refreshUI() {
    if (!chip) return;
    var c, up = Object.keys(inbox).length, q = qn();
    if (!auth) c = 'off'; else if (st.busy) c = 'busy'; else if (st.err && st.err !== 'NOAUTH') c = navigator.onLine ? 'err' : 'pend'; else if (q || !navigator.onLine) c = 'pend'; else c = 'ok';
    var key = c + '|' + up + '|' + q;
    if (chip.__k !== key) {
      chip.__k = key;
      chip.className = c + (chip.classList.contains('fixed') ? ' fixed' : '');
      chip.innerHTML = cloudSvg(c === 'pend' ? (navigator.onLine ? 'up' : 'off') : c) + (c !== 'off' ? '<i class="dot"></i>' : '') +
        (up ? '<span class="cnt up">↻</span>' : (q ? '<span class="cnt">' + Math.min(q, 99) + '</span>' : ''));
    }
    if (window.__mfRenderCloud) window.__mfRenderCloud(chip, c, up, q, st.err);
    if (panel && panel.classList.contains('open')) { if (panel.__sig === panelSig()) softPanel(); else renderPanel(); }
  }
  function panelSig() { return [auth ? 1 : 0, Object.keys(inbox).length, meta.lastBackup || 0, isAdminNow() ? 1 : 0].join('|'); }
  function softPanel() {
    var pill = panel.querySelector('.mfs-pill');
    if (pill) { pill.className = 'mfs-pill ' + stKind(); pill.innerHTML = '<i></i>'; pill.appendChild(document.createTextNode(statusText())); }
    var sbn = document.getElementById('mfs-syncbtn'); if (sbn) sbn.classList.toggle('spin', !!st.busy);
  }
  var PIC = {
    cloud: '<path d="M17.5 19a4.5 4.5 0 0 0 .5-8.97A6 6 0 0 0 6.34 8.6 4.8 4.8 0 0 0 7 19z"/><path d="m9 13.5 2 2 4-4.5"/>',
    sync: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    down: '<circle cx="12" cy="12" r="10"/><path d="M12 8v8"/><path d="m8 12 4 4 4-4"/>',
    save: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
    hist: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/>',
    out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    inn: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5"/><path d="M15 12H3"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3.5 7 8.5 6 8.5-6"/>',
    shield: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    chev: '<path d="m15 18-6-6 6-6"/>'
  };
  function pic(n, s, w) { return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (w || 2) + '" stroke-linecap="round" stroke-linejoin="round">' + PIC[n] + '</svg>'; }
  function stKind() {
    if (!auth) return 'off'; if (st.busy) return 'busy';
    if (st.err && st.err !== 'NOAUTH') return navigator.onLine ? 'err' : 'pend';
    return (qn() || !navigator.onLine) ? 'pend' : 'ok';
  }
  function mainBtn(cls, ico, label, fn, cnt) {
    var b = el('button', { type: 'button', class: 'mfs-main ' + cls }, pic(ico, 22, 2.2) + '<span>' + label + '</span>' + (cnt ? '<span class="mfs-cnt">' + cnt + '</span>' : ''));
    b.onclick = fn; return b;
  }
  function tile(row, color, ico, title, sub, fn) {
    var b = el('button', { type: 'button', class: 'mfs-tile' + (row ? ' mfs-row' : ''), style: '--mc:' + color },
      '<span class="mfs-ti">' + pic(ico, 23, 2) + '</span><span class="mfs-tt"><b>' + title + '</b><span>' + sub + '</span></span>' + (row ? '<span class="mfs-chev">' + pic('chev', 20, 2.4) + '</span>' : ''));
    b.onclick = fn; return b;
  }
  function renderPanel() {
    var box = panel.firstChild, sc = box.scrollTop; panel.__sig = panelSig(); box.innerHTML = '';
    panel.onclick = function (e) { if (e.target === panel) panel.classList.remove('open'); };
    var hd = el('div', { class: 'mfs-hd' }, '<div class="mfs-hd-row"><div class="mfs-hd-ico">' + pic('cloud', 28, 1.8) + '</div><div class="mfs-hd-txt"><h3>گونجاندن لەگەڵ سێرڤەر</h3></div></div>');
    var pill = el('span', { class: 'mfs-pill ' + stKind() }, '<i></i>'); pill.appendChild(document.createTextNode(statusText()));
    hd.querySelector('.mfs-hd-txt').appendChild(pill); box.appendChild(hd);
    var bd = el('div', { class: 'mfs-bd' }); box.appendChild(bd);
    if (!auth) {
      bd.appendChild(mainBtn('', 'inn', 'چوونەژوورەوە بۆ سێرڤەر', function () { panel.classList.remove('open'); showGate(); }));
    } else {
      var acc = el('div', { class: 'mfs-acc' }, '<span class="mfs-acc-ico">' + pic('mail', 21, 2) + '</span><span class="mfs-acc-txt"><small>ئەکاونتی پەیوەستکراو</small><b></b></span>' + pic('shield', 24, 2));
      acc.querySelector('b').textContent = auth.email || ''; bd.appendChild(acc);
    if (cloud.enabled() && cloud.role() === 'admin' && window.mfCloudProvisionAll) bd.appendChild(mainBtn('', 'inn', 'دروستکردنی ئەکاونتی کلاود بۆ کارمەندان', function () { panel.classList.remove('open'); window.mfCloudProvisionAll(); }));
      var n = Object.keys(inbox).length;
      if (n) bd.appendChild(mainBtn('warm', 'down', 'نوێکردنەوەی داتا', reloadNow, n));
      var syncBtn = mainBtn(st.busy ? 'spin' : '', 'sync', 'گونجاندنی ئێستا', function () { cycle(); }); syncBtn.id = 'mfs-syncbtn'; bd.appendChild(syncBtn);
    }
    bd.appendChild(el('div', { class: 'mfs-lb' }, 'داتا و باکئەپ'));
    var g = el('div', { class: 'mfs-grid' }); bd.appendChild(g);
    g.appendChild(tile(false, '#10b981', 'save', 'باکئەپ', 'دابەزاندنی هەموو داتا', doBackup));
    g.appendChild(tile(false, '#0ea5e9', 'hist', 'گەڕاندنەوە', 'لە فایلی باکئەپ', doRestore));
    if (meta.lastBackup) {
      var lb = el('div', { class: 'mfs-last' }, pic('clock', 15, 2) + '<span>دوایین باکئەپ:</span><bdi></bdi>');
      lb.querySelector('bdi').textContent = new Date(meta.lastBackup).toLocaleString('en-GB'); bd.appendChild(lb);
    }
    try { if (window.mfStorageCard) { bd.appendChild(el('div', { class: 'mfs-lb' }, 'شوێنی پاشەکەوتکردن')); bd.appendChild(window.mfStorageCard()); } } catch (e) {}
    if (auth) {
      bd.appendChild(el('div', { class: 'mfs-lb' }, 'ئەکاونت و سێرڤەر'));
      bd.appendChild(tile(true, '#ef4444', 'trash', 'پاککردنەوەی سێرڤەر', 'ناردنەوەی داتای ئەم ئامێرە', resetServer));
      if (isAdminNow()) bd.appendChild(tile(true, '#b91c1c', 'trash', 'سڕینەوەی هەموو داتا لە هەموو ئامێرەکان', 'سێرڤەر + هەموو مۆبایلەکان', wipeEverywhere));
      bd.appendChild(tile(true, '#f59e0b', 'out', 'دەرچوون', 'کۆتایی هێنان بە پەیوەندی', function () {
        var go = function () { auth = null; _rem.call(LS, 'mf_sync_auth'); meta.skip = 0; saveMeta(); panel.classList.remove('open'); refreshUI(); showGate(); };
        if (qn()) window.mfDialog.confirm('هێشتا ' + qn() + ' گۆڕانکاری نەنێردراوە و ونەدەبن.', { title: 'دەرچوون لە ئەکاونت', type: 'warn', icon: 'out', ok: 'بەڵێ، دەرچوون', cancel: 'مانەوە' }).then(function (y) { if (y) go(); });
        else go();
      }));
    }
    try { if (window.__mfServerCard) bd.appendChild(window.__mfServerCard({ c: !auth ? 'off' : st.busy ? 'busy' : (st.err && st.err !== 'NOAUTH') ? (navigator.onLine ? 'err' : 'pend') : (qn() || !navigator.onLine) ? 'pend' : 'ok', err: st.err })); } catch (e) {}
    var c = el('button', { type: 'button', class: 'mfs-close' }, pic('x', 18, 2.4) + '<span>داخستن</span>');
    c.onclick = function () { panel.classList.remove('open'); }; bd.appendChild(c);
    box.scrollTop = sc;
  }
  function doLogin() {
    var em = document.getElementById('mfs-em').value.trim(), pw = document.getElementById('mfs-pw').value, m = document.getElementById('mfs-msg');
    if (!em || !pw) { m.textContent = 'ئیمەیڵ و وشەی نهێنی بنووسە'; return; }
    m.textContent = '...';
    authCall('password', { email: em, password: pw }).then(function () { renderPanel(); refreshUI(); return cycle(); })
      .catch(function (e) { m.textContent = (e.message || 'هەڵە'); });
  }


  // ---- backup / restore ----
  function bkKeys() { var k = []; for (var i = 0; i < LS.length; i++) { var n = LS.key(i); if (n && n.indexOf('mf_') === 0 && n.indexOf('mf_sync_') !== 0 && n.indexOf('_corrupt_backup_') < 0 && n.indexOf('mf_login_fails_') !== 0 && n !== 'mf_admin_session' && n !== 'mf_employee_session') k.push(n); } return k; }
  function doBackup() {
    var data = {}; bkKeys().forEach(function (k) { data[k] = _get.call(LS, k); });
    var d = new Date(), pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var name = 'massi-fars-backup-' + d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()) + '.json';
    var blob = new Blob([JSON.stringify({ app: 'massi-fars-backup', v: 1, at: d.toISOString(), data: data })], { type: 'application/json' });
    var file; try { file = new File([blob], name, { type: 'application/json' }); } catch (e) {}
    var viaAnchor = function () { var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 4000); };
    if (file && navigator.canShare && navigator.canShare({ files: [file] })) navigator.share({ files: [file], title: name }).catch(function (e) { if (e && e.name !== 'AbortError') viaAnchor(); });
    else viaAnchor();
    meta.lastBackup = Date.now(); saveMeta();
  }
  function doRestore() {
    var inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = function () {
      var f = inp.files && inp.files[0]; if (!f) return;
      var r = new FileReader();
      r.onload = function () {
        var j; try { j = JSON.parse(r.result); } catch (e) { window.mfDialog.alert('فایلەکە دروست نییە', { title: 'فایلی نادروست', type: 'err' }); return; }
        if (!j || j.app !== 'massi-fars-backup' || !j.data) { window.mfDialog.alert('ئەمە فایلی باکئەپی ماسی فارس نییە', { title: 'فایلی هەڵە', type: 'err' }); return; }
        var n = Object.keys(j.data).length;
        window.mfDialog.confirm('هەموو داتای ئێستا بە داتای ئەم باکئەپە دەگۆڕدرێت (' + n + ' بەش، لە ' + (j.at || '').slice(0, 10) + ').\nئەم گۆڕانکارییە بۆ هەموو ئامێرەکانیش دەگوازرێتەوە.',
          { title: 'گەڕاندنەوە لە باکئەپ', type: 'warn', icon: 'hist', ok: 'بەڵێ، بیگەڕێنەوە', cancel: 'پاشگەزبوونەوە' }).then(function (yes) {
          if (!yes) return;
          applying = false;
          bkKeys().forEach(function (k) { if (!(k in j.data)) LS.removeItem(k); });
          Object.keys(j.data).forEach(function (k) { if (k.indexOf('mf_') === 0 && k.indexOf('mf_sync_') !== 0 && typeof j.data[k] === 'string') { try { LS.setItem(k, j.data[k]); } catch (e) { window.mfDialog.alert(k, { title: 'شوێنی ئامێرەکە پڕە', type: 'err' }); } } });
          setTimeout(function () { location.reload(); }, 1200);
        });
      };
      r.readAsText(f);
    };
    inp.click();
  }

  var gate;
  var IC = {
    cloud: '<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 19a4.5 4.5 0 0 0 .5-8.97A6 6 0 0 0 6.34 8.6 4.8 4.8 0 0 0 7 19z"/><path d="m9 13.5 2 2 4-4.5"/></svg>',
    mail: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3.5 7 8.5 6 8.5-6"/></svg>',
    lock: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>',
    eye: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>'
  };
  function errText(m) {
    if (/Invalid login|invalid_grant|credentials/i.test(m)) return 'ئیمەیڵ یان وشەی نهێنی هەڵەیە';
    if (/Failed to fetch|abort|Network|Load failed/i.test(m)) return 'ئینتەرنێت نییە، دووبارە هەوڵ بدەرەوە';
    return m || 'هەڵەیەک ڕوویدا';
  }
  function buildGate() {
    gate = el('div', { id: 'mfs-gate' });
    gate.innerHTML = '<i class="blob b1"></i><i class="blob b2"></i><i class="blob b3"></i>' +
      '<div id="mfs-card"><div id="mfs-logo">' + IC.cloud + '</div>' +
      '<h2>بەخێربێیت</h2><p class="sub">بۆ پاراستنی داتاکانت و گونجاندنیان لەسەر هەموو ئامێرەکان، سەرەتا بچۆ ژوورەوە بۆ سێرڤەر</p>' +
      '<div id="mfs-form"><div class="mfs-f">' + IC.mail + '<input id="mfs-em" type="email" placeholder="ئیمەیڵ" autocomplete="username" autocapitalize="off" spellcheck="false"></div>' +
      '<div class="mfs-f">' + IC.lock + '<input id="mfs-pw" type="password" placeholder="وشەی نهێنی" autocomplete="current-password"><button type="button" class="mfs-eye" id="mfs-eye" aria-label="show">' + IC.eye + '</button></div>' +
      '<div id="mfs-err"></div><button id="mfs-go" type="button">پەیوەستبوون بە سێرڤەر</button>' +
      '<button id="mfs-skip" type="button">بەردەوامبوون بێ سێرڤەر</button></div>' +
      '<div id="mfs-steps"><div id="mfs-s1" class="on"><span class="mfs-dot"></span>پەیوەستبوون بە سێرڤەر</div><div id="mfs-s2"><span class="mfs-dot"></span>گونجاندنی داتاکان</div></div></div>';
    document.body.appendChild(gate);
    var pw = gate.querySelector('#mfs-pw');
    gate.querySelector('#mfs-eye').onclick = function () { pw.type = pw.type === 'password' ? 'text' : 'password'; };
    gate.querySelector('#mfs-go').onclick = gateLogin;
    gate.querySelector('#mfs-skip').onclick = function () { meta.skip = 1; saveMeta(); hideGate(); };
    pw.addEventListener('keydown', function (e) { if (e.key === 'Enter') gateLogin(); });
    gate.querySelector('#mfs-em').addEventListener('keydown', function (e) { if (e.key === 'Enter') pw.focus(); });
  }
  function showGate() { if (!gate) buildGate(); gate.querySelector('#mfs-form').style.display = ''; gate.querySelector('#mfs-steps').style.display = 'none'; gate.querySelector('#mfs-err').textContent = ''; gate.classList.add('open'); }
  function hideGate() { if (gate) gate.classList.remove('open'); }
  function stepMark(id, cls) { var e = gate.querySelector(id); e.className = cls; e.querySelector('.mfs-dot').textContent = cls === 'done' ? '✓' : ''; }
  function gateLogin() {
    var em = gate.querySelector('#mfs-em').value.trim(), pw = gate.querySelector('#mfs-pw').value, err = gate.querySelector('#mfs-err'), go = gate.querySelector('#mfs-go');
    if (!em || !pw) { err.textContent = 'ئیمەیڵ و وشەی نهێنی بنووسە'; return; }
    err.textContent = ''; go.disabled = true; go.innerHTML = '<span class="mfs-sp"></span>چاوەڕێبە ...';
    authCall('password', { email: em, password: pw }).then(function () {
      gate.querySelector('#mfs-form').style.display = 'none'; gate.querySelector('#mfs-steps').style.display = 'block';
      stepMark('#mfs-s1', 'done'); stepMark('#mfs-s2', 'on'); refreshUI();
      return cycle().then(function () {
        if (st.err && st.err !== 'NOAUTH') { gate.querySelector('#mfs-form').style.display = ''; err.textContent = errText(st.err); go.disabled = false; go.textContent = 'دووبارە هەوڵبدەرەوە'; return; }
        stepMark('#mfs-s2', 'done'); setTimeout(hideGate, 700);
      });
    }).catch(function (e) { err.textContent = errText(e.message); go.disabled = false; go.textContent = 'پەیوەستبوون بە سێرڤەر'; });
  }

  function initUI() {
    if (chip) return;
    document.head.appendChild(el('style', {}, CSS));
    chip = el('button', { id: 'mfs-chip', 'aria-label': 'sync' }); chip.onclick = function () { if (!isAdminNow()) return; if (auth && Object.keys(inbox).length) { reloadNow(); return; } if (!auth) { showGate(); return; } renderPanel(); panel.classList.add('open'); };
    var host = document.querySelector('.top-nav-content'), prof = host && host.querySelector('.user-profile-nav');
    if (host && prof) host.appendChild(chip); else { chip.classList.add('fixed'); document.body.appendChild(chip); }
    panel = el('div', { id: 'mfs-panel' }); panel.appendChild(el('div', { id: 'mfs-box' }));
    panel.addEventListener('click', function (e) { if (e.target === panel) panel.classList.remove('open'); });
    document.body.appendChild(panel);
    // ---- online/offline indicator for non-admin users ----
    document.head.appendChild(el('style', {}, '#mfs-net{position:relative;width:46px;height:46px;flex:0 0 46px;margin-inline-start:10px;border-radius:15px;display:flex;align-items:center;justify-content:center;padding:0;pointer-events:none;background:var(--bg-card,#fff);border:1px solid var(--border,rgba(0,0,0,.08));box-shadow:var(--solid-shadow,0 6px 16px rgba(20,20,60,.12));transition:color .3s}' +
      '#mfs-net.fixed{position:fixed;left:10px;bottom:calc(142px + env(safe-area-inset-bottom));z-index:2147483000;margin:0}' +
      '#mfs-net svg{width:26px;height:26px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}' +
      '#mfs-net.fast{color:#1fa35a}#mfs-net.slow{color:#d99a00}#mfs-net.none{color:#f97316}#mfs-net.off{color:#d93a3a}' +
      '#mfs-net .cnt{position:absolute;top:-5px;left:-5px;min-width:19px;height:19px;padding:0 5px;border-radius:10px;background:#6d3df0;color:#fff;font:800 11px/19px system-ui;text-align:center;box-sizing:border-box;box-shadow:0 2px 6px rgba(0,0,0,.25)}' +
      '#mfs-net .dot{position:absolute;top:5px;right:5px;width:11px;height:11px;border-radius:50%;background:currentColor;border:2px solid var(--bg-card,#fff);box-sizing:border-box}' +
      '#mfs-net.fast .dot{animation:mfsDot 2.6s ease-in-out infinite}#mfs-net.slow .dot,#mfs-net.none .dot{animation:mfsDot 1.1s ease-in-out infinite}#mfs-net.off .dot{display:none}'));
    var net = el('div', { id: 'mfs-net', role: 'status' });
    if (host && prof) host.appendChild(net); else { net.classList.add('fixed'); document.body.appendChild(net); }
    var WIFI_ON = '<svg viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><path d="M12 20h.01"/></svg>';
    var WIFI_SLOW = '<svg viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0 1 14.08 0" opacity=".3"/><path d="M1.42 9a16 16 0 0 1 21.16 0" opacity=".3"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><path d="M12 20h.01"/></svg>';
    var WIFI_NONE = '<svg viewBox="0 0 24 24"><path d="M5 12.55a11 11 0 0 1 14.08 0" opacity=".35"/><path d="M1.42 9a16 16 0 0 1 21.16 0" opacity=".35"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0" opacity=".35"/><path d="M12 8v5"/><path d="M12 17h.01"/></svg>';
    var WIFI_OFF = '<svg viewBox="0 0 24 24"><path d="M12 20h.01"/><path d="M8.5 16.43a5 5 0 0 1 7 0"/><path d="M5 12.86a10 10 0 0 1 5.17-2.69"/><path d="M13.83 10.17a10 10 0 0 1 5.17 2.69"/><path d="M2 8.82a15 15 0 0 1 4.17-2.65"/><path d="M10.66 5c4.01-.36 8.14.9 11.34 3.76"/><path d="M2 2l20 20"/></svg>';
    var NETUI = {
      fast: { ico: WIFI_ON,   label: 'ئینتەرنێت باشە و خێرایە' },
      slow: { ico: WIFI_SLOW, label: 'ئینتەرنێت هێواشە' },
      none: { ico: WIFI_NONE, label: 'پەیوەندی هەیە بەڵام ئینتەرنێت نییە' },
      off:  { ico: WIFI_OFF,  label: 'ئۆفلاین' }
    };

    // ---- real connection probe: measures round-trip time to the server (fast / slow / connected-but-no-internet / offline) ----
    var Q = { state: navigator.onLine ? 'fast' : 'off', rtts: [], busy: false };
    function median(a) { var b = a.slice().sort(function (x, y) { return x - y; }); return b[Math.floor(b.length / 2)]; }
    function setQ(state) {
      var was = Q.state; Q.state = state;
      applyNet();
      if ((was === 'off' || was === 'none') && (state === 'fast' || state === 'slow')) { try { cycle(); } catch (e) {} }
    }
    function probe() {
      if (Q.busy) return;
      if (!navigator.onLine) { Q.rtts = []; setQ('off'); return; }
      Q.busy = true;
      var t0 = Date.now(), c = new AbortController(), to = setTimeout(function () { c.abort(); }, 8000);
      fetch(CFG.url + '/auth/v1/health?_=' + t0, { headers: { apikey: CFG.key }, cache: 'no-store', signal: c.signal })
        .then(function () {
          clearTimeout(to);
          var rtt = Date.now() - t0;
          Q.rtts.push(rtt); if (Q.rtts.length > 3) Q.rtts.shift();
          Q.rtt = median(Q.rtts);
          setQ(Q.rtt < 1500 ? 'fast' : 'slow');
        })
        .catch(function () {
          clearTimeout(to);
          // a successful sync cycle in the last 15s proves the internet works even if the probe was blocked
          if (st.last && Date.now() - st.last < 15000) { setQ(Q.state === 'off' || Q.state === 'none' ? 'slow' : Q.state); return; }
          Q.rtts = [];
          setQ(navigator.onLine ? 'none' : 'off');
        })
        .then(function () { Q.busy = false; });
    }
    function applyNet() {
      if (net.style.display) net.style.display = '';
      var k = Q.state, q = qn(), key = k + '|' + q;
      if (net.__k !== key) {
        net.__k = key; net.className = k + (net.classList.contains('fixed') ? ' fixed' : '');
        net.innerHTML = NETUI[k].ico + '<i class="dot"></i>' + (q ? '<span class="cnt">' + Math.min(q, 99) + '</span>' : '');
        var t = NETUI[k].label + (q ? ' — ' + q + ' گۆڕانکاری چاوەڕێی ناردنە' : '');
        net.setAttribute('aria-label', t); net.title = t;
      }
    }
    addEventListener('online', function () { probe(); });
    addEventListener('offline', function () { Q.rtts = []; setQ('off'); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden) probe(); });
    setInterval(function () { if (!document.hidden) probe(); }, 15000);
    probe();
    function applyAdminVis() {
      var a = isAdminNow();
      var d = a ? '' : 'none';
      applyNet();
      if (chip.style.display !== d) chip.style.display = d;
      if (!a && panel && panel.classList.contains('open')) panel.classList.remove('open');
    }
    applyAdminVis(); setInterval(applyAdminVis, 1000);
    refreshUI();
    if (!auth && !meta.skip && !(window.MF_AUTH && window.MF_AUTH.cloud)) showGate();
  }

  function start() {
    initUI();
    addEventListener('online', function () { st.online = true; refreshUI(); cycle(); });
    addEventListener('offline', function () { refreshUI(); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden) cycle(); });
    var __pollN = 0; pollT = setInterval(function () { if (document.hidden) return; __pollN++; if (Date.now() - lastTouch > 60000 && __pollN % 4 !== 0) return; cycle(); }, 4000); /* active: every 4s, idle >60s: every 16s */
    setInterval(maybeReload, 1500);
    cycle();
  }
  // ---- weekly reminder to make a file backup (shows at most once a day) ----
  function backupReminder() {
    try {
      if (document.getElementById('mfs-bkrem') || !document.body || document.body.classList.contains('app-locked') || !isAdminNow()) return;
      var now = Date.now(), last = meta.lastBackup || 0;
      if (last && now - last < 7 * 864e5) return;
      if (meta.bkSnooze && now < meta.bkSnooze) return;
      var b = document.createElement('div'); b.id = 'mfs-bkrem'; b.dir = 'rtl';
      b.style.cssText = 'position:fixed;left:12px;right:12px;bottom:calc(92px + env(safe-area-inset-bottom,0px));z-index:2147482000;max-width:420px;margin:0 auto;padding:14px;border-radius:20px;background:var(--bg-card,#fff);color:var(--text-main,#222);border:1px solid var(--border,rgba(128,128,128,.3));box-shadow:0 14px 40px rgba(0,0,0,.28);font-family:inherit';
      b.innerHTML = '<div class="t" style="font-weight:800;font-size:14px;line-height:1.7;margin-bottom:10px"></div><div style="display:flex;gap:8px"><button type="button" data-a="go" style="flex:1;border:0;border-radius:14px;padding:11px;background:#0ea5e9;color:#fff;font:inherit;font-weight:800;cursor:pointer">باکئەپ بکە</button><button type="button" data-a="later" style="flex:0 0 auto;border:1px solid var(--border,rgba(128,128,128,.3));border-radius:14px;padding:11px 16px;background:transparent;color:inherit;font:inherit;font-weight:700;cursor:pointer">دواتر</button></div>';
      b.querySelector('.t').textContent = last ? 'ئەم ' + Math.floor((now - last) / 864e5) + ' ڕۆژە باکئەپی فایلت نەکردووە. با داتاکانت بپارێزین.' : 'هێشتا باکئەپی فایلت نەکردووە. با داتاکانت بپارێزین.';
      var snooze = function (h) { meta.bkSnooze = Date.now() + h * 36e5; saveMeta(); if (b.parentNode) b.remove(); };
      b.querySelector('[data-a=go]').onclick = function () { b.remove(); doBackup(); };
      b.querySelector('[data-a=later]').onclick = function () { snooze(24); };
      document.body.appendChild(b);
      setTimeout(function () { if (b.parentNode) snooze(12); }, 20000);
    } catch (e) {}
  }
  setTimeout(backupReminder, 10000); setInterval(backupReminder, 30 * 60000);
  var MFA = function () { return window.MF_AUTH || {}; };
  function mfEmail(u) { u = String(u || '').trim().toLowerCase(); var d = MFA().domain || 'mf.local'; if (/^[a-z0-9._-]{1,40}$/.test(u)) return u + '@' + d; var b = new TextEncoder().encode(u), h = ''; for (var i = 0; i < b.length; i++) h += ('0' + b[i].toString(16)).slice(-2); return 'u' + h + '@' + d; }
  function jwtRole(t) { try { var p = JSON.parse(atob(String(t).split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))); return (p.app_metadata && p.app_metadata.role) || ''; } catch (e) { return ''; } }
  var cloud = {
    enabled: function () { return !!(MFA().cloud && CFG && CFG.url); },
    email: mfEmail,
    login: function (username, password) { return authCall('password', { email: mfEmail(username), password: password }).then(function (a) { return { role: jwtRole(a.access), username: username }; }); },
    role: function () { return auth ? jwtRole(auth.access) : ''; },
    logout: function () { auth = null; _rem.call(LS, 'mf_sync_auth'); try { refreshUI(); } catch (e) {} },
    call: function (action, payload) {
      return token().then(function (tok) {
        var body = { action: action }; for (var k in (payload || {})) if (payload[k] !== undefined) body[k] = payload[k];
        return fetch(MFA().fn || (CFG.url + '/functions/v1/manage-users'), { method: 'POST', headers: hdr(tok), body: JSON.stringify(body), signal: tmo(30000) })
          .then(function (r) { return r.json().then(function (j) { if (!r.ok || j.error) throw new Error(j.error || ('HTTP ' + r.status)); return j; }); });
      });
    }
  };
  window.__mfSync = { cloud: cloud, token: token, api: api, resetServer: resetServer, cycle: cycle, state: function () { return { st: st, queue: qn(), inbox: Object.keys(inbox).length, meta: meta, authed: !!auth }; }, reloadNow: reloadNow, _encode: encode, _decode: decode };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();

