(function () {
    'use strict';
    var KEYS = ['exp', 'debtnew', 'debtborrow', 'pur', 'cs'];
    var S = {};
    var OPTS = [
        { v: true,  title: 'حساب بکرێت',   sub: 'لەگەڵ کۆی گشتی ئەم ڕۆژە', icon: 'calculator', color: '#10b981' },
        { v: false, title: 'حساب نەکرێت', sub: 'لە کۆی گشتی ئەم ڕۆژە دەربچێت', icon: 'ban',        color: '#f59e0b' }
    ];
    function st(k) { if (!(k in S)) S[k] = true; return S[k]; }
    function icons() { try { if (typeof safeCreateIcons === 'function') safeCreateIcons(); else if (window.lucide) window.lucide.createIcons(); } catch (e) {} }
    function render(k) {
        var host = document.getElementById('mf-count-host-' + k);
        if (!host) return;
        var cur = st(k);
        host.innerHTML = '<div class="mf-count-head"><i data-lucide="calendar-check"></i><span>کۆی گشتی ئەم ڕۆژە</span></div><div class="mf-count-seg">' +
            OPTS.map(function (o) {
                return '<button type="button" class="mf-count-opt' + (o.v === cur ? ' on' : '') + '" style="--dc:' + o.color + '" onclick="mfCount.set(\'' + k + '\',' + o.v + ')">' +
                    '<span class="mf-count-ico"><i data-lucide="' + o.icon + '"></i></span>' +
                    '<span class="mf-count-txt"><b>' + o.title + '</b><small>' + o.sub + '</small></span></button>';
            }).join('') + '</div>';
        icons();
    }
    function setState(k, v) { S[k] = !!v; render(k); }
    window.mfCount = {
        set: setState,
        setState: setState,
        reset: function (k) { setState(k, true); },
        skip: function (k) { return !st(k); },
        render: render
    };
    KEYS.forEach(render);
})();
