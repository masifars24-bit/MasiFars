(function(){
  'use strict';
  if (window.MFNumpad) return;

  var KB = null, S = { el: null, k: null, skip: false, pad: null, timer: 0, rep: 0, repT: 0 };
  var SKIP_TYPE = /^(hidden|checkbox|radio|file|range|color|date|time|datetime-local|month|week|button|submit|reset|image|email|url|search|password)$/;
  var NOT_NUM   = /(plate|vehicle|payer|payee|giver|taker|sender|owner|buyer-name|seller-name|name|note|search|mail|url|addr|country|account|user|pass|desc|title|comment|memo|text|type|product|lender|witness|receiver|coverage|reason|city|street|label|msg|message|key|link|file)/i;
  var IS_NUM    = /(price|amount|qty|quantity|count|kilo|gram|weight|cash|rate|salary|(^|[-_])sal([-_]|$)|phone|mobile|(^|[-_])tel([-_]|$)|disc|total|paid|payment|limit|(^|[-_])age([-_]|$)|num|cost|budget|points|(^|[-_])pin([-_]|$)|stock|fee|quota|percent|pct|stop-pos|required|remaining|deposit|balance|installment|usd|iqd|dinar|income|expense|profit)/i;
  var IS_PHONE  = /(phone|mobile|(^|[-_])tel([-_]|$)|مۆبایل|موبایل)/i;
  var PH_NUM    = /(ژمارە|بڕ|نرخ|کۆی|موچە|تەمەن|کێش|دینار|دۆلار)/;
  var PH_NOT    = /(ناو|نموونە|گەڕان|وشە|پاسۆرد|ئیمەیل|ناونیشان|تێبینی)/;
  var IS_DEC    = /(weight|rate|usd|percent|pct)/i;

  var ICON = {
    bs:  '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M21 5H9.2a2 2 0 0 0-1.5.7L2.5 12l5.2 6.3a2 2 0 0 0 1.5.7H21a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1z"/><path d="m16.5 9.5-5 5m0-5 5 5"/></svg>',
    clr: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.2"/><path d="m9 9 6 6m0-6-6 6"/></svg>',
    ok:  '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.8 4.6 4.6L19.2 7.6"/></svg>',
    shift:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4 4.5 12.5H9V19h6v-6.5h4.5z"/></svg>',
    globe:'<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 3.9 5.6 3.9 9s-1.3 6.4-3.9 9c-2.6-2.6-3.9-5.6-3.9-9S9.4 5.6 12 3z"/></svg>',
    ent: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 5v6a2 2 0 0 1-2 2H5m4-4-4 4 4 4"/></svg>',
    rst: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>',
    pen: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
    nx:  '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>'
  };

  /* ───────── کام خانە ژمارەییە؟ ───────── */
  function ro(el){ return el.readOnly && !el.__nkRO; }
  var COARSE = false;
  try { COARSE = window.matchMedia('(pointer: coarse)').matches || (navigator.maxTouchPoints > 0 && !window.matchMedia('(hover: hover)').matches); } catch (e) {}
  function attr(el, n){ return (el.getAttribute(n) || ''); }
  function isFld(t){ return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA'); }
  var TEXT_KIND = { text: true };
  function textLike(el){
    if (attr(el, 'data-kb') === 'native' || attr(el, 'data-numpad') === 'off') return false;
    var im = attr(el, 'inputmode').toLowerCase();
    if (im === 'email' || im === 'url') return false;
    if (el.tagName === 'TEXTAREA') return true;
    var t = (el.type || 'text').toLowerCase();
    return t === 'text' || t === 'search';
  }
  function kindOf(el){
    if (!isFld(el)) return null;
    if (el.__nk === undefined) { el.__nk = el.tagName === 'INPUT' ? compute(el) : null; el.__nkT = textLike(el); }
    if (ro(el) || el.disabled) return null;
    var M = window.MFNumpad;
    if (el.__nk) return M.enabled ? el.__nk : null;
    if (el.__nkT && M.textEnabled && COARSE) return TEXT_KIND;
    return null;
  }
  function compute(el){
    if (el.tagName !== 'INPUT') return null;
    var flag = attr(el, 'data-numpad');
    if (flag === 'off') return null;
    var type = (el.type || 'text').toLowerCase();
    if (SKIP_TYPE.test(type) && flag !== 'on') return null;
    var im = (el.__nkIm !== undefined ? el.__nkIm : attr(el, 'inputmode')).toLowerCase();
    var id = (attr(el, 'id') + ' ' + attr(el, 'name') + ' ' + attr(el, 'data-k') + ' ' + attr(el, 'data-field')).trim();
    var ph = attr(el, 'placeholder');
    var yes = flag === 'on' || type === 'number' || type === 'tel' || im === 'numeric' || im === 'decimal' || im === 'tel';
    if (!yes) {
      if (NOT_NUM.test(id)) return null;
      if (PH_NOT.test(ph)) return null;
      if (IS_NUM.test(id) || el.classList.contains('num')) yes = true;
      else if (PH_NUM.test(ph) && !PH_NOT.test(ph)) yes = true;
    }
    if (!yes) return null;
    var step = attr(el, 'step'), pat = attr(el, 'pattern'), min = attr(el, 'min');
    var phone = (type === 'tel' && im !== 'numeric') || IS_PHONE.test(id) || IS_PHONE.test(ph);
    return {
      decimal: im === 'decimal' || (type === 'number' && /any|\./.test(step)) || (IS_DEC.test(id) && !phone),
      neg: /-/.test(pat) || (min !== '' && parseFloat(min) < 0),
      phone: phone
    };
  }

  /* ───────── ئامادەکردنی خانە (کیبۆردی مۆبایل دابخە) ───────── */
  function prime(el){
    var k = kindOf(el); if (!k) return null;
    if (el.type === 'number') { try { el.type = 'text'; } catch (e) {} }
    if (el.__nkIm === undefined) el.__nkIm = el.getAttribute('inputmode');
    el.setAttribute('inputmode', 'none');
    if (!el.__nkOn && !el.__nkRO) el.__nkRO0 = el.hasAttribute('readonly');
    if (COARSE && !el.__nkRO0) { el.setAttribute('readonly', 'readonly'); el.__nkRO = true; }
    el.__nkOn = true;
    return k;
  }
  function restore(el){
    if (!el.__nkOn) return;
    el.__nkOn = false;
    if (el.__nkRO) { el.__nkRO = false; el.removeAttribute('readonly'); }
    if (el.__nkIm === null || el.__nkIm === undefined) el.removeAttribute('inputmode');
    else el.setAttribute('inputmode', el.__nkIm);
  }
  function commit(el){
    if (el.isConnected && el.__nkV !== undefined && el.value !== el.__nkV) {
      el.__nkV = el.value;
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    el.__nkV = el.value;
  }


  /* ───────── شوێنی دوگمەکان (دەتوانرێت بگۆڕدرێت) ───────── */
  var LS_CUSTOM = 'mf_kb_custom';
  var DEF_N = '123456789'.split(''), DEF_Z = ['0', '00', '000', '0000'];
  function getCustom(){ try { var o = JSON.parse(localStorage.getItem(LS_CUSTOM) || '{}'); return (o && typeof o === 'object') ? o : {}; } catch (e) { return {}; } }
  function saveCustom(o){ try { localStorage.setItem(LS_CUSTOM, JSON.stringify(o)); } catch (e) {} }
  function perm(key, def){
    var c = getCustom()[key];
    if (Array.isArray(c) && c.length === def.length && c.slice().sort().join('\u0001') === def.slice().sort().join('\u0001')) return c.slice();
    return def.slice();
  }
  function defFlat(lang){ return LAYOUT[lang].rows.reduce(function(a, r){ return a.concat(r); }, []); }
  function rowsFor(lang){
    var flat = perm(lang, defFlat(lang)), out = [], p = 0;
    LAYOUT[lang].rows.forEach(function(r){ out.push(flat.slice(p, p + r.length)); p += r.length; });
    return out;
  }
  function numHTML(){
    var N = perm('n', DEF_N), Z = perm('z', DEF_Z), sp = ['bs', 'clr', 'ex'], h = '';
    for (var r = 0; r < 3; r++) {
      for (var c = 0; c < 3; c++) {
        var i = r * 3 + c, d = N[i];
        h += '<button type="button" tabindex="-1" class="nk-k" data-a="' + d + '" data-p="n:' + i + '" style="--i:' + (r * 4 + c) + '">' + d + '</button>';
      }
      var k = sp[r], cls = 'nk-k', inner = '';
      if (k === 'bs') { cls += ' nk-del'; inner = ICON.bs; }
      else if (k === 'clr') { cls += ' nk-clr'; inner = ICON.clr; }
      else { cls += ' nk-ex off'; }
      h += '<button type="button" tabindex="-1" class="' + cls + '" data-a="' + k + '" style="--i:' + (r * 4 + 3) + '">' + inner + '</button>';
    }
    h += '<div class="nk-zrow" style="--i:12">';
    Z.forEach(function(z, i){ h += '<button type="button" tabindex="-1" class="nk-k nk-z" data-a="' + z + '" data-z="' + z + '" data-p="z:' + i + '">' + z + '</button>'; });
    return h + '</div>';
  }
  function renderNum(){
    var g = KB && KB.querySelector('.nk-grid'); if (!g) return;
    g.innerHTML = numHTML();
    if (S.k && !S.k.text && !S.edit) setExtra(S.k);
  }

  /* ───────── بنیاتنانی کیبۆرد ───────── */
  function build(){
    if (KB) return;
    var chips = [['n', 'ژمارە'], ['ku', 'کوردی'], ['ar', 'عەرەبی'], ['en', 'English']].map(function(x){
      return '<button type="button" tabindex="-1" class="nk-chip" data-tab="' + x[0] + '">' + x[1] + '</button>';
    }).join('');
    var h = '<div class="nk-sheet"><i class="nk-aur a"></i><i class="nk-aur b"></i>' +
      '<div class="nk-grip" data-g="1"></div>' +
      '<div class="nk-head"><button type="button" tabindex="-1" class="nk-done" data-a="done">' + ICON.ok + '</button>' +
      '<div class="nk-disp"><div class="nk-lab" dir="auto"></div><div class="nk-val"><span class="nk-txt"></span><span class="nk-caret"></span></div></div>' +
      '<div class="nk-edtabs"><div class="nk-edhint" dir="auto">دوو دوگمە هەڵبژێرە بۆ گۆڕینی شوێنیان</div><div class="nk-edrow">' + chips + '</div></div>' +
      '<button type="button" tabindex="-1" class="nk-next" data-a="next"><span class="ic-nx">' + ICON.nx + '</span><span class="ic-rst">' + ICON.rst + '</span></button>' +
      '<button type="button" tabindex="-1" class="nk-edit" data-a="edit" aria-label="edit">' + ICON.pen + '</button></div>' +
      '<div class="nk-grid">' + numHTML() + '</div><div class="nk-tgrid"></div></div><div class="nk-bub"></div>';
    KB = document.createElement('div');
    KB.id = 'mfnk'; KB.setAttribute('aria-hidden', 'true'); KB.innerHTML = h;
    document.body.appendChild(KB);
    S.bub = KB.querySelector('.nk-bub');
    applySize();

    KB.addEventListener('mousedown', function(e){ e.preventDefault(); });
    KB.addEventListener('touchstart', function(e){ if (e.cancelable) e.preventDefault(); }, { passive: false });
    KB.addEventListener('contextmenu', function(e){ e.preventDefault(); });
    KB.addEventListener('pointerdown', onKeyDown);
    ['pointerup','pointercancel','pointerleave'].forEach(function(t){ KB.addEventListener(t, onKeyUp, true); });
    initSwipe();
  }

  function onKeyDown(e){
    if (S.lp) {
      var lo = e.target.closest ? e.target.closest('.nk-lp-o') : null;
      if (lo) { e.preventDefault(); pickOpt(lo); return; }
      closeLP();
    }
    var b = e.target.closest ? e.target.closest('[data-a],[data-t],[data-tab]') : null;
    if (!b) return;
    if (S.edit) { e.preventDefault(); if (navigator.vibrate) { try { navigator.vibrate(6); } catch (x) {} } return editTap(b); }
    if (!S.el) return;
    e.preventDefault();
    if (b.classList.contains('off')) return;
    b.classList.add('p'); b.__t = Date.now();
    ripple(b, e);
    clickSound();
    if (navigator.vibrate) { try { navigator.vibrate(6); } catch (x) {} }
    var tv = b.getAttribute('data-t');
    if (tv !== null) {
      bubble(b, tv);
      var alts = altOf(tv);
      if (alts) { altDown(b, tv, alts); return; }
      typeKey(tv); return;
    }
    var a = b.getAttribute('data-a');
    if (a === 'edit') { var f0 = S.el; return openSettings(f0); }
    if (a === 'space' && S.k && S.k.text) { spaceDown(b); return; }
    act(a);
    if (a === 'bs') {
      stopRep();
      S.repT = setTimeout(function(){
        var d = 120;
        (function tick(){ act('bs'); d = Math.max(35, d - 8); S.rep = setTimeout(tick, d); })();
      }, 380);
    }
  }
  function onKeyUp(e){
    if (S.spT) {
      clearTimeout(S.spT); S.spT = 0;
      if (e.type === 'pointerup') { if (S.spCh === ' ') insertText(' '); else typeKey(S.spCh); }
    } else if (S.lp && S.lpHeld && (e.type === 'pointerup' || e.type === 'pointercancel')) {
      S.lpHeld = false;
      {
        var o = lpAt(e.clientX, e.clientY);
        if (o) pickOpt(o);
      }
    }
    var b = e.target.closest ? e.target.closest('[data-a],[data-t]') : null;
    stopRep(); hideBub();
    if (!b) return;
    var left = Math.max(0, 80 - (Date.now() - (b.__t || 0)));
    setTimeout(function(){ b.classList.remove('p'); }, left);
  }
  function stopRep(){ clearTimeout(S.repT); clearTimeout(S.rep); }
  function ripple(b, e){
    var r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 1.6, s = document.createElement('span');
    s.className = 'nk-rip';
    s.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (e.clientX - r.left - d / 2) + 'px;top:' + (e.clientY - r.top - d / 2) + 'px';
    b.appendChild(s); setTimeout(function(){ if (s.parentNode) s.parentNode.removeChild(s); }, 600);
  }

  function initSwipe(){
    var g = KB.querySelector('.nk-grip'), y0 = null;
    g.addEventListener('pointerdown', function(e){ y0 = e.clientY; try { g.setPointerCapture(e.pointerId); } catch (x) {} });
    g.addEventListener('pointermove', function(e){ if (y0 !== null && e.clientY - y0 > 34) { y0 = null; closeKB(); } });
    g.addEventListener('pointerup', function(){ if (y0 !== null) { y0 = null; closeKB(); } });
  }

  /* ───────── کردارەکان ───────── */
  function act(a){
    var el = S.el; if (!el) return;
    if (a === 'done') return closeKB();
    if (a === 'next') return goNext();
    if (S.k && S.k.text) {
      if (a === 'bs') return backspaceText();
      if (a === 'shift') return shiftKey();
      if (a === 'sym') { S.layer = 'sym'; return renderText(); }
      if (a === 'abc') { S.layer = 'abc'; return renderText(); }
      if (a === 'lang') return nextLang();
      if (a === 'space') return insertText(' ');
      if (a === 'enter') return enterKey();
      return;
    }
    if (a === 'bs') return backspace();
    if (a === 'clr') { if (el.value !== '') { setVal('', 0, 0); } return; }
    if (a === 'ex') return insert(S.k.decimal ? '.' : S.k.neg ? '-' : S.k.phone ? '+' : '');
    insert(a);
  }
  function sig(s){ var n = 0; for (var i = 0; i < s.length; i++) if (/[0-9.]/.test(s[i])) n++; return n; }
  function selOf(el){
    var s = null, e = null;
    try { s = el.selectionStart; e = el.selectionEnd; } catch (x) {}
    if (s == null) { s = e = el.value.length; }
    return [s, e];
  }
  function setVal(cand, caret, right){
    var el = S.el;
    el.value = cand;
    try { el.setSelectionRange(caret, caret); } catch (x) {}
    el.dispatchEvent(new Event('input', { bubbles: true }));
    var v = el.value, p = v.length, c = 0;
    while (p > 0 && c < right) { p--; if (/[0-9.]/.test(v[p])) c++; }
    try { el.setSelectionRange(p, p); } catch (x) {}
    refresh();
  }
  function insert(txt){
    var el = S.el, k = S.k; if (!txt || !el || ro(el) || el.disabled) return;
    var v = el.value, se = selOf(el), s = se[0], e = se[1], cand, caret;
    if (txt === '.') {
      if (!k.decimal) return;
      if ((v.slice(0, s) + v.slice(e)).indexOf('.') >= 0) return;
      var pre = /\d/.test(v.slice(0, s)) ? '.' : '0.';
      cand = v.slice(0, s) + pre + v.slice(e); caret = s + pre.length;
    } else if (txt === '-') {
      if (!k.neg) return;
      if (v.charAt(0) === '-') { cand = v.slice(1); caret = Math.max(0, s - 1); }
      else { cand = '-' + v; caret = s + 1; }
    } else if (txt === '+') {
      if (!k.phone || v.charAt(0) === '+') return;
      cand = '+' + v; caret = s + 1;
    } else {
      cand = v.slice(0, s) + txt + v.slice(e); caret = s + txt.length;
      if (!k.phone) {
        var m = /^(-?)(0+)(?=\d)/.exec(cand);
        if (m) { cand = m[1] + cand.slice(m[0].length); caret = Math.max(m[1].length, caret - m[2].length); }
      }
    }
    if (el.maxLength > 0 && cand.length > el.maxLength) return;
    setVal(cand, caret, sig(cand.slice(caret)));
  }
  function backspace(){
    var el = S.el; if (!el || ro(el)) return;
    var v = el.value, se = selOf(el), s = se[0], e = se[1], cand, caret;
    if (s !== e) { cand = v.slice(0, s) + v.slice(e); caret = s; }
    else {
      var i = s; while (i > 0 && /[,\s٬٫]/.test(v.charAt(i - 1))) i--;
      if (i <= 0) return;
      cand = v.slice(0, i - 1) + v.slice(s); caret = i - 1;
    }
    if (cand === '-') { cand = ''; caret = 0; }
    setVal(cand, caret, sig(cand.slice(caret)));
  }


  /* ───────── کیبۆردی نووسین ───────── */
  var LS_LANG = 'mf_kb_lang';
  var LANGS = ['ku', 'ar', 'en'];
  var LANG_NAME = { ku: 'کوردی', ar: 'العربية', en: 'English' };
  var LANG_ABC = { ku: 'ئا', ar: 'أب', en: 'ABC' };
  var LAYOUT = {
    ku: { rtl: true,  rows: ['جحخهعغفڤقپچ'.split(''), 'گکمنتالبیسش'.split(''), 'دۆزوەڵێرڕئ'.split('')] },
    ar: { rtl: true,  rows: ['ضصثقفغعهخحج'.split(''), 'شسيبلاتنمكط'.split(''), 'ئءؤرىةوزظدذ'.split('')] },
    en: { rtl: false, rows: ['qwertyuiop'.split(''), 'asdfghjkl'.split(''), 'zxcvbnm'.split('')] }
  };
  var SYM = ['1234567890'.split(''), ['@','#','%','&','*','-','_','=','(',')','+'], ['،','؛','؟','!','.',',',':','"','/','«','»']];
  S.lang = 'ku'; S.layer = 'abc'; S.shift = 0; S.shiftT = 0;
  try { var sl = localStorage.getItem(LS_LANG); if (LANGS.indexOf(sl) > -1) S.lang = sl; } catch (e) {}

  function escA(s){ return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
  /* پیتە شاراوەکان: پەنجە لەسەر پیتەکە دابگرە */
  var ALT = { 'ز': ['ژ'], 'چ': ['ض'], 'پ': ['ث', 'ص'], 'گ': ['ط'], 'ی': ['ي'], 'د': ['ذ'], 'ۆ': ['ظ'], 'ئ': ['ء'] };
  function altOf(ch){ return (!S.edit && S.k && S.k.text && S.lang === 'ku' && S.layer === 'abc' && ALT[ch]) || null; }
  function tk(cls, attrs, inner, flex){
    return '<button type="button" tabindex="-1" class="nk-k nk-t ' + cls + '" ' + attrs + ' style="--w:' + flex + '">' + inner + '</button>';
  }
  function renderText(){
    if (!KB) return;
    closeLP();
    var lang = S.edit ? S.edit.tab : S.lang;
    var L = LAYOUT[lang], sym = !S.edit && S.layer === 'sym', en = lang === 'en', h = '', pi = 0;
    var BS = ICON.bs.replace(/width="28" height="28"/, 'width="24" height="24"');
    var rowDel = !sym && (lang === 'ku' || en);   /* سڕینەوە لە ڕیزی سێیەم، لەتەنیشت پیتەکان */
    var N = en && !sym ? 10 : 11;
    (sym ? SYM : rowsFor(lang)).forEach(function(r, ri){
      var rtl = !sym && L.rtl, last = ri === 2;
      h += '<div class="nk-trow' + (rtl ? ' rtl' : '') + '" style="--n:' + N + '">';
      if (!sym && en && last) h += tk('nk-fn' + (S.shift ? ' on' : '') + (S.shift === 2 ? ' caps' : ''), 'data-a="shift"', ICON.shift, 1.5);
      if (rowDel && last && !en) h += tk('nk-del', 'data-a="bs"', BS, 1);
      r.forEach(function(c){
        var ch = (!sym && en && S.shift && !S.edit) ? c.toUpperCase() : c;
        var al = (!sym && lang === 'ku' && !S.edit) ? ALT[ch] : null;
        h += tk('nk-ch', 'data-t="' + escA(ch) + '"' + (sym ? '' : ' data-p="l:' + (pi++) + '"'), escA(ch) + (al ? '<i class="nk-alt">' + al.join('') + '</i>' : ''), 1);
      });
      if (rowDel && last && en) h += tk('nk-del', 'data-a="bs"', BS, 1.5);
      h += '</div>';
    });
    var comma = en ? ',' : '،';
    h += '<div class="nk-trow" style="--n:' + N + '">' +
      tk('nk-fn', 'data-a="' + (sym ? 'abc' : 'sym') + '"', sym ? LANG_ABC[lang] : '123', en && !sym ? 1.5 : rowDel ? 2 : 1.5) +
      tk('nk-fn', 'data-a="lang"', ICON.globe, 1) +
      tk('nk-ch', 'data-t="' + comma + '"', comma, 1) +
      tk('nk-space', 'data-a="space"', LANG_NAME[lang], en && !sym ? 3 : rowDel ? 4 : 3.5) +
      (en && !sym ? tk('nk-ch', 'data-t="\'"', "'", 1) : '') +
      tk('nk-ch', 'data-t="."', '.', 1) +
      (rowDel ? '' : tk('nk-del', 'data-a="bs"', BS, 1.5)) +
      tk('nk-enter', 'data-a="enter"', ICON.ent, rowDel && !en ? 2 : 1.5) + '</div>';
    var g = KB.querySelector('.nk-tgrid');
    g.className = 'nk-tgrid' + (en ? ' en' : '');
    g.innerHTML = h;
  }
  function typeKey(ch){
    insertText(ch);
    if (S.shift === 1 && S.lang === 'en' && S.layer === 'abc') { S.shift = 0; renderText(); }
  }
  function shiftKey(){
    var now = Date.now();
    if (S.shift === 2) S.shift = 0;
    else if (S.shift === 1) S.shift = (now - S.shiftT < 420) ? 2 : 0;
    else S.shift = 1;
    S.shiftT = now; renderText();
  }
  /* پەنجە لەسەر ناوەند (سپەیس) دابگرە → هەر سێ زمانەکە دەرەکەون */
  function altDown(b, ch, alts){
    clearTimeout(S.spT); S.spCh = ch;
    S.spT = setTimeout(function(){
      S.spT = 0; showLP(b, alts);
      if (navigator.vibrate) { try { navigator.vibrate(14); } catch (x) {} }
    }, 300);
  }
  function spaceDown(b){
    clearTimeout(S.spT); S.spCh = ' ';
    S.spT = setTimeout(function(){
      S.spT = 0; showLP(b);
      if (navigator.vibrate) { try { navigator.vibrate(14); } catch (x) {} }
    }, 340);
  }
  function showLP(b, alts){
    closeLP();
    var d = document.createElement('div'); d.className = 'nk-lp';
    d.innerHTML = alts ? alts.map(function(c){
      return '<div class="nk-lp-o ch" data-c="' + escA(c) + '">' + escA(c) + '</div>';
    }).join('') : LANGS.map(function(l){
      return '<div class="nk-lp-o' + (l === S.lang ? ' cur' : '') + '" data-l="' + l + '">' + LANG_NAME[l] + '</div>';
    }).join('');
    KB.appendChild(d); S.lp = d; S.lpHeld = true;
    var r = b.getBoundingClientRect(), R = KB.getBoundingClientRect();
    var cx = r.left + r.width / 2 - R.left, hw = d.offsetWidth / 2, W = R.width;
    cx = Math.max(hw + 8, Math.min(W - hw - 8, cx));
    d.style.left = cx + 'px';
    d.style.top = (r.top - R.top - d.offsetHeight - 10) + 'px';
    KB.addEventListener('pointermove', lpMove);
  }
  function lpAt(x, y){
    var el = document.elementFromPoint(x, y);
    return el && el.closest ? el.closest('.nk-lp-o') : null;
  }
  function lpMove(e){
    if (!S.lp) return;
    var o = lpAt(e.clientX, e.clientY);
    [].forEach.call(S.lp.children, function(c){ c.classList.toggle('hov', c === o); });
  }
  function closeLP(){
    clearTimeout(S.spT); S.spT = 0;
    if (KB) KB.removeEventListener('pointermove', lpMove);
    if (S.lp && S.lp.parentNode) S.lp.parentNode.removeChild(S.lp);
    S.lp = null; S.lpHeld = false;
  }
  function pickOpt(o){
    var c = o.getAttribute('data-c');
    if (c !== null) { closeLP(); if (navigator.vibrate) { try { navigator.vibrate(8); } catch (x) {} } insertText(c); return; }
    pickLang(o.getAttribute('data-l'));
  }
  function pickLang(l){
    if (LANGS.indexOf(l) < 0) return closeLP();
    closeLP();
    S.lang = l; S.shift = 0; S.layer = 'abc';
    try { localStorage.setItem(LS_LANG, S.lang); } catch (e) {}
    if (navigator.vibrate) { try { navigator.vibrate(8); } catch (x) {} }
    renderText();
  }
  function nextLang(){
    S.lang = LANGS[(LANGS.indexOf(S.lang) + 1) % LANGS.length]; S.shift = 0; S.layer = 'abc';
    try { localStorage.setItem(LS_LANG, S.lang); } catch (e) {}
    renderText();
  }
  function bubble(b, t){
    if (!S.bub || b.classList.contains('nk-space')) return;
    var r = b.getBoundingClientRect(), R = KB.getBoundingClientRect();
    S.bub.textContent = t;
    S.bub.style.left = (r.left + r.width / 2 - R.left) + 'px';
    S.bub.style.top = (r.top - R.top - 68) + 'px';
    S.bub.classList.add('on');
  }
  function hideBub(){ clearTimeout(S.bubT); S.bubT = setTimeout(function(){ if (S.bub) S.bub.classList.remove('on'); }, 70); }
  function setText(cand, caret){
    var el = S.el, right = cand.length - caret;
    el.value = cand;
    try { el.setSelectionRange(caret, caret); } catch (x) {}
    el.dispatchEvent(new Event('input', { bubbles: true }));
    var n = el.value.length, p = Math.max(0, Math.min(n, n - right));
    try { el.setSelectionRange(p, p); } catch (x) {}
    if (el.tagName === 'TEXTAREA' && p >= n) el.scrollTop = el.scrollHeight;
    refresh();
  }
  function insertText(txt){
    var el = S.el; if (!txt || !el || ro(el) || el.disabled) return;
    var v = el.value, se = selOf(el), s = se[0], e = se[1], cand = v.slice(0, s) + txt + v.slice(e);
    if (el.maxLength > 0 && cand.length > el.maxLength) return;
    setText(cand, s + txt.length);
  }
  function backspaceText(){
    var el = S.el; if (!el || ro(el)) return;
    var v = el.value, se = selOf(el), s = se[0], e = se[1];
    if (s !== e) return setText(v.slice(0, s) + v.slice(e), s);
    if (s <= 0) return;
    var n = (/[\uDC00-\uDFFF]/.test(v.charAt(s - 1)) && s > 1) ? 2 : 1;
    setText(v.slice(0, s - n) + v.slice(s), s - n);
  }
  function enterKey(){
    var el = S.el; if (!el) return;
    function mk(type){
      var ev = new KeyboardEvent(type, { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true });
      try { Object.defineProperty(ev, 'keyCode', { get: function(){ return 13; } }); Object.defineProperty(ev, 'which', { get: function(){ return 13; } }); } catch (x) {}
      return ev;
    }
    var ok = el.dispatchEvent(mk('keydown'));
    el.dispatchEvent(mk('keypress')); el.dispatchEvent(mk('keyup'));
    if (ok) { if (el.tagName === 'TEXTAREA') insertText('\n'); else closeKB(); }
  }


  /* ───────── دۆخی گۆڕینی شوێن ───────── */
  function openEditor(from){
    build();
    var back = (from && from.nodeType === 1) ? from : null, tab0 = 'n';
    if (back && S.k && S.k.text) tab0 = S.lang;
    if (S.el) { var e0 = S.el; if (document.activeElement === e0) e0.blur(); hide(); }
    S.edit = { tab: tab0, sel: null, warn: 0, back: back };
    KB.classList.add('edit', 'on'); KB.setAttribute('aria-hidden', 'false');
    renderEdit();
    var btn = document.getElementById('mf-ed-open'); if (btn) makeRoom(btn);
  }
  function closeEditor(silent){
    if (!S.edit) return;
    clearTimeout(S.edit.wt);
    var back = S.edit.back;
    S.edit = null; unRoom();
    if (!silent && back && back.isConnected) setTimeout(function(){ try { back.focus(); } catch (x) {} }, 60);
    if (KB) { KB.classList.remove('edit'); if (!silent) { KB.classList.remove('on', 'txt'); KB.setAttribute('aria-hidden', 'true'); } }
    if (KB) { var nx = KB.querySelector('.nk-next'); nx.classList.remove('warn'); }
  }
  function renderEdit(){
    var t = S.edit.tab;
    S.edit.sel = null; S.shift = 0;
    KB.classList.toggle('txt', t !== 'n');
    if (t === 'n') renderNum(); else renderText();
    Array.prototype.forEach.call(KB.querySelectorAll('.nk-chip'), function(c){ c.classList.toggle('on', c.getAttribute('data-tab') === t); });
    KB.querySelector('.nk-next').classList.remove('warn'); S.edit.warn = 0;
  }
  function editTap(b){
    var E = S.edit, tab = b.getAttribute('data-tab'), a = b.getAttribute('data-a');
    if (tab) { E.tab = tab; return renderEdit(); }
    if (a === 'done') return closeEditor();
    if (a === 'next') return resetTab();
    var pp = b.getAttribute('data-p'); if (!pp) return;
    var cur = KB.querySelector('.sel');
    if (!cur) { b.classList.add('sel'); E.sel = pp; return; }
    if (cur === b) { b.classList.remove('sel'); E.sel = null; return; }
    var g1 = E.sel.split(':'), g2 = pp.split(':');
    if (g1[0] !== g2[0]) { cur.classList.remove('sel'); b.classList.add('sel'); E.sel = pp; return; }
    var i = +g1[1], j = +g2[1], g = g1[0], key = g === 'l' ? E.tab : g;
    var arr = g === 'n' ? perm('n', DEF_N) : g === 'z' ? perm('z', DEF_Z) : perm(E.tab, defFlat(E.tab));
    var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    var all = getCustom(); all[key] = arr; saveCustom(all);
    if (E.tab === 'n') renderNum(); else renderText();
    E.sel = null;
    [E.sel, g + ':' + i, g + ':' + j].forEach(function(p){
      if (!p) return; var k = KB.querySelector('[data-p="' + p + '"]'); if (k) k.classList.add('swp');
    });
  }
  function resetTab(){
    var E = S.edit, nx = KB.querySelector('.nk-next');
    if (!E.warn) {
      E.warn = 1; nx.classList.add('warn');
      E.wt = setTimeout(function(){ if (S.edit) { S.edit.warn = 0; nx.classList.remove('warn'); } }, 2600);
      return;
    }
    clearTimeout(E.wt);
    var all = getCustom();
    if (E.tab === 'n') { delete all.n; delete all.z; } else delete all[E.tab];
    saveCustom(all); renderEdit();
  }

  /* ───────── خانەی دواتر ───────── */
  function visible(n){ return !!(n.offsetWidth || n.offsetHeight || n.getClientRects().length); }
  function nextOf(el){
    var root = el.closest('[role="dialog"],dialog,[class*="modal"],[class*="sheet"],[class*="overlay"],[class*="popup"]') || document;
    var all = root.querySelectorAll('input,textarea'), seen = false;
    for (var i = 0; i < all.length; i++) {
      var n = all[i];
      if (n === el) { seen = true; continue; }
      if (seen && kindOf(n) && visible(n)) return n;
    }
    return null;
  }
  function goNext(){
    var n = S.el && nextOf(S.el); if (!n) return;
    prime(n); n.focus();
    try { n.select(); } catch (x) {}
  }

  /* ───────── پیشاندان ───────── */
  function labelOf(el){
    var t = el.getAttribute('aria-label'), l;
    if (!t && el.id) { try { l = document.querySelector('label[for="' + (window.CSS && CSS.escape ? CSS.escape(el.id) : el.id) + '"]'); } catch (x) {} if (l) t = l.textContent; }
    if (!t) {
      l = el.closest('label');
      if (l) t = Array.prototype.filter.call(l.childNodes, function(n){ return n.nodeType === 3 || (n.nodeType === 1 && n.tagName !== 'INPUT' && !n.querySelector('input')); }).map(function(n){ return n.textContent; }).join(' ');
    }
    if (!t || !t.trim()) {
      var p = el.previousElementSibling;
      for (var i = 0; p && i < 2; i++, p = p.previousElementSibling) {
        var tx = (p.textContent || '').trim();
        if (/^(LABEL|SPAN|DIV|P|SMALL|B|STRONG)$/.test(p.tagName) && tx && tx.length < 40 && !p.querySelector('input')) { t = tx; break; }
      }
    }
    if ((!t || !t.trim()) && el.parentElement) {
      var pl = el.parentElement.previousElementSibling;
      if (pl && /^(LABEL|SPAN|DIV|P|SMALL)$/.test(pl.tagName) && (pl.textContent || '').trim().length < 40 && !pl.querySelector('input')) t = pl.textContent;
    }
    if (!t || !t.trim()) t = el.placeholder || el.title || '';
    return t.replace(/\s+/g, ' ').trim().slice(0, 50);
  }
  function refresh(){
    if (!KB || !S.el) return;
    var el = S.el, v = el.value, txt = KB.querySelector('.nk-txt'), box = KB.querySelector('.nk-val');
    if (S.k && S.k.text) {
      var tv = v.replace(/\s*\n\s*/g, ' \u21B5 ');
      txt.textContent = v === '' ? (el.placeholder || '') : (tv.length > 42 ? '\u2026' + tv.slice(-42) : tv);
      txt.classList.toggle('ph', v === ''); box.className = 'nk-val';
      var nx0 = KB.querySelector('.nk-next'); nx0.classList.toggle('dis', !nextOf(el));
      return;
    }
    txt.textContent = v === '' ? '0' : v;
    txt.classList.toggle('ph', v === '');
    box.className = 'nk-val' + (v.length > 17 ? ' s2' : v.length > 12 ? ' s1' : '');
    var nx = KB.querySelector('.nk-next'); nx.classList.toggle('dis', !nextOf(el));
  }
  function setExtra(k){
    var ex = KB.querySelector('[data-a="ex"]'), sym = k.decimal ? '.' : k.neg ? '−' : k.phone ? '+' : '';
    ex.textContent = sym; ex.classList.toggle('off', !sym);
  }

  function scroller(el){
    var fx = null;
    for (var p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var cs = getComputedStyle(p);
      if (/(auto|scroll|overlay)/.test(cs.overflowY)) return p;
      if (!fx && cs.position === 'fixed') fx = p;
    }
    if (fx) { fx.__nkOv = true; return fx; }
    return null;
  }
  function makeRoom(el){
    var h = KB.offsetHeight, sc = scroller(el), host = sc || document.body;
    if (S.pad && S.pad.n === host) { S.pad.h = h; host.style.paddingBottom = (S.pad.base + h) + 'px'; S.ug = false; }
    else {
    unRoom();
    var base = parseFloat(getComputedStyle(host).paddingBottom) || 0;
    S.pad = { n: host, old: host.style.paddingBottom, ov: host.style.overflowY, ovSet: !!(sc && sc.__nkOv), base: base, h: h };
    S.ug = false;
    host.style.paddingBottom = (base + h) + 'px';
    if (S.pad.ovSet) host.style.overflowY = 'auto';
    }
    /* دڵنیابوون لەوەی خانەکە لەسەرووی کیبۆردەکەیە (دوو جار: دوای دەرکەوتن و دوای ئەنیمەیشنەکە) */
    [60, 420].forEach(function(ms){
      setTimeout(function(){
        if (S.el !== el || !KB || S.ug) return;
        var hh = KB.offsetHeight, r = el.getBoundingClientRect(), vh = window.innerHeight, limit = vh - hh - 18;
        if (r.bottom > limit) {
          var d = r.bottom - limit;
          try { (sc || window).scrollBy({ top: d, behavior: 'auto' }); } catch (x) { (sc || window).scrollBy(0, d); }
        } else if (r.top < 8) {
          try { (sc || window).scrollBy({ top: r.top - 24, behavior: 'auto' }); } catch (x) {}
        }
      }, ms);
    });
  }
  function unRoom(){
    if (!S.pad) return;
    var n = S.pad.n;
    n.style.paddingBottom = S.pad.old;
    if (S.pad.ovSet) { n.style.overflowY = S.pad.ov; n.__nkOv = false; }
    S.pad = null;
  }

  function openFor(el, k){
    build();
    if (S.edit) closeEditor(true);
    S.el = el; S.k = k;
    if (el.__nkV === undefined || !el.__nkVSet) { el.__nkV = el.value; }
    KB.querySelector('.nk-lab').textContent = labelOf(el);
    KB.classList.toggle('txt', !!k.text);
    if (k.text) { S.layer = 'abc'; S.shift = 0; renderText(); } else setExtra(k);
    refresh();
    var was = KB.classList.contains('on');
    KB.classList.add('on'); KB.setAttribute('aria-hidden', 'false');
    makeRoom(el);
    clearInterval(S.timer);
    S.timer = setInterval(function(){
      if (!S.el || !S.el.isConnected || document.activeElement !== S.el) { if (!S.skip) hide(); }
    }, 500);
    return was;
  }
  function hide(){
    if (S.edit) return;
    closeLP();
    clearInterval(S.timer); stopRep(); unRoom();
    if (S.el) restore(S.el);
    S.el = null;
    if (KB) { KB.classList.remove('on'); KB.setAttribute('aria-hidden', 'true'); }
  }
  function closeKB(){
    if (S.edit) return closeEditor();
    var el = S.el;
    if (el && document.activeElement === el) el.blur(); else hide();
  }

  /* ───────── گوێگرە گشتییەکان ───────── */
  document.addEventListener('pointerdown', function(e){
    var t = e.target;
    if (isFld(t) && kindOf(t)) prime(t);
    if (S.el && KB && !KB.contains(t) && t !== S.el) { S.down = { x: e.clientX, y: e.clientY, t: t }; } else S.down = null;
  }, true);
  document.addEventListener('mousedown', function(e){ var t = e.target; if (isFld(t) && kindOf(t)) prime(t); }, true);
  document.addEventListener('touchstart', function(e){ var t = e.target; if (isFld(t) && kindOf(t)) prime(t); }, { capture: true, passive: true });
  document.addEventListener('pointerup', function(e){
    var d = S.down; S.down = null;
    if (!d || !S.el) return;
    if (Math.abs(e.clientX - d.x) < 10 && Math.abs(e.clientY - d.y) < 10) {
      var t = d.t;
      if (t && t.closest && t.closest('label') && t.closest('label').contains(S.el)) return;
      if (isFld(t) && kindOf(t)) return;
      if (S.el && document.activeElement === S.el) S.el.blur();
    }
  }, true);

  document.addEventListener('focusin', function(e){
    var el = e.target; if (!isFld(el)) return;
    var k = kindOf(el);
    if (!k) { if (S.el) hide(); return; }
    if (!el.__nkOn) {
      /* focus بە کۆد بوو: سەرەتا کیبۆردی مۆبایل دابخە و دووبارە focus بکەرەوە */
      prime(el);
      var se = selOf(el); S.skip = true;
      try { el.blur(); el.focus({ preventScroll: true }); el.setSelectionRange(se[0], se[1]); } catch (x) {}
      S.skip = false;
      if (document.activeElement !== el) return;
    }
    el.__nkV = el.value; el.__nkVSet = true;
    openFor(el, k);
  }, true);

  document.addEventListener('focusout', function(e){
    var el = e.target; if (!el || !el.__nkOn || S.skip) return;
    commit(el); el.__nkVSet = false;
    restore(el);
    setTimeout(function(){
      var a = document.activeElement;
      if (!(isFld(a) && a.__nkOn)) hide();
    }, 40);
  }, true);

  document.addEventListener('change', function(e){ var el = e.target; if (el && el.__nkV !== undefined) el.__nkV = el.value; }, true);
  document.addEventListener('input', function(e){ if (S.el && e.target === S.el) refresh(); }, true);
  /* گۆڕانی قەبارە (نوێکردنەوەی شریتی ناونیشان لە کاتی سکرۆڵ): تەنها ئەگەر بەرزی کیبۆردەکە گۆڕا، بێ ڕێکخستنەوەی سکرۆڵ */
  (function(){
    var rt = 0;
    window.addEventListener('resize', function(){
      clearTimeout(rt);
      rt = setTimeout(function(){
        if (!S.el || !S.pad || !KB) return;
        var h = KB.offsetHeight;
        if (Math.abs(h - S.pad.h) < 2) return;
        S.pad.h = h; S.pad.n.style.paddingBottom = (S.pad.base + h) + 'px';
      }, 150);
    });
    var ug = function(){ S.ug = true; };
    document.addEventListener('touchmove', ug, { passive: true, capture: true });
    document.addEventListener('wheel', ug, { passive: true, capture: true });
  })();

  /* ───────── داگیرساندن / کوژاندنەوە (ڕێکخستن) ───────── */
  var LSK = 'mf_numpad_on';
  function loadOn(){ try { return localStorage.getItem(LSK) !== '0'; } catch (e) { return true; } }
  var LST = 'mf_textkb_on';
  function loadTxt(){ try { return localStorage.getItem(LST) !== '0'; } catch (e) { return true; } }
  function syncOne(on, pre){
    var sw = document.getElementById(pre + '-switch'); if (!sw) return;
    sw.classList.toggle('on', on); sw.setAttribute('aria-pressed', on ? 'true' : 'false');
    var row = document.getElementById(pre + '-row'); if (row) row.classList.toggle('off', !on);
    var st = document.getElementById(pre + '-status');
    if (st) st.textContent = on ? 'داگیرساوە · کیبۆردی تایبەت کار دەکات' : 'کوژاوەتەوە · کیبۆردی مۆبایل کار دەکات';
  }
  function syncUI(){ syncOne(window.MFNumpad.enabled, 'mf-nk'); syncOne(window.MFNumpad.textEnabled, 'mf-tk'); }
  document.addEventListener('click', function(e){
    var t = e.target && e.target.closest ? e.target : null; if (!t) return;
    if (t.closest('#mf-nk-switch')) window.MFNumpad.setEnabled(!window.MFNumpad.enabled);
    else if (t.closest('#mf-tk-switch')) window.MFNumpad.setTextEnabled(!window.MFNumpad.textEnabled);
    else if (t.closest('#mf-ed-open')) openEditor();
  });


  /* ───────── دەنگ و قەبارە ───────── */
  var LS_SND = 'mf_kb_snd', LS_VOL = 'mf_kb_vol', LS_STY = 'mf_kb_snd_t', LS_SIZE = 'mf_kb_scale';
  function lsGet(k, d){ try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
  function lsSet(k, v){ try { localStorage.setItem(k, String(v)); } catch (e) {} }
  var CFG = {
    snd: lsGet(LS_SND, '0') === '1',
    vol: Math.max(0, Math.min(100, parseInt(lsGet(LS_VOL, '60'), 10) || 60)),
    sty: lsGet(LS_STY, 'normal'),
    size: Math.max(80, Math.min(130, parseInt(lsGet(LS_SIZE, '100'), 10) || 100))
  };
  var AC = null;
  var SND = { soft: ['sine', 420, .06, .9], normal: ['triangle', 780, .045, .6], sharp: ['square', 1500, .028, .22] };
  function clickSound(force){
    if (!CFG.snd && !force) return;
    try {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)();
      if (AC.state === 'suspended') AC.resume();
      var P = SND[CFG.sty] || SND.normal, t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain();
      o.type = P[0];
      o.frequency.setValueAtTime(P[1], t);
      o.frequency.exponentialRampToValueAtTime(P[1] * .6, t + P[2]);
      var v = Math.max(.0001, CFG.vol / 100 * P[3]);
      g.gain.setValueAtTime(v, t);
      g.gain.exponentialRampToValueAtTime(.0001, t + P[2]);
      o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + P[2] + .03);
    } catch (e) {}
  }
  function applySize(){
    if (!KB) return;
    KB.style.setProperty('--kh', 'calc(clamp(46px,7.3vh,58px) * ' + (CFG.size / 100) + ')');
  }

  /* ───────── سلایدی ڕێکخستنی کیبۆرد ───────── */
  var NS = null;
  var NI = {
    ok: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    abc: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18l4.5-12L12 18M4.8 14h5.4"/><path d="M15 9h5M17.5 9v9"/></svg>',
    mode: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="12" rx="3"/><path d="M6.5 10h.01M10 10h.01M13.5 10h.01M17 10h.01M7 14h10"/></svg>',
    vol: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>',
    size: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>'
  };
  function nsBuild(){
    if (NS) return;
    NS = document.createElement('div'); NS.id = 'mfnks'; NS.setAttribute('aria-hidden', 'true');
    NS.innerHTML =
      '<div class="ns-bd" data-n="close"></div><div class="ns-sh">' +
      '<div class="ns-grip"></div>' +
      '<div class="ns-top"><div class="ns-title">ڕێکخستنی کیبۆرد</div><button type="button" class="ns-ok" data-n="close">' + NI.ok + '</button></div>' +
      '<div class="ns-card"><div class="ns-h"><span class="ns-ic">' + NI.abc + '</span>دەستکاری پیت و ژمارەکان</div>' +
        '<div class="ns-row"><span>ژمارە · کوردی · عەرەبی · English</span><button type="button" class="ns-btn" data-n="layout">دەستکاری</button></div></div>' +
      '<div class="ns-card"><div class="ns-h"><span class="ns-ic">' + NI.mode + '</span>دۆخی کیبۆرد</div>' +
        '<div class="ns-row"><span>کیبۆردی ژمارە<span class="ns-sub" data-n-st="num"></span></span><button type="button" class="ns-sw" data-n="num"></button></div>' +
        '<div class="ns-row"><span>کیبۆردی نووسین<span class="ns-sub" data-n-st="txt"></span></span><button type="button" class="ns-sw" data-n="txt"></button></div></div>' +
      '<div class="ns-card"><div class="ns-h"><span class="ns-ic">' + NI.vol + '</span>دەنگ</div>' +
        '<div class="ns-row"><span>دەنگی دوگمەکان</span><button type="button" class="ns-sw" data-n="snd"></button></div>' +
        '<div class="ns-row" style="display:block"><span>ئاستی دەنگ</span><div class="ns-rng"><input type="range" min="0" max="100" step="5" data-n="vol"><span class="ns-val" data-n-v="vol"></span></div></div>' +
        '<div class="ns-row" style="display:block"><span>جۆری دەنگ</span><div class="ns-chips" style="margin-top:8px"><button type="button" class="ns-chip" data-n="sty" data-v="soft">نەرم</button><button type="button" class="ns-chip" data-n="sty" data-v="normal">ئاسایی</button><button type="button" class="ns-chip" data-n="sty" data-v="sharp">تیژ</button></div></div></div>' +
      '<div class="ns-card"><div class="ns-h"><span class="ns-ic">' + NI.size + '</span>قەبارەی کیبۆرد</div>' +
        '<div class="ns-rng"><input type="range" min="80" max="130" step="5" data-n="size"><span class="ns-val" data-n-v="size"></span></div>' +
        '<div class="ns-prev"><i>1</i><i>2</i><i>3</i><i>A</i></div>' +
        '<div class="ns-row" style="justify-content:flex-end"><button type="button" class="ns-btn g" data-n="size0">100%</button></div></div>' +
      '</div>';
    document.body.appendChild(NS);
    NS.addEventListener('contextmenu', function(e){ e.preventDefault(); });
    NS.addEventListener('click', function(e){
      var t = e.target.closest ? e.target.closest('[data-n]') : null; if (!t) return;
      var n = t.getAttribute('data-n');
      if (n === 'close') return closeSettings();
      if (n === 'layout') { var bk = NS.__back; closeSettings(true); return openEditor(bk); }
      if (n === 'num') window.MFNumpad.setEnabled(!window.MFNumpad.enabled);
      else if (n === 'txt') window.MFNumpad.setTextEnabled(!window.MFNumpad.textEnabled);
      else if (n === 'snd') { CFG.snd = !CFG.snd; lsSet(LS_SND, CFG.snd ? 1 : 0); if (CFG.snd) clickSound(); }
      else if (n === 'sty') { CFG.sty = t.getAttribute('data-v'); lsSet(LS_STY, CFG.sty); clickSound(true); }
      else if (n === 'size0') { CFG.size = 100; lsSet(LS_SIZE, 100); applySize(); }
      nsSync();
    });
    NS.addEventListener('input', function(e){
      var t = e.target, n = t.getAttribute && t.getAttribute('data-n');
      if (n === 'vol') { CFG.vol = +t.value; lsSet(LS_VOL, CFG.vol); }
      else if (n === 'size') { CFG.size = +t.value; lsSet(LS_SIZE, CFG.size); applySize(); }
      else return;
      nsSync();
    });
    NS.addEventListener('change', function(e){ if (e.target.getAttribute && e.target.getAttribute('data-n') === 'vol') clickSound(true); });
  }
  function nsSync(){
    if (!NS) return;
    var M = window.MFNumpad;
    function sw(n, on){ var b = NS.querySelector('.ns-sw[data-n="' + n + '"]'); if (b) b.classList.toggle('on', !!on); }
    sw('num', M.enabled); sw('txt', M.textEnabled); sw('snd', CFG.snd);
    var st = { num: M.enabled, txt: M.textEnabled };
    Object.keys(st).forEach(function(k){
      var el = NS.querySelector('[data-n-st="' + k + '"]');
      if (el) el.textContent = st[k] ? 'داگیرساوە · کیبۆردی تایبەت کار دەکات' : 'کوژاوەتەوە · کیبۆردی مۆبایل کار دەکات';
    });
    NS.querySelectorAll('.ns-chip').forEach(function(c){ c.classList.toggle('on', c.getAttribute('data-v') === CFG.sty); });
    var v = NS.querySelector('input[data-n="vol"]'); if (v && +v.value !== CFG.vol) v.value = CFG.vol;
    var z = NS.querySelector('input[data-n="size"]'); if (z && +z.value !== CFG.size) z.value = CFG.size;
    NS.querySelector('[data-n-v="vol"]').textContent = CFG.vol + '%';
    NS.querySelector('[data-n-v="size"]').textContent = CFG.size + '%';
    NS.querySelector('.ns-prev').style.setProperty('--ph', Math.round(52 * CFG.size / 100) + 'px');
    NS.querySelector('.ns-rng input[data-n="vol"]').disabled = !CFG.snd;
    NS.querySelector('.ns-rng input[data-n="vol"]').style.opacity = CFG.snd ? 1 : .4;
  }
  function openSettings(from){
    build(); nsBuild();
    var back = (from && from.nodeType === 1) ? from : null;
    if (S.el) { var e0 = S.el; if (document.activeElement === e0) e0.blur(); hide(); }
    NS.__back = back;
    nsSync();
    NS.classList.add('on'); NS.setAttribute('aria-hidden', 'false');
  }
  function closeSettings(keep){
    if (!NS) return;
    NS.classList.remove('on'); NS.setAttribute('aria-hidden', 'true');
    var back = NS.__back; NS.__back = null;
    if (!keep && back && back.isConnected) setTimeout(function(){ try { back.focus(); } catch (x) {} }, 60);
  }

  window.MFNumpad = {
    enabled: loadOn(),
    textEnabled: loadTxt(),
    setTextEnabled: function(v){
      this.textEnabled = !!v;
      try { localStorage.setItem(LST, v ? '1' : '0'); } catch (e) {}
      if (!v && S.el && S.k && S.k.text) { var el = S.el; if (document.activeElement === el) el.blur(); hide(); }
      syncUI();
    },
    setEnabled: function(v){
      this.enabled = !!v;
      try { localStorage.setItem(LSK, v ? '1' : '0'); } catch (e) {}
      if (!v && S.el) { var el = S.el; if (document.activeElement === el) el.blur(); hide(); }
      syncUI();
    },
    open: function(el){ var k = prime(el); if (k) el.focus(); },
    close: closeKB,
    isOpen: function(){ return !!S.el; },
    editLayout: openEditor,
    settings: openSettings,
    isEditing: function(){ return !!S.edit; }
  };
  syncUI();
})();


