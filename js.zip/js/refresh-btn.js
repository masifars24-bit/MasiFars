(function () {
    var BUILD = (document.querySelector('meta[name="mf-build"]') || {}).content || '';
    var IS_WEB = /^https?:$/.test(location.protocol);
    var btn = null, toastEl = null, toastT = null, bar = null, lastCheck = 0, busy = false, dismissed = false;

    /* پەیامی بچووک و ئارام، هاوشێوەی ئەپەکە */
    function say(msg, ms) {
        if (!toastEl) {
            toastEl = document.createElement('div');
            toastEl.setAttribute('role', 'status');
            toastEl.style.cssText = 'position:fixed;left:50%;top:calc(72px + env(safe-area-inset-top,0px));transform:translate(-50%,-8px);z-index:2147483000;max-width:calc(100vw - 40px);padding:8px 14px;border-radius:12px;background:var(--surface,#fff);color:var(--text-main,#111);border:1px solid var(--border,rgba(0,0,0,.1));font:700 12.5px/1.5 var(--main-font,sans-serif);text-align:center;box-shadow:0 8px 22px rgba(15,23,42,.14);opacity:0;pointer-events:none;transition:opacity .2s,transform .2s';
            document.body.appendChild(toastEl);
        }
        toastEl.textContent = msg; toastEl.style.opacity = '1'; toastEl.style.transform = 'translate(-50%,0)';
        clearTimeout(toastT); toastT = setTimeout(function () { toastEl.style.opacity = '0'; toastEl.style.transform = 'translate(-50%,-8px)'; }, ms || 2200);
    }

    /* فێچی سەرەتای لاپەڕەکە (٦ کیلۆبایت) لە سێرڤەرەوە، بەبێ cache */
    function peekServer(ms) {
        var ctl = new AbortController(), t = setTimeout(function () { try { ctl.abort(); } catch (e) {} }, ms || 8000);
        return fetch(location.pathname + '?mfv=' + Date.now(), { cache: 'no-store', signal: ctl.signal, headers: { Range: 'bytes=0-8191' } })
            .then(function (r) {
                if (!r || !(r.ok || r.status === 206) || !r.body) { clearTimeout(t); return { ok: !!(r && r.ok), build: null }; }
                var rd = r.body.getReader(), dec = new TextDecoder(), txt = '', n = 0;
                function pump() {
                    return rd.read().then(function (x) {
                        if (x.done) return;
                        txt += dec.decode(x.value, { stream: true }); n += x.value.length;
                        if (/name="mf-build"\s+content="[^"]+"/.test(txt) || n > 12000) return;
                        return pump();
                    });
                }
                return pump().then(function () {
                    try { ctl.abort(); } catch (e) {}
                    clearTimeout(t);
                    var m = /name="mf-build"\s+content="([^"]+)"/.exec(txt);
                    return { ok: true, build: m ? m[1] : null };
                });
            })
            .catch(function () { clearTimeout(t); return { ok: false, build: null }; });
    }

    /* سڕینەوەی cache و service workerـی کۆن (داتای ئەپەکە و localStorage دەستکاری ناکرێت) */
    function purge() { return Promise.resolve(); }   /* وەشانی پینکراو دەمێنێتەوە: نوێکردنەوە تەنها بە ڕەزامەندی بەکارهێنەر */

    function freshReload() {
        if (busy) return; busy = true;
        if (btn) btn.classList.add('spin');
        if (!IS_WEB) { setTimeout(function () { location.reload(); }, 300); return; }   /* فایلی لۆکاڵ (content:// یان file://): ڕاستەوخۆ نوێ بکەرەوە */
        peekServer(9000).then(function (res) {
            if (!res.ok) {                                   /* هێڵ لاوازە: لاپەڕەکە مەگۆڕە */
                busy = false; if (btn) btn.classList.remove('spin');
                say('هێڵ لاوازە، دووبارە هەوڵبدەوە');
                return;
            }
            return purge().then(function () { setTimeout(function () { location.reload(); }, 300); });
        });
    }

    function showUpdateBar() {
        if (bar || dismissed || !document.body) return;
        bar = document.createElement('div');
        bar.id = 'mf-update-bar';
        bar.style.cssText = 'position:fixed;left:50%;bottom:calc(92px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:2147482500;display:flex;align-items:center;gap:8px;max-width:calc(100vw - 28px);padding:6px 6px 6px 12px;border-radius:14px;background:var(--surface,#fff);color:var(--text-main,#111);border:1px solid var(--border,rgba(0,0,0,.1));font:700 12.5px var(--main-font,sans-serif);box-shadow:0 8px 22px rgba(15,23,42,.14)';
        var t = document.createElement('span'); t.textContent = 'وەشانی نوێ هەیە';
        var b = document.createElement('button'); b.type = 'button'; b.textContent = 'نوێ بکەرەوە';
        b.style.cssText = 'border:0;border-radius:10px;padding:7px 12px;background:var(--c-1,#4f46e5);color:#fff;font:800 12.5px var(--main-font,sans-serif);cursor:pointer';
        b.onclick = freshReload;
        var x = document.createElement('button'); x.type = 'button'; x.setAttribute('aria-label', 'داخستن'); x.textContent = '×';
        x.style.cssText = 'border:0;background:none;color:var(--text-sub,#71717a);font:400 20px/1 sans-serif;padding:0 6px;cursor:pointer';
        x.onclick = function () { dismissed = true; if (bar && bar.parentNode) bar.parentNode.removeChild(bar); bar = null; };
        bar.appendChild(t); bar.appendChild(b); bar.appendChild(x); document.body.appendChild(bar);
    }

    function checkVersion(force) {
        if (!IS_WEB || !BUILD || !navigator.onLine || bar || dismissed || ('serviceWorker' in navigator)) return;
        var now = Date.now(); if (!force && now - lastCheck < 45000) return; lastCheck = now;
        peekServer(8000).then(function (res) { if (res.ok && res.build && res.build !== BUILD) showUpdateBar(); });
    }

    function mount() {
        if (document.getElementById('mf-refresh-btn')) return;
        var host = document.querySelector('.top-nav-content');
        btn = document.createElement('button');
        btn.type = 'button'; btn.id = 'mf-refresh-btn';
        btn.setAttribute('aria-label', 'نوێکردنەوە'); btn.title = 'نوێکردنەوە';
        btn.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>';
        btn.addEventListener('click', freshReload);
        if (host) {
            var chip = document.getElementById('mfs-chip');
            if (chip && chip.parentNode === host) host.insertBefore(btn, chip); else host.appendChild(btn);
        } else { btn.classList.add('fixed'); document.body.appendChild(btn); }
    }

    function init() {
        mount();
        setTimeout(function () { checkVersion(true); }, 4000);
        addEventListener('online', function () { checkVersion(true); });
        document.addEventListener('visibilitychange', function () { if (!document.hidden) checkVersion(false); });
    }
    if (document.readyState === 'complete') init(); else addEventListener('load', init);
})();
