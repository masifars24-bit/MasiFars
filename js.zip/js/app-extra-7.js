(function () {
            try {
                const isAdmin = localStorage.getItem('mf_admin_session') === '1';
                let isEmployee = false;
                if (localStorage.getItem('mf_login_type') === 'employee') {
                    const sess = mfParseStorage('mf_employee_session', 'null', false);
                    isEmployee = !!(sess && sess.employeeId);
                }
                if (isAdmin || isEmployee) {
                    document.getElementById('app-login-gate').classList.add('hidden');
                } else {
                    document.body.classList.add('app-locked');
                }
            } catch (e) {  }
        })();
